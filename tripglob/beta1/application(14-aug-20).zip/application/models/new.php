<?php
Array
(
    [Status] => 1
    [Message] => 
    [Search] => Array
        (
            [FlightDataList] => Array
                (
                    [JourneyList] => Array
                        (
                            [0] => Array
                                (
                                    [0] => Array
                                        (
                                            [Price] => Array
                                                (
                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [PassengerCount] => 1
                                                                    [BasePrice] => 1550
                                                                    [Tax] => 747
                                                                    [TotalPrice] => 2297
                                                                )

                                                        )

                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2297
                                                    [PriceBreakup] => Array
                                                        (
                                                            [Tax] => 747
                                                            [BasicFare] => 1550
                                                            [YQValue] => 0.00
                                                            [CommissionEarned] => 46.5
                                                            [PLBEarned] => 30.07
                                                            [TdsOnCommission] => 2.325
                                                            [TdsOnPLB] => 1.5035
                                                            [AgentCommission] => 76.57
                                                            [AgentTdsOnCommision] => 3.829
                                                        )

                                                    [pax_breakup] => Array
                                                        (
                                                        )

                                                )

                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [journey_number] => onward
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [date_time] => 2019-03-27T13:35:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 13:35:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 13:35:00
                                                                                    [FDTV] => 1552982700
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [date_time] => 2019-03-27T14:35:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 14:35:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 14:35:00
                                                                                    [FATV] => 1552986300
                                                                                )

                                                                            [duration_seconds] => 3600
                                                                            [duration] => 1 Hr 
                                                                            [OperatorCode] => 6E
                                                                            [OperatorName] => Indigo
                                                                            [FlightNumber] => 258
                                                                            [is_leg] => 
                                                                            [operator_class] => X
                                                                            [CabinClass] => X
                                                                            [class] => Array
                                                                                (
                                                                                    [name] => Economy
                                                                                )

                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 Kg
                                                                                    [CabinBaggage] => 7 Kg
                                                                                    [AvailableSeats] => 1
                                                                                )

                                                                            [fare_info_ref] => H7MeSm3R2BKAgxyvAAAAAA==
                                                                            [fare_basis] => 
                                                                            [booking_code] => X
                                                                        )

                                                                )

                                                        )

                                                )

                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => false
                                                    [AirlineRemark] => 
                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*1*_*B3jYIgGHXwnyxQzV
                                            [booking_source] => PTBSID0000000007
                                            [token_key] => 161be3fe018f741be9eeafdca41c66eb
                                        )

                                    [1] => Array
                                        (
                                            [Price] => Array
                                                (
                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [PassengerCount] => 1
                                                                    [BasePrice] => 1550
                                                                    [Tax] => 747
                                                                    [TotalPrice] => 2297
                                                                )

                                                        )

                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2297
                                                    [PriceBreakup] => Array
                                                        (
                                                            [Tax] => 747
                                                            [BasicFare] => 1550
                                                            [YQValue] => 0.00
                                                            [CommissionEarned] => 46.5
                                                            [PLBEarned] => 30.07
                                                            [TdsOnCommission] => 2.325
                                                            [TdsOnPLB] => 1.5035
                                                            [AgentCommission] => 76.57
                                                            [AgentTdsOnCommision] => 3.829
                                                        )

                                                    [pax_breakup] => Array
                                                        (
                                                        )

                                                )

                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [journey_number] => onward
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [date_time] => 2019-03-27T14:35:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 14:35:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 14:35:00
                                                                                    [FDTV] => 1552986300
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [date_time] => 2019-03-27T15:35:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 15:35:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 15:35:00
                                                                                    [FATV] => 1552989900
                                                                                )

                                                                            [duration_seconds] => 3600
                                                                            [duration] => 1 Hr 
                                                                            [OperatorCode] => 6E
                                                                            [OperatorName] => Indigo
                                                                            [FlightNumber] => 237
                                                                            [is_leg] => 
                                                                            [operator_class] => X
                                                                            [CabinClass] => X
                                                                            [class] => Array
                                                                                (
                                                                                    [name] => Economy
                                                                                )

                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 Kg
                                                                                    [CabinBaggage] => 7 Kg
                                                                                    [AvailableSeats] => 1
                                                                                )

                                                                            [fare_info_ref] => H7MeSm3R2BKAQxyvAAAAAA==
                                                                            [fare_basis] => 
                                                                            [booking_code] => X
                                                                        )

                                                                )

                                                        )

                                                )

                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => false
                                                    [AirlineRemark] => 
                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*2*_*OyCM5PfipbqXuYkS
                                            [booking_source] => PTBSID0000000007
                                            [token_key] => af2868c735216f8d2854bfce0ae1e181
                                        )

                                    [2] => Array
                                        (
                                            [Price] => Array
                                                (
                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [PassengerCount] => 1
                                                                    [BasePrice] => 1550
                                                                    [Tax] => 747
                                                                    [TotalPrice] => 2297
                                                                )

                                                        )

                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2297
                                                    [PriceBreakup] => Array
                                                        (
                                                            [Tax] => 747
                                                            [BasicFare] => 1550
                                                            [YQValue] => 0.00
                                                            [CommissionEarned] => 46.5
                                                            [PLBEarned] => 30.07
                                                            [TdsOnCommission] => 2.325
                                                            [TdsOnPLB] => 1.5035
                                                            [AgentCommission] => 76.57
                                                            [AgentTdsOnCommision] => 3.829
                                                        )

                                                    [pax_breakup] => Array
                                                        (
                                                        )

                                                )

                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [journey_number] => onward
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [date_time] => 2019-03-27T17:05:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 17:05:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 17:05:00
                                                                                    [FDTV] => 1552995300
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [date_time] => 2019-03-27T18:10:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 18:10:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 18:10:00
                                                                                    [FATV] => 1552999200
                                                                                )

                                                                            [duration_seconds] => 3900
                                                                            [duration] => 1 Hr 5 Mins 
                                                                            [OperatorCode] => 6E
                                                                            [OperatorName] => Indigo
                                                                            [FlightNumber] => 7221
                                                                            [is_leg] => 
                                                                            [operator_class] => X
                                                                            [CabinClass] => X
                                                                            [class] => Array
                                                                                (
                                                                                    [name] => Economy
                                                                                )

                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 Kg
                                                                                    [CabinBaggage] => 7 Kg
                                                                                    [AvailableSeats] => 1
                                                                                )

                                                                            [fare_info_ref] => H7MeSm3R2BKAAxyvAAAAAA==
                                                                            [fare_basis] => 
                                                                            [booking_code] => X
                                                                        )

                                                                )

                                                        )

                                                )

                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => false
                                                    [AirlineRemark] => 
                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*3*_*LQxtPLdGuRlcI4TM
                                            [booking_source] => PTBSID0000000007
                                            [token_key] => f79a778459c240b793403d31e5bbbe2a
                                        )

                                    [3] => Array
                                        (
                                            [Price] => Array
                                                (
                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [PassengerCount] => 1
                                                                    [BasePrice] => 1550
                                                                    [Tax] => 747
                                                                    [TotalPrice] => 2297
                                                                )

                                                        )

                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2297
                                                    [PriceBreakup] => Array
                                                        (
                                                            [Tax] => 747
                                                            [BasicFare] => 1550
                                                            [YQValue] => 0.00
                                                            [CommissionEarned] => 46.5
                                                            [PLBEarned] => 30.07
                                                            [TdsOnCommission] => 2.325
                                                            [TdsOnPLB] => 1.5035
                                                            [AgentCommission] => 76.57
                                                            [AgentTdsOnCommision] => 3.829
                                                        )

                                                    [pax_breakup] => Array
                                                        (
                                                        )

                                                )

                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [journey_number] => onward
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [date_time] => 2019-03-27T19:20:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 19:20:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 19:20:00
                                                                                    [FDTV] => 1553003400
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [date_time] => 2019-03-27T20:20:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 20:20:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 20:20:00
                                                                                    [FATV] => 1553007000
                                                                                )

                                                                            [duration_seconds] => 3600
                                                                            [duration] => 1 Hr 
                                                                            [OperatorCode] => 6E
                                                                            [OperatorName] => Indigo
                                                                            [FlightNumber] => 729
                                                                            [is_leg] => 
                                                                            [operator_class] => X
                                                                            [CabinClass] => X
                                                                            [class] => Array
                                                                                (
                                                                                    [name] => Economy
                                                                                )

                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 Kg
                                                                                    [CabinBaggage] => 7 Kg
                                                                                    [AvailableSeats] => 1
                                                                                )

                                                                            [fare_info_ref] => H7MeSm3R2BKAIxyvAAAAAA==
                                                                            [fare_basis] => 
                                                                            [booking_code] => X
                                                                        )

                                                                )

                                                        )

                                                )

                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => false
                                                    [AirlineRemark] => 
                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*4*_*3fVZhIGVtZ0U2ypk
                                            [booking_source] => PTBSID0000000007
                                            [token_key] => 72ed18cbd9f3f7c0debd87bc67bcd531
                                        )

                                    [4] => Array
                                        (
                                            [Price] => Array
                                                (
                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [PassengerCount] => 1
                                                                    [BasePrice] => 1550
                                                                    [Tax] => 747
                                                                    [TotalPrice] => 2297
                                                                )

                                                        )

                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2297
                                                    [PriceBreakup] => Array
                                                        (
                                                            [Tax] => 747
                                                            [BasicFare] => 1550
                                                            [YQValue] => 0.00
                                                            [CommissionEarned] => 46.5
                                                            [PLBEarned] => 30.07
                                                            [TdsOnCommission] => 2.325
                                                            [TdsOnPLB] => 1.5035
                                                            [AgentCommission] => 76.57
                                                            [AgentTdsOnCommision] => 3.829
                                                        )

                                                    [pax_breakup] => Array
                                                        (
                                                        )

                                                )

                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [journey_number] => onward
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [date_time] => 2019-03-27T20:25:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 20:25:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 20:25:00
                                                                                    [FDTV] => 1553007300
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [date_time] => 2019-03-27T21:40:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 21:40:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 21:40:00
                                                                                    [FATV] => 1553011800
                                                                                )

                                                                            [duration_seconds] => 4500
                                                                            [duration] => 1 Hr 15 Mins 
                                                                            [OperatorCode] => 6E
                                                                            [OperatorName] => Indigo
                                                                            [FlightNumber] => 7223
                                                                            [is_leg] => 
                                                                            [operator_class] => X
                                                                            [CabinClass] => X
                                                                            [class] => Array
                                                                                (
                                                                                    [name] => Economy
                                                                                )

                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 Kg
                                                                                    [CabinBaggage] => 7 Kg
                                                                                    [AvailableSeats] => 1
                                                                                )

                                                                            [fare_info_ref] => H7MeSm3R2BKAYxyvAAAAAA==
                                                                            [fare_basis] => 
                                                                            [booking_code] => X
                                                                        )

                                                                )

                                                        )

                                                )

                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => false
                                                    [AirlineRemark] => 
                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*5*_*gTNbtHjnEDg7Ya7f
                                            [booking_source] => PTBSID0000000007
                                            [token_key] => 0f5cf1f205683d3d873f7f8852fe534c
                                        )

                                    [5] => Array
                                        (
                                            [Price] => Array
                                                (
                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [PassengerCount] => 1
                                                                    [BasePrice] => 1681
                                                                    [Tax] => 758
                                                                    [TotalPrice] => 2439
                                                                )

                                                        )

                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2439
                                                    [PriceBreakup] => Array
                                                        (
                                                            [Tax] => 758
                                                            [BasicFare] => 1681
                                                            [YQValue] => 0.00
                                                            [CommissionEarned] => 50.43
                                                            [PLBEarned] => 32.6114
                                                            [TdsOnCommission] => 2.5215
                                                            [TdsOnPLB] => 1.63057
                                                            [AgentCommission] => 83.041
                                                            [AgentTdsOnCommision] => 4.152
                                                        )

                                                    [pax_breakup] => Array
                                                        (
                                                        )

                                                )

                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [journey_number] => onward
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [date_time] => 2019-03-27T00:05:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 00:05:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 00:05:00
                                                                                    [FDTV] => 1552934100
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [date_time] => 2019-03-27T01:00:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 01:00:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 01:00:00
                                                                                    [FATV] => 1552937400
                                                                                )

                                                                            [duration_seconds] => 3300
                                                                            [duration] => 55 Mins 
                                                                            [OperatorCode] => 6E
                                                                            [OperatorName] => Indigo
                                                                            [FlightNumber] => 829
                                                                            [is_leg] => 
                                                                            [operator_class] => X
                                                                            [CabinClass] => X
                                                                            [class] => Array
                                                                                (
                                                                                    [name] => Economy
                                                                                )

                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 Kg
                                                                                    [CabinBaggage] => 7 Kg
                                                                                    [AvailableSeats] => 1
                                                                                )

                                                                            [fare_info_ref] => H7MeSm3R2BKAoxyvAAAAAA==
                                                                            [fare_basis] => 
                                                                            [booking_code] => X
                                                                        )

                                                                )

                                                        )

                                                )

                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => false
                                                    [AirlineRemark] => 
                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*6*_*JxHKnLK6BtGPUpxF
                                            [booking_source] => PTBSID0000000007
                                            [token_key] => add6d3562c2cf2191207eb9db8642834
                                        )

                                    [6] => Array
                                        (
                                            [Price] => Array
                                                (
                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [PassengerCount] => 1
                                                                    [BasePrice] => 1681
                                                                    [Tax] => 758
                                                                    [TotalPrice] => 2439
                                                                )

                                                        )

                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2439
                                                    [PriceBreakup] => Array
                                                        (
                                                            [Tax] => 758
                                                            [BasicFare] => 1681
                                                            [YQValue] => 0.00
                                                            [CommissionEarned] => 50.43
                                                            [PLBEarned] => 32.6114
                                                            [TdsOnCommission] => 2.5215
                                                            [TdsOnPLB] => 1.63057
                                                            [AgentCommission] => 83.041
                                                            [AgentTdsOnCommision] => 4.152
                                                        )

                                                    [pax_breakup] => Array
                                                        (
                                                        )

                                                )

                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [journey_number] => onward
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [date_time] => 2019-03-27T06:25:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 06:25:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 06:25:00
                                                                                    [FDTV] => 1552956900
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [date_time] => 2019-03-27T07:15:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 07:15:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 07:15:00
                                                                                    [FATV] => 1552959900
                                                                                )

                                                                            [duration_seconds] => 3000
                                                                            [duration] => 50 Mins 
                                                                            [OperatorCode] => 6E
                                                                            [OperatorName] => Indigo
                                                                            [FlightNumber] => 233
                                                                            [is_leg] => 
                                                                            [operator_class] => X
                                                                            [CabinClass] => X
                                                                            [class] => Array
                                                                                (
                                                                                    [name] => Economy
                                                                                )

                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 Kg
                                                                                    [CabinBaggage] => 7 Kg
                                                                                    [AvailableSeats] => 2
                                                                                )

                                                                            [fare_info_ref] => H7MeSm3R2BKA4xyvAAAAAA==
                                                                            [fare_basis] => 
                                                                            [booking_code] => X
                                                                        )

                                                                )

                                                        )

                                                )

                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => false
                                                    [AirlineRemark] => 
                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*7*_*RoOQzQOpkKo9Ccuh
                                            [booking_source] => PTBSID0000000007
                                            [token_key] => a83a182c073cc61cfbc10272556601fb
                                        )

                                    [7] => Array
                                        (
                                            [Price] => Array
                                                (
                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [PassengerCount] => 1
                                                                    [BasePrice] => 1681
                                                                    [Tax] => 758
                                                                    [TotalPrice] => 2439
                                                                )

                                                        )

                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2439
                                                    [PriceBreakup] => Array
                                                        (
                                                            [Tax] => 758
                                                            [BasicFare] => 1681
                                                            [YQValue] => 0.00
                                                            [CommissionEarned] => 50.43
                                                            [PLBEarned] => 32.6114
                                                            [TdsOnCommission] => 2.5215
                                                            [TdsOnPLB] => 1.63057
                                                            [AgentCommission] => 83.041
                                                            [AgentTdsOnCommision] => 4.152
                                                        )

                                                    [pax_breakup] => Array
                                                        (
                                                        )

                                                )

                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [journey_number] => onward
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [date_time] => 2019-03-27T09:15:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 09:15:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 09:15:00
                                                                                    [FDTV] => 1552967100
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [date_time] => 2019-03-27T10:15:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 10:15:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 10:15:00
                                                                                    [FATV] => 1552970700
                                                                                )

                                                                            [duration_seconds] => 3600
                                                                            [duration] => 1 Hr 
                                                                            [OperatorCode] => 6E
                                                                            [OperatorName] => Indigo
                                                                            [FlightNumber] => 541
                                                                            [is_leg] => 
                                                                            [operator_class] => X
                                                                            [CabinClass] => X
                                                                            [class] => Array
                                                                                (
                                                                                    [name] => Economy
                                                                                )

                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 Kg
                                                                                    [CabinBaggage] => 7 Kg
                                                                                    [AvailableSeats] => 1
                                                                                )

                                                                            [fare_info_ref] => H7MeSm3R2BKAwxyvAAAAAA==
                                                                            [fare_basis] => 
                                                                            [booking_code] => X
                                                                        )

                                                                )

                                                        )

                                                )

                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => false
                                                    [AirlineRemark] => 
                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*8*_*VccNhiNKPgvvjVxy
                                            [booking_source] => PTBSID0000000007
                                            [token_key] => 19b35194792fc66f3092b2912834c414
                                        )

                                    [8] => Array
                                        (
                                            [Price] => Array
                                                (
                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [PassengerCount] => 1
                                                                    [BasePrice] => 1681
                                                                    [Tax] => 758
                                                                    [TotalPrice] => 2439
                                                                )

                                                        )

                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2439
                                                    [PriceBreakup] => Array
                                                        (
                                                            [Tax] => 758
                                                            [BasicFare] => 1681
                                                            [YQValue] => 0.00
                                                            [CommissionEarned] => 50.43
                                                            [PLBEarned] => 32.6114
                                                            [TdsOnCommission] => 2.5215
                                                            [TdsOnPLB] => 1.63057
                                                            [AgentCommission] => 83.041
                                                            [AgentTdsOnCommision] => 4.152
                                                        )

                                                    [pax_breakup] => Array
                                                        (
                                                        )

                                                )

                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [journey_number] => onward
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [date_time] => 2019-03-27T12:30:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 12:30:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 12:30:00
                                                                                    [FDTV] => 1552978800
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [date_time] => 2019-03-27T13:25:00.000+05:30
                                                                                    [DateTime] => 2019-03-27 13:25:00
                                                                                    [date] => 2019-03-27
                                                                                    [time] => 13:25:00
                                                                                    [FATV] => 1552982100
                                                                                )

                                                                            [duration_seconds] => 3300
                                                                            [duration] => 55 Mins 
                                                                            [OperatorCode] => 6E
                                                                            [OperatorName] => Indigo
                                                                            [FlightNumber] => 389
                                                                            [is_leg] => 
                                                                            [operator_class] => X
                                                                            [CabinClass] => X
                                                                            [class] => Array
                                                                                (
                                                                                    [name] => Economy
                                                                                )

                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 Kg
                                                                                    [CabinBaggage] => 7 Kg
                                                                                    [AvailableSeats] => 2
                                                                                )

                                                                            [fare_info_ref] => H7MeSm3R2BKAAyyvAAAAAA==
                                                                            [fare_basis] => 
                                                                            [booking_code] => X
                                                                        )

                                                                )

                                                        )

                                                )

                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => false
                                                    [AirlineRemark] => 
                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*9*_*U4OrWmC8Qg2ekn0J
                                            [booking_source] => PTBSID0000000007
                                            [token_key] => 65430285a4dc7815f753da723544590a
                                        )

                                    [9] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 17:15:00
                                                                                    [FDTV] => 1552995900
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-27 18:25:00
                                                                                    [FATV] => 1553000100
                                                                                )

                                                                            [OperatorCode] => SG
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => SpiceJet
                                                                            [FlightNumber] => 1233
                                                                            [CabinClass] => B
                                                                            [Duration] => 70
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 7 KG
                                                                                    [AvailableSeats] => 1
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2983.68
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 2250
                                                            [Tax] => 733.68
                                                            [AgentCommission] => 131.29
                                                            [AgentTdsOnCommision] => 6.565
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 2250
                                                                    [Tax] => 733.68
                                                                    [TotalPrice] => 2983.68
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*10*_*7So0B9PMBUrR3fER
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 1
                                                    [AirlineRemark] => this is a test from aditya.
                                                )

                                        )

                                    [10] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 22:00:00
                                                                                    [FDTV] => 1553013000
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-27 22:45:00
                                                                                    [FATV] => 1553015700
                                                                                )

                                                                            [OperatorCode] => SG
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => SpiceJet
                                                                            [FlightNumber] => 3310
                                                                            [CabinClass] => B
                                                                            [Duration] => 45
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 7 KG
                                                                                    [AvailableSeats] => 1
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 2983.68
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 2250
                                                            [Tax] => 733.68
                                                            [AgentCommission] => 131.29
                                                            [AgentTdsOnCommision] => 6.565
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 2250
                                                                    [Tax] => 733.68
                                                                    [TotalPrice] => 2983.68
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*11*_*9kEG9JJYivQCojIp
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 1
                                                    [AirlineRemark] => this is a test from aditya.
                                                )

                                        )

                                    [11] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 07:30:00
                                                                                    [FDTV] => 1552960800
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-27 08:25:00
                                                                                    [FATV] => 1552964100
                                                                                )

                                                                            [OperatorCode] => SG
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => SpiceJet
                                                                            [FlightNumber] => 3302
                                                                            [CabinClass] => C
                                                                            [Duration] => 55
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 7 KG
                                                                                    [AvailableSeats] => 5
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 3351.68
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 2600
                                                            [Tax] => 751.68
                                                            [AgentCommission] => 151.71
                                                            [AgentTdsOnCommision] => 7.586
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 2600
                                                                    [Tax] => 751.68
                                                                    [TotalPrice] => 3351.68
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*12*_*4R0pNMzyQXt6RcTg
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 1
                                                    [AirlineRemark] => this is a test from aditya.
                                                )

                                        )

                                    [12] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 12:05:00
                                                                                    [FDTV] => 1552977300
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-27 13:05:00
                                                                                    [FATV] => 1552980900
                                                                                )

                                                                            [OperatorCode] => SG
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => SpiceJet
                                                                            [FlightNumber] => 3425
                                                                            [CabinClass] => C
                                                                            [Duration] => 60
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 7 KG
                                                                                    [AvailableSeats] => 5
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 3351.68
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 2600
                                                            [Tax] => 751.68
                                                            [AgentCommission] => 151.71
                                                            [AgentTdsOnCommision] => 7.586
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 2600
                                                                    [Tax] => 751.68
                                                                    [TotalPrice] => 3351.68
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*13*_*Hut52kgXRMX9bU41
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 1
                                                    [AirlineRemark] => this is a test from aditya.
                                                )

                                        )

                                    [13] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 20:25:00
                                                                                    [FDTV] => 1553007300
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-27 21:25:00
                                                                                    [FATV] => 1553010900
                                                                                )

                                                                            [OperatorCode] => SG
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => SpiceJet
                                                                            [FlightNumber] => 3318
                                                                            [CabinClass] => C
                                                                            [Duration] => 60
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 7 KG
                                                                                    [AvailableSeats] => 5
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 3351.68
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 2600
                                                            [Tax] => 751.68
                                                            [AgentCommission] => 151.71
                                                            [AgentTdsOnCommision] => 7.586
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 2600
                                                                    [Tax] => 751.68
                                                                    [TotalPrice] => 3351.68
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*14*_*LMIupEKFz1HCQ7Ix
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 1
                                                    [AirlineRemark] => this is a test from aditya.
                                                )

                                        )

                                    [14] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 07:00:00
                                                                                    [FDTV] => 1552959000
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-27 09:40:00
                                                                                    [FATV] => 1552968600
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 810
                                                                            [CabinClass] => E
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 5
                                                                                )

                                                                        )

                                                                    [1] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-27 19:55:00
                                                                                    [FDTV] => 1553005500
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-27 22:40:00
                                                                                    [FATV] => 1553015400
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 835
                                                                            [CabinClass] => W
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 9
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 12845.24
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 11600
                                                            [Tax] => 1245.24
                                                            [AgentCommission] => 0
                                                            [AgentTdsOnCommision] => 0
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 11600
                                                                    [Tax] => 1245.24
                                                                    [TotalPrice] => 12845.24
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*15*_*IO6nvdujASSTEspa
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 
                                                    [AirlineRemark] => 
                                                )

                                        )

                                    [15] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 21:10:00
                                                                                    [FDTV] => 1553010000
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-28 00:05:00
                                                                                    [FATV] => 1552934100
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 814
                                                                            [CabinClass] => E
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 8
                                                                                )

                                                                        )

                                                                    [1] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-28 07:30:00
                                                                                    [FDTV] => 1552960800
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-28 10:25:00
                                                                                    [FATV] => 1552971300
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 833
                                                                            [CabinClass] => W
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 9
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 12845.24
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 11600
                                                            [Tax] => 1245.24
                                                            [AgentCommission] => 0
                                                            [AgentTdsOnCommision] => 0
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 11600
                                                                    [Tax] => 1245.24
                                                                    [TotalPrice] => 12845.24
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*16*_*bC9ZavJ7P3cOnbAJ
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 
                                                    [AirlineRemark] => 
                                                )

                                        )

                                    [16] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 09:50:00
                                                                                    [FDTV] => 1552969200
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-27 12:35:00
                                                                                    [FATV] => 1552979100
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 812
                                                                            [CabinClass] => Q
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 7
                                                                                )

                                                                        )

                                                                    [1] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-27 19:55:00
                                                                                    [FDTV] => 1553005500
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-27 22:40:00
                                                                                    [FATV] => 1553015400
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 835
                                                                            [CabinClass] => W
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 9
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 14473.24
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 13150
                                                            [Tax] => 1323.24
                                                            [AgentCommission] => 0
                                                            [AgentTdsOnCommision] => 0
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 13150
                                                                    [Tax] => 1323.24
                                                                    [TotalPrice] => 14473.24
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*17*_*ZPE3eDrdlomQk9p7
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 1
                                                    [AirlineRemark] => 
                                                )

                                        )

                                    [17] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 11:30:00
                                                                                    [FDTV] => 1552975200
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-27 14:10:00
                                                                                    [FATV] => 1552984800
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 816
                                                                            [CabinClass] => Q
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 9
                                                                                )

                                                                        )

                                                                    [1] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-27 19:55:00
                                                                                    [FDTV] => 1553005500
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-27 22:40:00
                                                                                    [FATV] => 1553015400
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 835
                                                                            [CabinClass] => W
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 9
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 14473.24
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 13150
                                                            [Tax] => 1323.24
                                                            [AgentCommission] => 0
                                                            [AgentTdsOnCommision] => 0
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 13150
                                                                    [Tax] => 1323.24
                                                                    [TotalPrice] => 14473.24
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*18*_*kmjQMNceM9lvblgf
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 1
                                                    [AirlineRemark] => 
                                                )

                                        )

                                    [18] => Array
                                        (
                                            [FlightDetails] => Array
                                                (
                                                    [Details] => Array
                                                        (
                                                            [0] => Array
                                                                (
                                                                    [0] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => BLR
                                                                                    [CityName] => Bangalore
                                                                                    [AirportName] => Bangalore
                                                                                    [DateTime] => 2019-03-27 16:00:00
                                                                                    [FDTV] => 1552991400
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-27 18:35:00
                                                                                    [FATV] => 1553000700
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 820
                                                                            [CabinClass] => Q
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 9
                                                                                )

                                                                        )

                                                                    [1] => Array
                                                                        (
                                                                            [Origin] => Array
                                                                                (
                                                                                    [AirportCode] => DEL
                                                                                    [CityName] => Delhi
                                                                                    [AirportName] => Delhi
                                                                                    [DateTime] => 2019-03-27 19:55:00
                                                                                    [FDTV] => 1553005500
                                                                                )

                                                                            [Destination] => Array
                                                                                (
                                                                                    [AirportCode] => MAA
                                                                                    [CityName] => Chennai
                                                                                    [AirportName] => Chennai
                                                                                    [DateTime] => 2019-03-27 22:40:00
                                                                                    [FATV] => 1553015400
                                                                                )

                                                                            [OperatorCode] => UK
                                                                            [DisplayOperatorCode] => 
                                                                            [OperatorName] => Air Vistara
                                                                            [FlightNumber] => 835
                                                                            [CabinClass] => W
                                                                            [Duration] => 0
                                                                            [Attr] => Array
                                                                                (
                                                                                    [Baggage] => 15 KG
                                                                                    [CabinBaggage] => 
                                                                                    [AvailableSeats] => 9
                                                                                )

                                                                        )

                                                                )

                                                        )

                                                )

                                            [Price] => Array
                                                (
                                                    [Currency] => INR
                                                    [TotalDisplayFare] => 14683.24
                                                    [PriceBreakup] => Array
                                                        (
                                                            [BasicFare] => 13350
                                                            [Tax] => 1333.24
                                                            [AgentCommission] => 0
                                                            [AgentTdsOnCommision] => 0
                                                        )

                                                    [PassengerBreakup] => Array
                                                        (
                                                            [ADT] => Array
                                                                (
                                                                    [BasePrice] => 13350
                                                                    [Tax] => 1333.24
                                                                    [TotalPrice] => 14683.24
                                                                    [PassengerCount] => 1
                                                                )

                                                        )

                                                )

                                            [ResultToken] => 25301cf894d55aaf6a85c646d9f7f6e4*_*19*_*1HUOERedBgoKJ2an
                                            [Attr] => Array
                                                (
                                                    [IsRefundable] => 1
                                                    [AirlineRemark] => 
                                                )

                                        )

                                )

                        )

                )

        )

)
