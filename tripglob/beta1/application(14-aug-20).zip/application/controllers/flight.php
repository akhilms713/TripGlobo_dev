<?php
ob_start();
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if (session_status() == PHP_SESSION_NONE) { session_start(); } 
error_reporting(0);
class FLight extends CI_Controller {
	//DO : Setting Current website url in session, Purpose : For keeping the page on login/logout.
	public function __construct(){
		parent::__construct();
		$current_url 	= $_SERVER['QUERY_STRING'] ? '?'.$_SERVER['QUERY_STRING'] : '';
        $current_url 	= WEB_URL.$this->uri->uri_string(). $current_url;
		$url 			= array('continue' => $current_url);
		$this->perPage 	= 100000;
        $this->session->set_userdata($url);   
        $this->load->model('Home_Model');
		$this->load->model('Flight_Model');   
        $this->load->model('cart_model');
        $this->load->model('booking_model');  
        $this->load->model('email_model');  
		$this->load->library('encrypt');
        $this->load->library('session');
        $this->load->library('flight/amedus_xml_to_array');
        $this->load->library('flight/xml_to_array');
        $this->load->library('Ajax_pagination'); 
       	$this->load->helper('flight/amedus_helper');
       	$this->load->helper('flight/tbo_helper');
       	$this->curr_val=1;

	}

    
    public function index(){
        $request 			= $this->input->get();
		$data['req'] 		= json_decode(json_encode($request));
		$data['request'] 	= base64_encode(json_encode($request));

		//$this->load->view(PROJECT_THEME.'/flight/results_calender', $data);

		// print_r($data); exit;
		if ($request['type'] == "M") {
// 			$this->load->view(PROJECT_THEME.'/flight/results', $data);
		} else if ($request['destination'] != $request['origin']) {
			$this->load->view(PROJECT_THEME.'/flight/results', $data);
		} else {
			//redirect('home');
		}    
	}
	
	public function search(){
        $request 	= $this->input->get(); 
        //echo '<pre>';print_r($request);exit();
        $insert_report['search_type'] = 'FLIGHT';
		$insert_report['trip_type'] = $request['trip_type'];
		$insert_report['cehck_from'] = $request['from'];
       	$insert_report['cehck_to'] = $request['to'];
       	$insert_report['cehck_both'] = $request['from'].' - '.$request['to'];

        $search_report_data = $this->custom_db->insert_record('search_report',$insert_report);
        if($request['trip_type']==''){
        	$request['trip_type']='round';
        }

     	if($request['trip_type']=="oneway"){
     		$request['depature'] = date('d-m-Y',strtotime($request['depature']));
     	}
     	if($request['trip_type']=="round"){
     		//$data1=explode('-',$request['round_val']);
     		$request['depature'] = date('d-m-Y',strtotime($request['depature']));
     		$request['return']   = date('d-m-Y',strtotime($request['return']));
     	}

		if($request['trip_type']=="oneway"){         
			$tday_get=date('d-m-Y');
			$dep_get_now=strtotime($request['depature']);
			$tday_get_now=strtotime($tday_get);

			if($dep_get_now < $tday_get_now)
			{
			   redirect(WEB_URL,'refresh');
			}
		}

        if($request['trip_type']=="round"){         
			$dep_get=strtotime($request['depature']);
			$ret_get=strtotime($request['return']);

			if($dep_get > $ret_get)
			{
			   redirect(WEB_URL,'refresh');
			}
		}

		if(trim($request['trip_type'])!='M' && $request['trip_type'] != 'multicity'){
			
				if($request['depature']){
		       		$request['depature'] = date('d-m-Y',strtotime($request['depature']));
		       	}
		       	if($request['return']){
		       		$request['return']= date('d-m-Y',strtotime($request['return']));
		       	}
		       
		       $insert_data['search_data'] = json_encode($request);
		       $insert_data['search_type'] = 'FLIGHT';

		        
		        $search_insert_data = $this->custom_db->insert_record('search_history',$insert_data);
		        $request['type']=$request['trip_type'];
		        $return_date = '';$isdomstic='';
		        $dep_check=explode("-",$request['depature']);
			    $deppp    = 		count($dep_check);	
					if(($request['type'])=="round"){
						$ret_check=explode("-",$request['return']);
						$rett     =count($ret_check);
					}	
				$from_aircode=explode('(',$request['from']);
				$to_aircode=explode('(',$request['to']);
				$cehck_from=count($from_aircode);
				$cehck_to=count($to_aircode);

				
					if(($request['from'])==($request['to'])){			
						redirect(WEB_URL,'refresh');
					}elseif(($request['depature'])==""){
						redirect(WEB_URL,'refresh');
					}elseif(($request['depature'])!="" && $deppp!="3"){

						redirect(WEB_URL,'refresh');
					}
					elseif($request['type']=="oneway" && $request['depature']==""){		
						redirect(WEB_URL,'refresh');
					}
					elseif(($request['type'])=="round" && $request['depature']=="" || $request['type']=="round" && $request['return']==""){	
						redirect(WEB_URL,'refresh');
					}
					else if(((($request['type'])=="") || ($request['depature']=="") ||  ($deppp!="3")) || ((($request['type'])=="") && ($request['depature']=="") && ($deppp!="3") && ($rett!="3") && ($request['return']==""))){
						redirect(WEB_URL,'refresh');
					}
					elseif((($request['from'])=="") || (($request['to'])=="")) {	
						redirect(WEB_URL,'refresh');
					}
					elseif(($request['adult']) + ($request['child'])>9) {
						redirect(WEB_URL,'refresh');
					}
					elseif(($request['adult'] =="" )|| ($request['child'] == "") || ($request['infant'] == "") ||($request['class2'] == "")) {
						redirect(WEB_URL,'refresh');
					}
					elseif($cehck_from!=2 || $cehck_to !=2){
						redirect(WEB_URL,'refresh');
					}
			if($request['trip_type'] == 'oneway'){
				$type 	= 'type=oneway';   
			}else if($request['trip_type'] == 'round'){
				$type 	= 'type=round'; $return_date = '&return_date='.$request['return'];
			}
				$from_aircode=substr(chop(substr($request['from'], -5), ')'), -3);
				$country_name=$this->Flight_Model->getcountry_name($from_aircode);
				$from_country=$country_name->country;
				$to_aircode=substr(chop(substr($request['to'], -5), ')'), -3);
				$country_name=$this->Flight_Model->getcountry_name($to_aircode);
				$to_country=$country_name->country;
				

				$isdomstic=0;
				if($request['airlines']!="0" && $request['airlines']!="" ){
					$airline=$request['airlines'];	
				}else{
					$airline='';	
				}
				 

			 	$query 	= $type.'&origin='.substr(chop(substr($request['from'], -5), ')'), -3).'&destination='.substr(chop(substr($request['to'], -5), ')'), -3).'&depart_date='.$request['depature'].$return_date.'&ADT='.$request['adult'].'&CHD='.$request['child'].'&INF='.$request['infant'].'&class='.$request['class2'].'&is_domestic='.$isdomstic.'&airline='.$airline.'&search_id='.$search_insert_data['insert_id'].'&flexible='.$request['flexible'];

		 	redirect(WEB_URL.'flight/?'.$query);  
	 	}else if($request['trip_type'] == 'multicity' || trim($request['trip_type']) =='M'){
            $type = 'type=M';
            $multi = json_decode(json_encode($this->input->get()));		
			foreach ($multi->from_m as $key => $value) {
				$origin[] = substr(chop(substr($value, -5), ')'), -3);
				$destination[] = substr(chop(substr($multi->to_m[$key], -5), ')'), -3);
				$depature[] = $multi->depature_m[$key];
			}
			$origin1 = substr(chop(substr($origin[0], -5), ')'), -3);
			$max_coun=count($destination)-1;
			$destination1 = substr(chop(substr($destination[$max_coun], -5), ')'), -3);
			$depature1=$depature[0];
				//airline wise search 
				if($request['airlines']!="0" && $request['airlines']!="" ){
					$airline=$request['airlines'];
				}else{
					$airline='';	
				}
			$multicity = array(
				'type' => 'M',
				'flexible' => '0',
				'origin' => $origin1,
				'destination' => $destination1,
				'depart_date' => $depature1,
				'origin_m' => $origin,
				'destination_m' => $destination,
				'depart_date_m' => $depature,
				'ADT' => $request['adult'],
				'CHD' => $request['child'],
				'INF' => $request['infant'],
				'class' => $request['class'],
				'airline' => $request['airline'], 
				'max_stop' => $request['max_stop'], 
				'departure_time' => $request['departure_time'], 
				'arrival_time' => $request['arrival_time'], 
				'connection_location' => $request['connection_location'], 
			);	
			$query = http_build_query($multicity);					
			redirect(WEB_URL.'flight/?'.$query);
		}
    }

        public function add_days_todate(){
		
		$get_data = $this->input->get();

		 $request_data = json_decode(base64_decode($get_data['search_request']), true);
		if($request_data['type'] == 'oneway'){
			$new_date = trim($get_data['new_date']);
			$request_data['depart_date'] = date('d-m-Y', strtotime($new_date));//Adding new Date
			$day_diff = $this->get_date_difference($request_data['depart_date'], $new_date);
			if(isset($safe_search_data['return'])) {
				$request_data['return'] = $this->add_days_to_date($day_diff, $request_data['return_date']);//Check it
			}
			$query = http_build_query($request_data);	
			redirect('flight/?'.$query);
		}

	}

	function get_date_difference($date1, $date2)
	{
		$date1 = strtotime($date1);
		$date2 = strtotime($date2);
		return floor(($date2-$date1)/(60*60*24));
	}

	function add_days_to_date($days, $date='')
		{
			if (empty($date) == true) {
				$date = date('d-m-Y');
			}
			return date('d-m-Y H:i:s', strtotime($date.' +'.$days.' day'));;
		}


    public function GetResults($Req_before_decode = ''){	
		$data['request'] 			= $search_request =  json_decode(base64_decode($Req_before_decode));
		$rand_id 					= md5(time() . rand() . crypt(time()));
		$xml_response 				= $this->Flight_Model->insertInputParameters($search_request,$rand_id);
    	$session_data_main= $data['session_data'] = $session_data = $this->generate_rand_no().date("mdHis");
		//$session_data_main= $data['session_data'] = $session_data ="GSGORC134B0ZWWSI9NPZOHSN0604215359";

		$api_name= "";
	    $active_api=$this->Flight_Model->get_api_list_flight();
		for($ai=0;$ai<count($active_api);$ai++){
				$api_name= $active_api[$ai]->api_name;
				//$api_name='AMADEUS';


	 if($api_name =='AMADEUS'){	
		/* $Amedus_LowFareSearchRes  = Fare_MasterPricerTravelBoard_calenderSearchReq($search_request,$xml_response);
		$results 				    = $this->renderApiResponse_calender($Amedus_LowFareSearchRes['Fare_MasterPricerTravelBoard_calenderSearch_Res'],$rand_id);

		exit("test");
		$snd_data['results']=$results;
		$snd_data['search_request']=$search_request;
		$this->Flight_Model->save_result($results,$session_data,$search_request,$api_name,$api_id1);
		$snd_data['flight_result'] = $this->Flight_Model->get_last_response($session_data,array('limit'=>$this->perPage));
		$dataresult['result1']=$this->load->view(PROJECT_THEME.'/flight/calender_search',$snd_data,true);
		echo json_encode($dataresult); exit();*/
		$Amedus_LowFareSearchRes = Fare_MasterPricerTravelBoardSearchReq($search_request,$xml_response);
        $results 				 = $this->renderApiResponse($Amedus_LowFareSearchRes['Fare_MasterPricerTravelBoardSearchRes'],$rand_id);	
       	if($results){
			$new_flight_arr =array();
			$i=0;
			foreach ($results as $r_key => $r_value) {
				
				if(isset($search_request->preferred_airline) && !empty($search_request->preferred_airline) && $search_request->preferred_airline!='All'){
					
					if($search_request->preferred_airline==$r_value['FlightDetails'][0]['airlineName'][0]){
						$include_flight = true;
						foreach ($r_value['FlightDetails'] as $f_key => $f_value) {					
								foreach($f_value['locationIdArival'] as $l_key=>$l_value){
		                            if((@$f_value['locationIdDeparture'][$l_key+1]!=null) && @$f_value['locationIdDeparture'][$l_key+1] != $l_value){
							           $include_flight = false;             
			                        }
			                    }		                    
						}
						if($include_flight){
							$new_flight_arr[$i]['FlightDetailsID'] =$i; 
							$new_flight_arr[$i]['FlightDetails'] = $r_value['FlightDetails'];
							$new_flight_arr[$i]['PricingDetails'] = $r_value['PricingDetails'];
		                    $new_flight_arr[$i]['paxFareProduct'] = $r_value['paxFareProduct'];
							$i++;
						}else{}
					}
				}else{
					$include_flight = true;
						foreach ($r_value['FlightDetails'] as $f_key => $f_value) {					
							//if(valid_array($r_value['FlightDetails'] )){
								foreach($f_value['locationIdArival'] as $l_key=>$l_value){
		                                   
			                        if((@$f_value['locationIdDeparture'][$l_key+1]!=null) && @$f_value['locationIdDeparture'][$l_key+1] != $l_value){
			                           $include_flight = false;             
			                   }
			                }
						}
						if($include_flight){
							$new_flight_arr[$i]['FlightDetailsID'] =$i; 
							$new_flight_arr[$i]['FlightDetails'] = $r_value['FlightDetails'];
							$new_flight_arr[$i]['PricingDetails'] = $r_value['PricingDetails'];
		                    $new_flight_arr[$i]['paxFareProduct'] = $r_value['paxFareProduct'];
							$i++;
						}else{
							//echo "not_incl"."<br/>";
						}
				}

			}
			$results = $new_flight_arr;			
		}	
		$data['paxFareProduct'] = $results['paxFareProduct']['paxFareDetail'];
		$dataresult['session_data']	=$session_data_main;
		$this->Flight_Model->save_result($results,$session_data,$search_request,$api_name);
	}elseif($api_name =='TBO'){
		$token_row = get_token();
		$token_data=json_decode($token_row);
		$_SESSION['token']=$token_data;
		$tt=$_SESSION['token'];
		$results = SearchReq_Res($search_request,$tt);
		$dataresult['session_data']	=$session_data_main;
		$this->Flight_Model->save_result_tbo($results,$session_data,$search_request,$api_name);
		}	
	}
		$flight_data						= $this->Flight_Model->get_last_response_data($session_data);
		$flight_data1						= $this->Flight_Model->get_arival_data_data($session_data);
		if ($api_name == 'AMADEUS' ) {
			$arival_data						= json_decode($flight_data1['low_flight']->segment_data);	
			$dataresult['ArrivalDate']          = $arival_data[0]->ArrivalDate[0];
		}

		$level_markup='B2C';
		$user_type = $this->session->userdata('user_type');
		if($user_type==B2B_USER){
			$user_id = $this->session->userdata('user_id');
    	    $level_markup='B2B';
     	}
     	$start_date = date('Y-m-d',strtotime($search_req->depart_date));
     	if ($search_req->depart_date == "Roundtrip") {
     		$end_date  = date('Y-m-d',strtotime($search_req->return_date));
     	}
          
     	$total_flight_price = $flight_data['result_data']->min_rate;
        $dataresult['min_rate'] 			=  floor((float)$flight_data['result_data']->min_rate * $this->curr_val);
		$total_flight_price = $flight_data['result_data']->max_rate;
        $dataresult['max_rate'] 			=  ceil((float)$flight_data['result_data']->max_rate * $this->curr_val);
		$data['airline_data'] 				= $flight_data['airline_data'];
		$data['connecting_airports_filter'] = $flight_data['connecting_airports_filter'];
		$dataresult['stops_0min_rate'] 		= floor( (float) $flight_data['stops_0']->min_rate * $this->curr_val);
		$dataresult['stops_1min_rate'] 		= floor( (float) $flight_data['stops_1']->min_rate * $this->curr_val);
		$dataresult['stops_multimin_rate'] 	= floor( (float) $flight_data['stops_multi']->min_rate * $this->curr_val);
		$data['flight_count'] 				=  $flight_data['result_data']->flight_count;
		$totalRec 							=  $flight_data['result_data']->flight_count;
		$config['first_link']  				= 'First';
		$config['div']        				= 'flightsdata'; //parent div tag id
		$config['base_url']    				= WEB_URL.'flight/ajaxPaginationData/'.$session_data;
		$config['total_rows']  				= $totalRec;
		$config['per_page']    				= $this->perPage;
		$this->ajax_pagination->initialize($config);
		$airlinematrixdata= $AirlineFilter = '';
		foreach($flight_data['airline_data'] as $airlinematrix){
			
					$airlinematrixdata .= '<div class="item">
							<a class="pricedates" id='.str_replace(" ","_",$airlinematrix->airline).'>
								<div class="imgemtrx_plusmin">
									<img src="https://c.fareportal.com/n/common/air/ai/'.$airlinematrix->airline_code.'.gif"  alt=""/>
								 </div>
							   <div class="alsmtrx"><strong>'.$airlinematrix->airline.'</strong><span class="mtrxprice">'.$this->display_icon.' '.number_format(($airlinematrix->min_rate * $this->curr_val), 2).'</span></div>
							 </a>
						  </div>';
									
		}
		$data['flight_result'] = $this->Flight_Model->get_last_response($session_data,array('limit'=>$this->perPage));
		if(!$data['flight_result']){
			$data['message'] = "No Result Found"; 
		}
		$dataresult['airlinematrix'] = $airlinematrixdata;
		$dataresult['AirlineFilter'] = $AirlineFilter;
        $data['Req_before_decode'] =$Req_before_decode;
        $data['all_results'] = $results;        
        $data['search_id'] = $search_request->search_id;
        $data['session_id'] = $session_data;
       // echo "<pre/>";print_r($data);exit();
			$dataresult['result'] =  $this->load->view(PROJECT_THEME.'/flight/ajax_result',$data,true);
       
		
		echo json_encode($dataresult);
    }

    function calculate_time_zone_duration($ddate,$adate,$dep_zone,$arv_zone){
		$ddate = str_replace("T"," ",$ddate); $adate = str_replace("T"," ",$adate);
		$Change_clock=($arv_zone)-($dep_zone);
		if(!is_int($Change_clock)){
			$Changeclock	= explode(".", $Change_clock);
			$Changeclock0	= $Changeclock[0];
			if($Changeclock0 > 0){
				$Changeclock1 	= ($Changeclock[1]*6);
			}else{
				$Changeclock1 	= (-1 * $Changeclock[1]*6);
			}
		}else{
			$Changeclock0	= $Change_clock;
			$Changeclock1	= 0;
		}		
		// echo $ddate." ".$dep_zone." ".$adate." ".$arv_zone." ".$Changeclock0." ".$Changeclock1."<br/>";
		$date_a 	= new DateTime($ddate);
		$date_b 	= new DateTime($adate);
		$interval 	= date_diff($date_a, $date_b);
		$hour 		= $interval->format('%h');
		$min 		= $interval->format('%i');
		$day1		= $interval->format('%d');
		$dur_in_min = ((($hour * 60) + $min) - (($Changeclock0 * 60) + $Changeclock1));
		$hour 		= FLOOR($dur_in_min / 60);
		$min 		= $dur_in_min%60;
		// echo '<pre/>';print_r($interval);
		if($hour<0){  $hour=((24)+($hour)); $day1 		-= 1;
		}else{
			$day1 		+= floor(((($hour * 60) + $min) / 1440));
		}
		if($min<0){ $min=((60)+($min)); }
		$hours 		= floor((($hour * 60) + $min) / 60);
		$minutes	= ((($hour * 60) + $min) % 60);
		
		if($hours>24){ $hours=($hours % 24);}
		if ($day1 > 0)
			$dur=$day1."d ".$hours."h ".$minutes."m";
		else
			$dur=$hours."h ".$minutes."m";
		return $dur;
				
	} 
	function renderApiResponse($SearchResponse,$rand_id){
		$flight_result = $this->xml2array($SearchResponse);

        $flightResult = array(); $currency = '';        
        if (!isset($_SESSION[$rand_id])) {
            // OneWay, RoundTrip, and MultiCity Module
            if (!isset($flight_result['soapenv:Envelope']['soapenv:Body']['Fare_MasterPricerTravelBoardSearchReply']['errorMessage'])) {
                if (isset($flight_result['soapenv:Envelope']['soapenv:Body']['Fare_MasterPricerTravelBoardSearchReply']))
                    $flightResult = $flight_result['soapenv:Envelope']['soapenv:Body']['Fare_MasterPricerTravelBoardSearchReply'];
            }   
        }else{
            // Calendar Module
            if (!isset($flight_result['soapenv:Envelope']['soapenv:Body']['Fare_MasterPricerCalendarReply']['errorMessage'])) {
                if (isset($flight_result['soapenv:Envelope']['soapenv:Body']['Fare_MasterPricerCalendarReply']))
                    $flightResult = $flight_result['soapenv:Envelope']['soapenv:Body']['Fare_MasterPricerCalendarReply'];
            }
        }

        $flightIndex1 = array(); $flightIndex = array();
        // debug($flightResult['recommendation']);die;
        if($flightResult){
            $currency = $flightResult['conversionRate']['conversionRateDetail']['currency'];
            // To Check the JourneyType: Oneway Or Roundtrip or Multicity or Calendar
            $flightIndex1 = $flightResult['flightIndex'];

            if(!isset($flightIndex1[0]))
                $flightIndex[0] = $flightIndex1;
            else
                $flightIndex = $flightIndex1;
            	$flightIndexCount = count($flightIndex);
            for ($i = 0; $i < $flightIndexCount; $i++){ // No of Flight Records Loop
                $groupOfFlights = $flightIndex[$i]['groupOfFlights'];
                $groupOfFlightsCount = count($groupOfFlights);
                for ($f = 0; $f < ($groupOfFlightsCount); $f++) { // To Check the Flight Segment
                    $FlightSegment1 = array(); $FlightSegment = array();
                    $FlightSegment1 = $groupOfFlights[$f]['flightDetails'];

                    if(!isset($FlightSegment1[0]))
                        $FlightSegment[0] = $FlightSegment1;
                    else
                        $FlightSegment = $FlightSegment1;   
                            
                    for ($j = 0; $j < (count($FlightSegment)); $j++) {
                        $flightId                                                               = $groupOfFlights[$f]['propFlightGrDetail']['flightProposal'][0]['ref'];
                        $flightDetails1[$flightId]['Flight'][$i]['flightId']                    = $groupOfFlights[$f]['propFlightGrDetail']['flightProposal'][0]['ref'];
                        
                        $flightDetails1[$flightId]['Flight'][$i]['currency']                    = $currency;
                        $flightDetails1[$flightId]['Flight'][$i]['stops']                       = $j;
                        $flightDetails1[$flightId]['Flight'][$i]['FlightEft']                   = $groupOfFlights[$f]['propFlightGrDetail']['flightProposal'][1]['ref'];
                        $flightDetails1[$flightId]['Flight'][$i]['dateOfDeparture'][$j]         = $departureDate = $FlightSegment[$j]['flightInformation']['productDateTime']['dateOfDeparture'];
                        $flightDetails1[$flightId]['Flight'][$i]['timeOfDeparture'][$j]         = $departureTime = $FlightSegment[$j]['flightInformation']['productDateTime']['timeOfDeparture'];
                        $flightDetails1[$flightId]['Flight'][$i]['dateOfArrival'][$j]           = $arrivalDate = $FlightSegment[$j]['flightInformation']['productDateTime']['dateOfArrival'];
                        $flightDetails1[$flightId]['Flight'][$i]['timeOfArrival'][$j]           = $arrivalTime = $FlightSegment[$j]['flightInformation']['productDateTime']['timeOfArrival'];
                        $flightDetails1[$flightId]['Flight'][$i]['flightOrtrainNumber'][$j]     = $FlightSegment[$j]['flightInformation']['flightOrtrainNumber'];
                        $flightDetails1[$flightId]['Flight'][$i]['marketingCarrier'][$j]        = $FlightSegment[$j]['flightInformation']['companyId']['marketingCarrier'];
                        $flightDetails1[$flightId]['Flight'][$i]['airlineName'][$j]             = $this->Flight_Model->get_airline_name($FlightSegment[$j]['flightInformation']['companyId']['marketingCarrier']);
                        
                        $flightDetails1[$flightId]['Flight'][$i]['DepartureDate'][$j]           = ((substr("$departureDate", 0, -4)) . "-" . (substr("$departureDate", -4, 2)) . "-20" . (substr("$departureDate", -2)));
                        $flightDetails1[$flightId]['Flight'][$i]['ArrivalDate'][$j]             = ((substr("$arrivalDate", 0, -4)) . "-" . (substr("$arrivalDate", -4, 2)) . "-20" . (substr("$arrivalDate", -2)));
                        
                        $flightDetails1[$flightId]['Flight'][$i]['DepartureTime'][$j]           = ((substr("$departureTime", 0, -2)) . ":" . (substr("$departureTime", -2)));
                        $flightDetails1[$flightId]['Flight'][$i]['ArrivalTime'][$j]             = ((substr("$arrivalTime", 0, -2)) . ":" . (substr("$arrivalTime", -2)));
                        
                        $eft_final = str_split($flightDetails1[$flightId]['Flight'][$i]['FlightEft'],2);
                        $flightDetails1[$flightId]['Flight'][$i]['durationFinalEft'] = $eft_final[0]." h ".$eft_final[1]." min";
                       $pp = (($eft_final[0]*60) + $eft_final[1])*60;
                       $pp1=$this->ConvertSectoDay($pp);
                       $flightDetails1[$flightId]['Flight'][$i]['durationFinalEft']= $pp1;
                       // $flightDetails1[$flightId]['Flight'][$i]['total_duration_final']

                        
                        
                        // Red Eye Feature
                        if ((($flightDetails1[$flightId]['Flight'][$i]['timeOfDeparture'][0]) <= "0700") && (($flightDetails1[$flightId]['Flight'][$i]['timeOfArrival'][$j]) >= "2000"))
                            $flightDetails1[$flightId]['Flight'][$i]['redEye'] = "Yes";
                        else
                            $flightDetails1[$flightId]['Flight'][$i]['redEye'] = "No";
                        
                        // Diffrent Airport Feature
                        if ($flightDetails1[$flightId]['Flight'][$i]['marketingCarrier'][0] != $flightDetails1[$flightId]['Flight'][$i]['marketingCarrier'][$j])
                            $flightDetails1[$flightId]['Flight'][$i]['DiffrentAirport'] = "Yes";
                        else
                            $flightDetails1[$flightId]['Flight'][$i]['DiffrentAirport'] = "No";
                        
                        // Short layover Time and Long Layover Time feature
                        if($j != 0)
                        {
                            $departureDateTimeLayover                                       = new DateTime($flightDetails1[$flightId]['Flight'][$i]['DepartureDate'][$j]." ".$flightDetails1[$flightId]['Flight'][$i]['DepartureTime'][$j]);
                            $arrivalDateTimeLayover                                         = new DateTime($flightDetails1[$flightId]['Flight'][$i]['ArrivalDate'][($j-1)]." ".$flightDetails1[$flightId]['Flight'][$i]['ArrivalTime'][($j-1)]);
                            $Layoverinterval                                                = date_diff($arrivalDateTimeLayover,$departureDateTimeLayover);
                            
                            $hour_layover                                                   = $Layoverinterval->format('%h');
                            $min_layover                                                    = $Layoverinterval->format('%i');
                            $dur_in_min_layover                                             = (($hour_layover * 60) + $min_layover);
                            $flightDetails1[$flightId]['Flight'][$i]['LayoverDurationMins'] = $dur_in_min_layover;
                            $flightDetails1[$flightId]['Flight'][$i]['LayoverDurationText'] = $Layoverinterval->format('%h H %i M');
                            $flightDetails1[$flightId]['Flight'][$i]['LayoverDuration'][$j] = $Layoverinterval->format('%h H %i M');
                        }
                        // echo '<pre/>';print_r($FlightSegment[$j]);exit;
                        if(isset($FlightSegment[$j]['flightInformation']['companyId']['operatingCarrier'])){
							$flightDetails1[$flightId]['Flight'][$i]['operatingCarrier'][$j]        = $FlightSegment[$j]['flightInformation']['companyId']['operatingCarrier'];
                        }else{
                            $flightDetails1[$flightId]['Flight'][$i]['operatingCarrier'][$j]    = '';
                        }
                        // echo '<pre/>';print_r($FlightSegment);exit;
                        $flightDetails1[$flightId]['Flight'][$i]['locationIdDeparture'][$j]     = $FlightSegment[$j]['flightInformation']['location'][0]['locationId'];
                        $flightDetails1[$flightId]['Flight'][$i]['locationIdArival'][$j]        = $FlightSegment[$j]['flightInformation']['location'][1]['locationId'];
                        
                        $dep_name                                                               = $this->Flight_Model->get_airport_cityname($flightDetails1[$flightId]['Flight'][$i]['locationIdDeparture'][$j]);
                        $arr_name                                                               = $this->Flight_Model->get_airport_cityname($flightDetails1[$flightId]['Flight'][$i]['locationIdArival'][$j]);
                        if(isset($flightDetails1[$flightId]['Flight'][$i]['DepartureAirport'][$j]))
                        $flightDetails1[$flightId]['Flight'][$i]['DepartureAirport'][$j]        = $dep_name->city.", ".$dep_name->country." (".$dep_name->city_code.")";
                        if(isset($flightDetails1[$flightId]['Flight'][$i]['ArrivalAirport'][$j]))
                        $flightDetails1[$flightId]['Flight'][$i]['ArrivalAirport'][$j]          = $arr_name->city.", ".$arr_name->country." (".$arr_name->city_code.")";
                        
                        $dep_time_zone_offset                                                   = $this->Flight_Model->get_time_zone_details($flightDetails1[$flightId]['Flight'][$i]['locationIdDeparture'][$j]); 
                        $arv_time_zone_offset                                                   = $this->Flight_Model->get_time_zone_details($flightDetails1[$flightId]['Flight'][$i]['locationIdArival'][$j]); 
                        $flightDetails1[$flightId]['Flight'][$i]['dep_time_zone_offset'][$j]    = $dep_time_zone_offset;
                        $flightDetails1[$flightId]['Flight'][$i]['arv_time_zone_offset'][$j]    = $arv_time_zone_offset;
                        
                        $flightDetails1[$flightId]['Flight'][$i]['equipmentType'][$j]           = $FlightSegment[$j]['flightInformation']['productDetail']['equipmentType'];
                        $flightDetails1[$flightId]['Flight'][$i]['electronicTicketing'][$j]     = $FlightSegment[$j]['flightInformation']['addProductDetail']['electronicTicketing'];
                        $flightDetails1[$flightId]['Flight'][$i]['productDetailQualifier'][$j]  = $FlightSegment[$j]['flightInformation']['addProductDetail']['productDetailQualifier'];
                        // Time Zone Related Code
						if(isset($flightDetails1[$flightId]['Flight'][$i]['dep_time_zone_offset'][$j]))
							$dep_zone = explode(":",($flightDetails1[$flightId]['Flight'][$i]['dep_time_zone_offset'][$j]));
						if(isset($flightDetails1[$flightId]['Flight'][$i]['arv_time_zone_offset'][$j]))
							$arv_zone = explode(":",($flightDetails1[$flightId]['Flight'][$i]['arv_time_zone_offset'][$j]));
						
						if($flightId == 2)	{
							// print_r($dep_zone)." ".print_r($arv_zone);exit;
						}
						if(!empty($arv_zone)){
							$Change_clock=(($arv_zone[0].".".$arv_zone[1])-($dep_zone[0].".".$dep_zone[1]));
							if(!is_int($Change_clock)){
								$Changeclock	= explode(".", $Change_clock);
								$Changeclock0	= $Changeclock[0];
								if($Changeclock0 > 0){
									$Changeclock1 	= ($Changeclock[1]*6);
								}else{
									$Changeclock1 	= (-1 * $Changeclock[1]*6);
								}
							}else{
								$Changeclock0	= $Change_clock;
								$Changeclock1	= 0;
							}
						}
                        $ddate = ((substr("$departureDate", 0, -4)) . "-" . (substr("$departureDate", -4, 2)) . "-20" . (substr("$departureDate", -2))) . " " . ((substr("$departureTime", 0, -2)) . ":" . (substr("$departureTime", -2))) . "";;
                        $adate = ((substr("$arrivalDate", 0, -4)) . "-" . (substr("$arrivalDate", -4, 2)) . "-20" . (substr("$arrivalDate", -2))) . " " . ((substr("$arrivalTime", 0, -2)) . ":" . (substr("$arrivalTime", -2))) . "";
                        $date_a = new DateTime($ddate);
                        $date_b = new DateTime($adate);
                        $interval 	= date_diff($date_a, $date_b);
						$hour 		= $interval->format('%h');
						$min 		= $interval->format('%i');
						$day1		= $interval->format('%d');
						$dur_in_min = ((($hour * 60) + $min) - (($Changeclock0 * 60) + $Changeclock1));
						$hour 		= FLOOR($dur_in_min / 60);
						$min 		= $dur_in_min%60;
						
						if($hour<0){ $hour=((24)+($hour)); }
						if($min<0){ $min=((60)+($min)); }
						
						$day 		= floor(((($hour * 60) + $min) / 1440));
						$hours 		= floor((($hour * 60) + $min) / 60);
						$minutes	= ((($hour * 60) + $min) % 60);
						
						if($hours>24){
							$hours=($hours % 24);
						}
                        		
		
                        if ($day1 > 0)
                            $duration_time_zone=$day1." D ".$hours." h ".$minutes." min";
                        else
                            $duration_time_zone=$hours." h ".$minutes." min";
                            
                        $flightDetails1[$flightId]['Flight'][$i]['duration_time_zone'][$j]      = $duration_time_zone;
                        $flightDetails1[$flightId]['Flight'][$i]['Clock_Changes'][$j]           = $Change_clock;
                        $flightDetails1[$flightId]['Flight'][$i]['dur_in_min_time_zone'][$j]    = $dur_in_min;
                  }
                }
            }
           
            $x = 0; $recommendation = array();
            if(isset($flightResult['recommendation'][0]))
                $recommendation                 = $flightResult['recommendation'];
            else
                $recommendation[0]              = $flightResult['recommendation'];
            foreach ($recommendation as $p => $s) {

                if(isset($s['itemNumber']['itemNumberId']['numberType'])){ $price = $p;$flag = "MTK"; }else{$price = 0;$flag = "Normal";}
                $segmentFlightRef = array();
                if(isset($s['segmentFlightRef'][0]))
                    $segmentFlightRef           = $s['segmentFlightRef'];
                else
                    $segmentFlightRef[0]        = $s['segmentFlightRef'];
                // debug($segmentFlightRef);die;
                for ($sfr = 0; $sfr <  (count($segmentFlightRef)); $sfr++) {
                    $referencingDetail = array();
                    if(isset($segmentFlightRef[$sfr]['referencingDetail'][0]))
                        $referencingDetail      = $segmentFlightRef[$sfr]['referencingDetail'];
                    else
                        $referencingDetail[0]   = $segmentFlightRef[$sfr]['referencingDetail'];
                // debug($referencingDetail);die;
                    for ($rd = 0; $rd < (count($referencingDetail)); $rd++) {
                        $refNumber              = $referencingDetail[$rd]['refNumber']."-".$flag."-".$p;
                        $refNumberFlight        = $referencingDetail[$rd]['refNumber'];
                        $refQualifier           = $referencingDetail[$rd]['refQualifier'];
                        
                        if(isset($s['itemNumber']['itemNumberId']['numberType'])){
                            $flightDetails[$refNumber][$price]['PriceInfo']['MultiTicket']          = "Yes";
                            // $flightDetails[$refNumber][$p]['PriceInfo']['MultiTicket_type']      = $s['itemNumber']['itemNumberId']['numberType'];
                            $flightDetails[$refNumber][$price]['PriceInfo']['MultiTicket_number']   = $s['itemNumber']['itemNumberId']['number'];
                        }else{
                            $flightDetails[$refNumber][$price]['PriceInfo']['MultiTicket']          = "No";
                            $flightDetails[$refNumber][$price]['PriceInfo']['MultiTicket_number']   = $s['itemNumber']['itemNumberId']['number'];
                        }
                        
                        // $flightDetails[$refNumber][$price]['baggage_amadeus_APIinfo']['baggage']             = $baggage_amadeus_APIinfo;
                        $flightDetails[$refNumber][$price]['PriceInfo']['refQualifier']             = $refQualifier;
                        $flightDetails[$refNumber][$price]['PriceInfo']['totalFareAmount']          = $s['recPriceInfo']['monetaryDetail'][0]['amount'];
                        $flightDetails[$refNumber][$price]['PriceInfo']['totalTaxAmount']           = $s['recPriceInfo']['monetaryDetail'][1]['amount'];

                        $paxFareProduct = array();
                        if(isset($s['paxFareProduct'][0]))
                            $paxFareProduct             = $s['paxFareProduct'];
                        else
                            $paxFareProduct[0]          = $s['paxFareProduct'];
                        for($pfp = 0; $pfp < (count($paxFareProduct)); $pfp++) {
                            $paxReference = array();
                            if(isset($paxFareProduct[$pfp]['paxReference']['traveller'][0]))
                                $paxReference           = $paxFareProduct[$pfp]['paxReference']['traveller'];
                            else
                                $paxReference[0]        = $paxFareProduct[$pfp]['paxReference']['traveller'];
                            $flightDetails[$refNumber][$price]['PriceInfo']['passengerType'] = $passengerType = $paxFareProduct[$pfp]['paxReference']['ptc'];
                            for($pr = 0; $pr < (count($paxReference)); $pr++) {
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['count']       = ($pr+1);
                            }
                            
                            $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['totalFareAmount']         = $paxFareProduct[$pfp]['paxFareDetail']['totalFareAmount'];
                            $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['totalTaxAmount']          = $paxFareProduct[$pfp]['paxFareDetail']['totalTaxAmount'];
                            if(isset($paxFareProduct[$pfp]['paxFareDetail']['codeShareDetails']['transportStageQualifier'])){
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['transportStageQualifier'] = $paxFareProduct[$pfp]['paxFareDetail']['codeShareDetails']['transportStageQualifier'];
                            }else{
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['transportStageQualifier'] = '';
                            }
                            if(isset($paxFareProduct[$pfp]['paxFareDetail']['codeShareDetails']['company'])){
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['company']                 = $paxFareProduct[$pfp]['paxFareDetail']['codeShareDetails']['company'];
                            }else{
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['company']                 = '';
                            }
                                
                        
                            $fare = array();
                            if(isset($paxFareProduct[$pfp]['fare'][0]))
                                $fare           = $paxFareProduct[$pfp]['fare'];
                            else
                                $fare[0]        = $paxFareProduct[$pfp]['fare'];
                            
                            for($fa = 0; $fa < (count($fare)); $fa++) {
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['fare'][$fa]['description'] = '';  
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['fare'][$fa]['textSubjectQualifier']   = $fare[$fa]['pricingMessage']['freeTextQualification']['textSubjectQualifier'];
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['fare'][$fa]['informationType']        = $fare[$fa]['pricingMessage']['freeTextQualification']['informationType'];
                                $description = array();
                                if(is_array($fare[$fa]['pricingMessage']['description']))
                                    $description            = $fare[$fa]['pricingMessage']['description'];
                                else
                                    $description[0]         = $fare[$fa]['pricingMessage']['description'];
                                $flightDetails[$refNumber][$price]['PriceInfo']['fare'][$fa]['description'] = ''    ;
                                for ($d = 0; $d < count($description); $d++) {
                                    if(isset($description[$d]))
                                        $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['fare'][$fa]['description'] .= $description[$d] . " - ";
                                }
                            }
                            $fareDetails = array();
                            if(isset($paxFareProduct[$pfp]['fareDetails'][0]))
                                $fareDetails            = $paxFareProduct[$pfp]['fareDetails'];
                            else
                                $fareDetails[0]         = $paxFareProduct[$pfp]['fareDetails'];
                            for($fd = 0; $fd < (count($fareDetails)); $fd++) 
                            {
                                $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['flightMtkSegRef']              = $fareDetails[$fd]['segmentRef']['segRef'];
                                $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['designator']           = $fareDetails[$fd]['majCabin']['bookingClassDetails']['designator'];                                   
                                $groupOfFares = array();
                                if(isset($fareDetails[$fd]['groupOfFares'][0]))
                                    $groupOfFares           = $fareDetails[$fd]['groupOfFares'];
                                else
                                    $groupOfFares[0]        = $fareDetails[$fd]['groupOfFares'];
                                for($gf = 0; $gf < (count($groupOfFares)); $gf++) 
                                {
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['rbd'][$gf]         = $groupOfFares[$gf]['productInformation']['cabinProduct']['rbd'];
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['cabin'][$gf]       = $groupOfFares[$gf]['productInformation']['cabinProduct']['cabin'];
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['avlStatus'][$gf]   = $groupOfFares[$gf]['productInformation']['cabinProduct']['avlStatus'];
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['breakPoint'][$gf]  = $groupOfFares[$gf]['productInformation']['breakPoint'];
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['fareType'][$gf]    = $groupOfFares[$gf]['productInformation']['fareProductDetail']['fareType'];
                                }
                            }
                        }
                    }
                }
            }
            // debug($referencingDetail);die;
            
            foreach ($recommendation as $p => $s) {
                         // debug($s);die;
                if(isset($s['itemNumber']['itemNumberId']['numberType'])) { $price = $p;$flag = "MTK"; }else{ $price = 0;$flag = "Normal"; }
                $segmentFlightRef = array();
                if(isset($s['segmentFlightRef'][0]))
                    $segmentFlightRef           = $s['segmentFlightRef'];
                else
                    $segmentFlightRef[0]        = $s['segmentFlightRef'];
                for ($sfr = 0; $sfr <  (count($segmentFlightRef)); $sfr++) {
                    $referencingDetail = array();
                    if(isset($segmentFlightRef[$sfr]['referencingDetail'][0]))
                        $referencingDetail      = $segmentFlightRef[$sfr]['referencingDetail'];
                    else
                        $referencingDetail[0]   = $segmentFlightRef[$sfr]['referencingDetail'];
                    for ($rd = 0; $rd < (count($referencingDetail)); $rd++) {
                        $refNumber              = $referencingDetail[$rd]['refNumber']."-".$flag."-".$p;
                        $refNumberFlight        = $referencingDetail[$rd]['refNumber'];
                        $refQualifier           = $referencingDetail[$rd]['refQualifier'];
                        $baggage_amadeus_info = '';
                        $baggage_amadeus_APIinfo = '';
                        if ($refQualifier == 'B') {
                        	// debug($flightResult['serviceFeesGrp']['freeBagAllowanceGrp']);die;
                        	// $baggage_amadeus_info = $flightResult['serviceFeesGrp']['freeBagAllowanceGrp'];
                        	if (isset($flightResult['serviceFeesGrp']['freeBagAllowanceGrp'][0])) {
                        		$baggage_amadeus_info = $flightResult['serviceFeesGrp']['freeBagAllowanceGrp'];
                        	} else {
                        		$baggage_amadeus_info[0] = $flightResult['serviceFeesGrp']['freeBagAllowanceGrp'];
                        	}
                        	foreach ($baggage_amadeus_info as $abkey => $abvalue) {
                        		// debug($rd);
                        		// debug($refNumberFlight);
                        		// debug($abvalue);die;
                        		if ($abvalue['itemNumberInfo']['itemNumberDetails']['number'] == $refNumberFlight) {
                        			if ($abvalue['freeBagAllownceInfo']['baggageDetails']['quantityCode'] == 'W') {
                        				if ($abvalue['freeBagAllownceInfo']['baggageDetails']['freeAllowance'] > 1) {
                        					 $FinalResult[$x]['FlightDetails'][0]['baggage'][$abkey] = $abvalue['freeBagAllownceInfo']['baggageDetails']['freeAllowance']." Kgs";
                        				} else {
                        					 $FinalResult[$x]['FlightDetails'][0]['baggage'][$abkey] = $abvalue['freeBagAllownceInfo']['baggageDetails']['freeAllowance']." Kg";
                        				}
                        				
                        			} else {
                        				if ($abvalue['freeBagAllownceInfo']['baggageDetails']['freeAllowance'] > 1) {
                        					 $FinalResult[$x]['FlightDetails'][0]['baggage'][$abkey] = $abvalue['freeBagAllownceInfo']['baggageDetails']['freeAllowance']." Pieces";
                        				} else {
                        					 $FinalResult[$x]['FlightDetails'][0]['baggage'][$abkey] = $abvalue['freeBagAllownceInfo']['baggageDetails']['freeAllowance']." Piece";
                        				}
                        			}
                        			
                        		}
                        	}
                        	
                        }
                        $FinalResult[$x]['FlightDetailsID']     = $x;
                        $FinalResult[$x]['FlightDetails'][$rd]  = $flightDetails1[$refNumberFlight]['Flight'][$rd];
                        // $FinalResult[$x]['FlightDetails'][$rd]['baggage']  = $baggage_amadeus_APIinfo;
                    }
                    
                    $priceDetailsfinal = array();
                    foreach($flightDetails[$refNumber] as $price)
                        $priceDetailsfinal[] = $price;
                    
                    $FinalResult[$x]['PricingDetails']      = $priceDetailsfinal;
                    
                    if (!isset($s['paxFareProduct'][0])) {
                    	$paxFareProduct[0] = $s['paxFareProduct'];
                    } else {
                    	$paxFareProduct = $s['paxFareProduct'];
                    }
                    $FinalResult[$x]['paxFareProduct'] = $paxFareProduct;                    
                    $specificRecDetails ='';

              

                    if (!empty($s['specificRecDetails'])){

                    	   if(isset($s['specificRecDetails'][0]))
			                    $specificRecDetails1           = $s['specificRecDetails'][0];
			                else
			                    $specificRecDetails1       = $s['specificRecDetails'];
					

                    	//$detail = base_64encode($s['specificRecDetails']);
			                //    echo "recommendation11<pre>"; print_r($s['specificRecDetails']); echo "</pre>"; 

                    	   if(isset($specificRecDetails1['specificProductDetails'][0]))
			                    $specificRecDetails12          = $specificRecDetails1['specificProductDetails'][0] ;
			                else
			                    $specificRecDetails12       = $specificRecDetails1['specificProductDetails'];

			              
                    	$specificRecDetails = $specificRecDetails12['fareContextDetails']['cnxContextDetails']['0']['fareCnxInfo']['contextDetails']['availabilityCnxType'];

                    	$FinalResult[$x]['specificRecDetails'] = $specificRecDetails;

                    	   					/*echo "<pre>";
                    	                   	print_r ($FinalResult[$x]);
                    	                   	echo "</pre>";exit("1272");   */             	

                    }

                    
                    $x++;
                }
            }
        }else{
        	//if there is no result
        	$FinalResult = array();
        }

        	// echo "asdfg<pre>"; print_r($FinalResult); echo "</pre>"; exit("1285");
        
        return $data['flight_result'] = $FinalResult;
    }


    function ConvertSectoDay($n){ 
    $dt1 = new DateTime("@0");
 	$dt2 = new DateTime("@$n");
 	return $dt1->diff($dt2)->format('%a d: %h h: %i m');
   }


    function xml2array($xmlStr, $get_attributes = 1, $priority = 'tag'){
        //print_r($xmlStr);die();
        // I renamed $url to $xmlStr, $url was the first parameter in the method if you
        // want to load from a URL then rename $xmlStr to $url everywhere in this method
        $contents = "";
        if (!function_exists('xml_parser_create')) {
            return array();
        }
        $parser = xml_parser_create('');
        
        xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8");
        xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
        xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
        xml_parse_into_struct($parser, trim($xmlStr), $xml_values);
        xml_parser_free($parser);
        if (!$xml_values)
            return; //Hmm...
        //echo "<pre>"; print_r($xml_values); echo "</pre>";  die();
        $xml_array = array();
        $parents = array();
        $opened_tags = array();
        $arr = array();
        $current = & $xml_array;
        $repeated_tag_index = array();
        foreach ($xml_values as $data) {
            unset($attributes, $value);
            //echo "<pre>"; print_r($get_attributes); echo "</pre>";  die();
            extract($data);
            $result = array();
            $attributes_data = array();
            if (isset($value)) {
                if ($priority == 'tag')
                    $result = $value;
                else
                    $result['value'] = $value;
            }
            if (isset($attributes) and $get_attributes) {
                foreach ($attributes as $attr => $val) { 
                    if ($priority == 'tag')
                        $attributes_data[$attr] = $val;
                    else
                        $result['attr'][$attr] = $val; //Set all the attributes in a array called 'attr'
                }
            }
            if ($type == "open") {
                $parent[$level - 1] = & $current; 
                if (!is_array($current) or (!in_array($tag, array_keys($current)))) {
                    $current[$tag] = $result;
                    if ($attributes_data)
                        $current[$tag . '_attr'] = $attributes_data;
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    $current = & $current[$tag];
                }
                else {
                    if (isset($current[$tag][0])) {
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                        $repeated_tag_index[$tag . '_' . $level]++;
                    } else {
                        $current[$tag] = array(
                            $current[$tag],
                            $result
                        );
                        $repeated_tag_index[$tag . '_' . $level] = 2;
                        if (isset($current[$tag . '_attr'])) {
                            $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                            unset($current[$tag . '_attr']);
                        }
                    }
                    $last_item_index = $repeated_tag_index[$tag . '_' . $level] - 1;
                    $current = & $current[$tag][$last_item_index];
                }
            } elseif ($type == "complete") {
                if (!isset($current[$tag])) {
                    $current[$tag] = $result;
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    if ($priority == 'tag' and $attributes_data)
                        $current[$tag . '_attr'] = $attributes_data;
                }
                else {
                    if (isset($current[$tag][0]) and is_array($current[$tag])) {
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                        if ($priority == 'tag' and $get_attributes and $attributes_data) {
                            $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                        }
                        $repeated_tag_index[$tag . '_' . $level]++;
                    } else {
                        $current[$tag] = array(
                            $current[$tag],
                            $result
                        );
                        $repeated_tag_index[$tag . '_' . $level] = 1;
                        if ($priority == 'tag' and $get_attributes) {
                            if (isset($current[$tag . '_attr'])) {
                                $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                                unset($current[$tag . '_attr']);
                            }
                            if ($attributes_data) {
                                $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                            }
                        }
                        $repeated_tag_index[$tag . '_' . $level]++; //0 and 1 index is already taken
                    }
                }
            } elseif ($type == 'close') {
                $current = & $parent[$level - 1];
            }
        }
        //echo "<pre>"; print_r($xml_array); echo "</pre>";  die();
        return ($xml_array);
    }

	function dateformatAMD($dateval,$timeval){  
		$day=substr($dateval,0,2);  
		$mon=substr($dateval,2,2);
		$year="20".substr($dateval,4,2);
		$hour=substr($timeval,0,2); 
		$min=substr($timeval,2,2);
		$newdate=$year.'-'.$mon.'-'.$day.'T'.$hour.':'.$min.':00';
		return $newdate;
	}
	function show_flight_details_ajax_calender() {
		$flightdetails  = $this->input->post('flightdetails');
		$flight_id  = $this->input->post('flight_id');
		$rand_id  = $this->input->post('rand_id');
		$search_id  = $this->input->post('search_id');
		
		
		$data['flight_details'] = json_decode(base64_decode($flightdetails),1);
		$data['flight_id_details'] = json_decode(base64_decode($flight_id),1);
		$data['flight_data'] = $flightdetails;
		$data['flight_id_data'] = $flight_id;
		$data['rand_id'] = $rand_id;
		$data['search_id'] = $search_id;
		// echo "<pre/>";print_r($data);exit();
		
		$flight = $this->load->view(PROJECT_THEME.'/flight/ajax_flight_details_calender',$data,true);
		echo ($flight);
	}
	function call_iternary($idval){
		$data['result'] = $this->Flight_Model->get_flight_data_segments($idval);
		$data['request_scenario'] = json_decode($data['result']->request_scenario);
		$data['idval'] = $idval;

		$segment_data = $data['result']->segment_data;
		$PricingDetails = $data['result']->PricingDetails;
		
		$fare_rule_xml_res = Get_Fare_Rule1($segment_data,$PricingDetails);


		echo "<pre/>";print_r($data);exit("1019");







		if(true){
			$fare_details = json_decode($data['result']->all_results,true);
		        $fare_rule_data['origin'] = $data['result']->origin;
		        $fare_rule_data['destination'] = $data['result']->destination;
		        $fare_rule_data['date'] = date("dmy");
		        if(array_key_exists("company",$fare_details[0]['paxFareDetail']['codeShareDetails']))
		            $fare_rule_data['carrier'] = $fare_details[0]['paxFareDetail']['codeShareDetails']['company'];
		        else
		            $fare_rule_data['carrier'] = $fare_details[0]['paxFareDetail']['codeShareDetails'][0]['company'];

				$fare_rule_data['farebasis'] = $fare_details[0]['fareDetails'][0]['groupOfFares'][0]['productInformation']['fareProductDetail']['fareBasis'];
		        if(!array_key_exists("groupOfFares",$fare_details[0]['fareDetails'])){
		            if(!array_key_exists("productInformation",$fare_details[0]['fareDetails'][0]['groupOfFares']))
		                $fare_rule_data['farebasis'] = $fare_details[0]['fareDetails'][0]['groupOfFares'][0]['productInformation']['fareProductDetail']['fareBasis'];
		            else
		                $fare_rule_data['farebasis'] = $fare_details[0]['fareDetails'][0]['groupOfFares']['productInformation']['fareProductDetail']['fareBasis'];
		        }
		        else{
		            if(!array_key_exists("productInformation",$fare_details[0]['fareDetails'][0]['groupOfFares']))
		                $fare_rule_data['farebasis'] = $fare_details[0]['fareDetails']['groupOfFares'][0]['productInformation']['fareProductDetail']['fareBasis'];
		            else
		                $fare_rule_data['farebasis'] = $fare_details[0]['fareDetails']['groupOfFares']['productInformation']['fareProductDetail']['fareBasis'];
		        }
				$fare_rule_xml_res = Get_Fare_Rule($fare_rule_data);
		        $fare_rule_details = $this->render_fare_rule_response($this->xml2array($fare_rule_xml_res['FareRule_SearchRes']));
		        $data['fare_rule_details'] = $fare_rule_details;
				$this->load->view(PROJECT_THEME.'/flight/flight_details',$data);
			}
		
	}





/*Tbo New start */
	function call_iternary_t($idval){
		$data['result'] = $this->Flight_Model->get_flight_data_segments($idval);
		$data['request_scenario'] = json_decode($data['result']->request_scenario);
		$data['idval'] = $idval;


		if(true){
			$fare_details = json_decode($data['result']->all_results,true);
			//$farerule_data=fare_rule_t($fare_details['TokenId'],$fare_details['TraceId'],$fare_details['ResultIndex']);
			$f1='{"Response":{"Error":{"ErrorCode":0,"ErrorMessage":""},"FareRules":[{"Airline":"AI","DepartureTime":"2020-08-22T03:50:00","Destination":"LHR","FareBasisCode":"LE6MBLR","FareRestriction":"","FareRuleDetail":"FareBasisCode: LE6MBLR 0.  APPLICATION AND OTHER CONDITIONS RULE - 004\/INUK UNLESS OTHERWISE SPECIFIED IN UK YEAR ROUND FARES  APPLICATION    AREA      THESE FARES APPLY      FROM INDIA TO EUROPE.    CLASS OF SERVICE      THESE FARES APPLY FOR FIRST\/BUSINESS\/ECONOMY CLASS      SERVICE.    TYPES OF TRANSPORTATION      THIS RULE GOVERNS ONE-WAY AND ROUND-TRIP FARES.      FARES GOVERNED BY THIS RULE CAN BE USED TO CREATE      ONE-WAY\/ROUND-TRIP\/CIRCLE-TRIP\/OPEN-JAW\/SINGLE OPEN-      JAW\/DOUBLE OPEN-JAW JOURNEYS.  CAPACITY LIMITATIONS    THE CARRIER SHALL LIMIT THE NUMBER OF PASSENGERS CARRIED    ON ANY ONE FLIGHT AT FARES GOVERNED BY THIS RULE AND SUCH    FARES WILL NOT NECESSARILY BE AVAILABLE ON ALL FLIGHTS.    THE NUMBER OF SEATS WHICH THE CARRIER SHALL MAKE    AVAILABLE ON A GIVEN FLIGHT WILL BE DETERMINED BY THE    CARRIERS BEST JUDGMENT  OTHER CONDITIONS    ORIGIN AND DESTINATION ADDONS BUILT    DEL\/BOM\/AMD\/BLR-LHR AND DEL-BHX 4.  FLIGHT APPLICATION FOR -BLR TYPE FARES   THE FARE COMPONENT MUST NOT BE ON       ONE OR MORE OF THE FOLLOWING         BA FLIGHTS 510 THROUGH 524         BA FLIGHTS 1500 THROUGH 1999         BA FLIGHTS 2290 THROUGH 2539         BA FLIGHTS 2800 THROUGH 2899         BA FLIGHTS 3000 THROUGH 3269         BA FLIGHTS 3300 THROUGH 7019         BA FLIGHTS 7026 THROUGH 8035         BA FLIGHTS 8200 THROUGH 8449         BA FLIGHTS 8498 THROUGH 8699         BA FLIGHTS 8770 THROUGH 9999.   AND   IF THE FARE COMPONENT INCLUDES TRAVEL WITHIN DOMESTIC   SECTORS IN INDIA       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT.          NOTE -           RBDS FOR DOMESTIC TRAVEL IN INDIA           FOR ECONOMY CLASS - K           NO UPSELLS PERMITTED           --------------------------------------------------           FOR EXECUTIVE CLASS           REQUIRED WHEN AVAILABLE - D           PERMITTED - C           REQUIRED - Y           --------------------------------------------------           FOR FIRST CLASS           REQUIRED WHEN AVAILABLE - F\/A\/C\/D           REQUIRED - Y   AND   IF THE FARE COMPONENT INCLUDES TRAVEL BETWEEN   INTERNATIONAL SECTORS IN INDIA AND AREA 3       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT OPERATED BY AI.   AND   IF THE FARE COMPONENT INCLUDES TRAVEL BETWEEN INDIA AND   EUROPE       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT OPERATED BY AI.   AND   IF THE FARE COMPONENT INCLUDES TRAVEL WITHIN EUROPE       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY BA FLIGHT OPERATED BY BA.          NOTE -           RBDS AND UPSELL CHARGES ON BA           BA RBD FOR AI ECO CLASS RBD E\/S\/T\/U\/L\/G\/W\/V\/Q\/K  -            N           BA UPSELL FOR AI ECO CLASS RBD           E\/S\/T\/U\/L\/G\/W\/V\/Q\/K           N TO V INR 2200 OW \/ INR 4400 RT           ---------------------           BA RBD FOR AI ECO CLASS RBD H\/M\/B\/Y  - N           BA UPSELL FOR AI ECO CLASS RBD H\/M\/B\/Y           N TO V INR 2200 OW \/ INR 4400 RT           V TO B INR 11000 OW \/ INR 22000 RT.           ------------            BA RBD FOR AI EXE CLASS RBD C\/D\/J\/Z  - D            NO UPSELLS PERMITTED 5.  ADVANCE RES\/TICKETING UNLESS OTHERWISE SPECIFIED   NOTE - GENERAL RULE DOES NOT APPLY   RESERVATIONS ARE REQUIRED FOR ALL SECTORS. 7.  MAXIMUM STAY FOR -6M TYPE FARES   TRAVEL FROM LAST STOPOVER MUST BE COMPLETED NO LATER THAN   6 MONTHS AFTER DEPARTURE FROM FARE ORIGIN. 8.  STOPOVERS UNLESS OTHERWISE SPECIFIED   UNLIMITED STOPOVERS PERMITTED ON THE PRICING UNIT AT       INR 2500 EACH. 9.  TRANSFERS UNLESS OTHERWISE SPECIFIED   UNLIMITED TRANSFERS PERMITTED ON THE PRICING UNIT     FARE BREAK AND EMBEDDED SURFACE SECTORS NOT PERMITTED ON      THE FARE COMPONENT. 10. PERMITTED COMBINATIONS UNLESS OTHERWISE SPECIFIED    APPLICABLE ADD-ON CONSTRUCTION IS ADDRESSED IN    MISCELLANEOUS PROVISIONS - CATEGORY 23.   END-ON-END     END-ON-END COMBINATIONS PERMITTED WITH AI DOMESTIC     FARES. VALIDATE ALL FARE COMPONENTS. SIDE TRIPS NOT     PERMITTED.    PROVIDED -      COMBINATIONS ARE WITH ANY Y-\/B-\/M- TYPE FARES FOR      CARRIER AI WITHIN ALL DOMESTIC SECTORS IN INDIA   IF THE FARE COMPONENT INCLUDES TRAVEL WITHIN INDIA       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT.   OPEN JAWS\/ROUND TRIPS\/CIRCLE TRIPS     FARES MAY BE COMBINED ON A HALF ROUND TRIP BASIS     -TO FORM SINGLE OR DOUBLE OPEN JAWS WHICH CONSISTS OF NO      MORE THAN 2 INTERNATIONAL FARE COMPONENTS AND THE OPEN      SEGMENT AT ORIGIN MUST BE IN ONE COUNTRY. THE OPEN      SEGMENT AT DESTINATION HAS NO RESTRICTIONS.      MILEAGE OF THE OPEN SEGMENT MUST BE EQUAL\/LESS THAN      MILEAGE OF THE SHORTEST FLOWN FARE COMPONENT.     -TO FORM ROUND TRIPS\/CIRCLE TRIPS.    PROVIDED -      COMBINATIONS ARE WITH ANY FARE FOR CARRIER AI IN ANY       RULE IN TARIFF       IPRA    - USA\/CANADA-AREA 2\/3 AND GUAM-AREA 2 VIA                 ATLANTIC       IPRAI   - BETWEEN THE USA\/CANADA-AREA 2\/3 VIA ATLANTIC       IPREUAS - BETWEEN EUROPE-AREA 3       IPRFE   - BETWEEN THE RUSSIAN FEDERATION-AREA 3       IPRMEAS - BETWEEN THE MIDDLE EAST-AREA 3. 12. SURCHARGES FOR ROUND TRIP REGULAR EXCURSION FARES   A SURCHARGE OF INR 1000 PER DIRECTION WILL BE ADDED TO THE   APPLICABLE FARE FOR WEEKEND TRAVEL ON FRI\/SAT\/SUN.   AND - A SURCHARGE OF INR 3500 PER DIRECTION WILL BE ADDED         TO THE APPLICABLE FARE FOR TRAVEL FOR A PORTION OF         TRAVEL WITHIN INDIA.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY AI FLIGHT OPERATED BY 9I.   AND - A SURCHARGE OF INR 10000 PER DIRECTION WILL BE ADDED         TO THE APPLICABLE FARE FOR TRAVEL FOR A PORTION OF         TRAVEL WITHIN INDIA.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY AI FLIGHT OPERATED BY IX.   AND - A RBD SURCHARGE OF INR 2200 PER DIRECTION WILL BE         ADDED TO THE APPLICABLE FARE FOR A PORTION OF TRAVEL         WITHIN EUROPE BOOKED IN V.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY BA FLIGHT OPERATED BY BA.   AND - A RBD SURCHARGE OF INR 13200 PER DIRECTION WILL BE         ADDED TO THE APPLICABLE FARE FOR A PORTION OF TRAVEL         WITHIN EUROPE BOOKED IN B.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY BA FLIGHT OPERATED BY BA.   AND - A SURCHARGE OF INR 1500 WILL BE ADDED TO THE         APPLICABLE FARE FOR PEAK TRAVEL FROM 01JAN THROUGH         15JAN. 15. SALES RESTRICTIONS FOR -BLR TYPE FARES   TICKETS MUST BE ISSUED ON AI. 16. PENALTIES FOR L- TYPE FARES   CHANGES     CHARGE INR 6000 FOR REISSUE.          NOTE -           A CHANGE IS A DATE\/FLIGHT\/ROUTING\/BOOKING           MODIFICATION.           --------------------------------------------------           CHARGE APPLIES PER TRANSACTION.           A TRANSACTION MAY INCORPORATE ONE OR MORE           RESERVATION CHANGE IN THE SAME TRANSACTION E.G.           FLIGHT AND DATE CHANGE IN ONE DIRECTION OR BOTH.           --------------------------------------------------           CHARGE APPLIES TO ADULT CHILD AND INFANT           OCCUPYING A SEAT.           INFANT NOT OCCUPYING A SEAT IS EXEMPTED.           --------------------------------------------------           CHARGE 1500 PER SECTOR PER CHANGE IN DOMESTIC           SECTORS IN INDIA OR SAARC - IND V.V. LEG IF IND -           U.K. V.V. SECTORS ARE NOT CHANGED.           --------------------------------------------------           CHANGE FEE DOES NOT APPLY FOR UPGRADE TO A           HIGHER  CABIN CLASS ON THE SAME FLIGHT. ONLY           DIFFERENCE IN FARE AND TAXES TO BE COLLECTED.           IF THE UPGRADE IS WITH A DATE CHANGE CHANGE FEE           ALSO TO BE COLLECTED ALONG WITH DIFFERENCE IN           FARE AND TAXES.           --------------------------------------------------           WHEN NOSHOW TICKET IS PRESENTED FOR REBOOKING           BOTH NOSHOW AND REBOOKING\/REISSUE CHARGES APPLY.           NO SHOW IS WHEN A PAX FAILS TO CHANGE BOOKING           ATLEAST 24 HOURS BEFORE DEPARTURE OF THE FLIGHT           BEING CHANGED.           --------------------------------------------------           TICKET HAS TO BE REISSUED FOR ANY CHANGE           INCLUDING DATE\/FLIGHT\/ROUTING\/BOOKING CHANGE.           --------------------------------------------------           REBOOKING\/REISSUE\/UPGRADING MUST BE MADE IN ONE           TRANSACTION BEFORE DEPARTURE OF THE  FLIGHT BEING           CHANGED.           --------------------------------------------------           REISSUE TO BE DONE BY THE ORIGINAL ISSUING AGENT           OR AI OFFICE ONLY.           --------------------------------------------------           REPRICING SCENARIO -           1.BEFORE DEPARTURE -           IF A COMPLETELY UNUTILIZED TICKET IS BROUGHT FOR           EITHER AN OUTBOUND OR AN INBOUND           SEGMENT\/SECTOR\/FLIGHT           CHANGE THE FARE WILL RE RECALCULATED AS ON DATE           OF REISSUE WITH THE CURRENT FARES\/FARE RULES           BEING APPLICABLE.           2.AFTER DEPARTURE -           IF A PARTIALLY UTILIZED TICKET IS BROUGHT FOR           EITHER AN OUTBOUND OR AN INBOUND           SEGMENT\/SECTOR\/FLIGHT           CHANGE THE FARE WILL RE RECALCULATED AS ON THE           ORIGINAL DATE OF ISSUE WITH THE HISTORICAL FARES           FARES\/FARE RULES BEING APPLICABLE.           --------------------------------------------------           FOR WAIVER OF REISSUE PENALTY ON ACCOUNT OF DEATH           OF PASSENGER OR IMMEDIATE FAMILY MEMBER PLEASE           REFER LAST PAGE           --------------------------------------------------           IF NO SEATS ARE AVAILABLE IN THE SAME RBD AS           TICKETED PASSENGERS MAY BE BOOKED IN THE HIGHER           RBD BY CHARGING DIFFERENCE OF FARE AND TAXES.           DOWNSELLING TO A LOWER RBD IS NOT PERMITTED.           --------------------------------------------------           THE CHANGE\/REISSUE CHARGE PLUS DIFFERENCE IN FARE           AND TAXES WILL APPLY EVEN IF THERE IS A CHANGE OF           DATE\/FLIGHT\/ROUTING\/BOOKING ONLY ON THE           INTERLINING SECTOR.           --------------------------------------------------           WHEN FARES ARE COMBINED THE MOST RESTRICTIVE           CONDITIONS APPLY FOR THE ENTIRE JOURNEY.           --------------------------------------------------           THE CHANGE\/REISSUE CHARGE IS NON - REFUNDABLE.           --------------------------------------------------           CHARGES ARE NON-COMMISISONABLE. APPLICABLE GST           WILL BE ADDITIONAL.           --------------------------------------------------   CANCELLATIONS     CHARGE INR 10000 FOR CANCEL.          NOTE -           CHARGE APPLIES TO ADULT CHILD AND INFANT           OCCUPYING A SEAT.           INFANT NOT OCCUPYING A SEAT IS EXEMPTED.           --------------------------------------------------           WHEN NOSHOW TICKET IS PRESENTED FOR CANCELLATION           BOTH NOSHOW AND CANCELLATION CHARGES APPLY.           NO SHOW IS WHEN A PAX FAILS TO CANCEL BOOKING           ATLEAST 24 HOURS BEFORE DEPARTURE OF THE FLIGHT           BEING CANCELLED.           --------------------------------------------------           FOR WAIVER OF CANCELLATION PENALTY ON ACCOUNT OF           DEATH OF PASSENGER OR IMMEDIATE FAMILY MEMBER P           PLEASE REFER LAST PAGE           --------------------------------------------------           FULL REFUND PERMITTED IN CASE OF REJECTION OF           VISA SUBJECT TO           1. SUBMISSION OF PROPER DOCUMENTS SUCH AS EMBASSY           STATEMENT AT LEAST 14 DAYS BEFORE DEPARTURE.           2. BOTH OUTBOUND AND INBOUND JOURNEY BOOKED IN           RBD G OR ABOVE.           --------------------------------------------------           APPLICABLE PENALTIES TO BE RECOVERED FROM THE           BASIC FARE AND FUEL CHARGE ONLY.           --------------------------------------------------           IN CASES WHERE THE APPLICABLE PENALTIES ARE           HIGHER THAN THE SUM OF THE BASIC FARE AND FUEL           CHARGE ONLY THE BASIC FARE AND FUEL CHARGE WILL           BE FORFEITED.           STATUTORY TAXES E.G. K3 TAX EX INDIA AND OTHER           CHARGES LIKE AIRPORT DEPARTURE TAX ETC.           TO BE REFUNDED IN FULL.           --------------------------------------------------           AGAINST NON - REFUNDABLE TICKETS ONLY THE BASIC           FARE AND FUEL CHARGE TO BE FORFEITED. STATUTORY           TAXES AND OTHER CHARGES ARE REFUNDABLE IN FULL.           --------------------------------------------------           THE CUT-OFF DATE FOR REFUND OF K3 TAX WILL BE           31ST AUGUST YYYY FOR TICKETS ISSUED DURING           FINANCIAL YEAR  01ST APRIL XXXX TO 31ST MARCH           YYYY AND \/ OR  EXCHANGED \/ REISSUED UPTO 31           AUGUST YYYY.           --------------------------------------------------           IN CASE OF PARTIALLY UTILIZED TICKETS CHARGE ONE           WAY FARE OR HALF ROUND TRIP FARE WHICHEVER IS           HIGHER IN THE SAME RBD FOR THE SECTOR UTILISED           PLUS APPLICABLE TAXES.           IF NO ONE WAY FARE EXISTS FOR THE UTILISED SECTOR           IN THE SAME RBD THE NEXT HIGHER RBD WILL APPLY IN           ADDITION TO THE CANCELLATION CHARGE.           --------------------------------------------------           IF AN OUT OF SEQUENCE COUPON IS PRESENTED FOR           REFUND THE ITINERARY TO BE REPRICED AND THE           BALANCE IF ANY MAY BE PROCESSED FOR REFUND AFTER           DEDUCTING APPLICABLE PENALTIES.           --------------------------------------------------           THE CANCELLATION CHARGE WILL APPLY EVEN IF THERE           IS CANCELLATION ONLY OF THE INTERLINING SECTOR.           --------------------------------------------------           WHEN FARES ARE COMBINED THE MOST RESTRICTIVE           CONDITIONS APPLY FOR THE ENTIRE JOURNEY.           --------------------------------------------------           THE CHANGE\/REISSUE CHARGE IS NON - REFUNDABLE.           --------------------------------------------------           CHARGES ARE NON-COMMISISONABLE. APPLICABLE GST           WILL BE ADDITIONAL.           --------------------------------------------------   CHANGES\/CANCELLATIONS     CHARGE INR 9000 FOR NO-SHOW.          NOTE -           NO SHOW IS WHEN A PAX FAILS TO CHANGE\/CANCEL           BOOKING ATLEAST 24 HOURS BEFORE DEPARTURE OF THE           FLIGHT BEING CHANGED\/CANCELLED.           --------------------------------------------------           CHARGE APPLIES TO ADULT CHILD AND INFANT           OCCUPYING A SEAT.           INFANT NOT OCCUPYING A SEAT IS EXEMPTED.           --------------------------------------------------           CHARGE 3000 PER SECTOR PER NO-SHOW ON DOMESTIC           SECTORS IN INDIA OR SAARC - IND V.V. LEG IF IND -           U.K. V.V. SECTORS ARE NOT NO-SHOW.           --------------------------------------------------           WHEN NOSHOW TICKET IS PRESENTED FOR REBOOKING           BOTH NOSHOW AND REBOOKING\/REISSUE CHARGES APPLY.           WHEN NOSHOW TICKET IS PRESENTED FOR CANCELLATION           BOTH NOSHOW AND CANCELLATION CHARGES APPLY.           --------------------------------------------------           FOR WAIVER OF NO SHOW PENALTY ON ACCOUNT OF           DEATH OF PASSENGER OR IMMEDIATE FAMILY MEMBER           PLEASE REFER LAST PAGE           ------------------------------------------------           THE NO-SHOW CHARGE WILL APPLY EVEN IF THERE IS NO-           SHOW ONLY ON THE INTERLINING SECTOR.           --------------------------------------------------           WHEN FARES ARE COMBINED THE MOST RESTRICTIVE           CONDITIONS APPLY FOR THE ENTIRE JOURNEY.           --------------------------------------------------           CHARGES ARE NON-COMMISISONABLE. APPLICABLE GST           WILL BE ADDITIONAL.           --------------------------------------------------          NOTE -           BELOW TEXT IS REGARDING WAIVER OF           REISSUE\/CANCELLATION\/NO-SHOW PENALTY IN CASE           OF DEATH OF PASSENGER OR IMMEDIATE FAMILY           MEMBER.           -------------------------------------------------           REISSUE\/CANCELLATION\/NO-SHOW PENALTY WAIVED           FOR DEATH OF PASSENGER OR IMMEDIATE FAMILY           MEMBER.           --------------------------------------------------           PENALTY ON ABOVE ACCOUNT IS WAIVED FOR FIRST TRANS           ACTION ONLY. SUBSEQUENT TRANSACTIONS IF ANY WILL           ATTRACT APPLICABLE PENALTY.           PENALTY ON ABOVE ACCOUNT IS WAIVED FOR FIRST           TRANSACTION ONLY. SUBSEQUENT TRANSACTIONS IF ANY           WILL ATTRACT APPLICABLE           PENALTY           ----------------------------------------------           IMMEDIATE FAMILY SHALL BE LIMITED TO SPOUSE\/           CHILDREN INCLUDING ADOPTED CHILDREN\/           PARENTS\/BROTHERS\/ SISTERS\/ GRANDPARENTS\/           GRANDCHILDREN\/FATHER IN LAW\/ MOTHER IN LAW\/SISTER           IN LAW\/BROTHER IN LAW\/ SON IN LAW\/ AND DAUGHTER           IN LAW.           --------------------------------------------------            IN CASE OF DEATH OF A PASSENGER OR IMMEDIATE           FAMILY MEMBER BEFORE COMMENCEMENT OF TRAVEL           PENALTY CHARGES STAND WAIVED OFF. THE WAIVER IS           PERMITTED FOR PENALTIES ONLY AND NOT FOR           APPLICABLEDIFFERENCE IN FARE. THE ABOVE IS           APPLICABLE ONLY WHEN TICKET IS PURCHASED BEFORE T           THE DEATH OF PASSENGER OR IMMEDIATE FAMILY MEMBER           HAS OCCURRED.           -------------------------------------------------           IN CASE OF DEATH OF A PASSENGER OR IMMEDIATE           FAMILY MEMBER AFTER COMMENCEMENT OF           TRAVEL PENALTY CHARGES STAND WAIVED           OFF.           -------------------------------------------------            IN CASE OF DEATH OF PASSENGER AFTER           COMMENCEMENT OF TRAVEL ACCOMPANYING PASSENGER           MAY TERMINATE TRAVEL OR INTERRUPT TRAVEL UNTIL           COMPLETION OF FORMALITIES AND RELIGIOUS CUSTOMS.           IF ANY BUT IN NO EVENT LATER THAN FORTY FIVE -45-D           AYS AFTER TRAVEL IS INTERRUPTED.           THE TICKET OF           RETURNING PASSENGERS WILL BE ENDORSED RETURN           ACCOUNT DEATH - NAME - AND SUCH ENDORSEMENT SHALL           BE AUTHENTICATED BY VALIDATION OR OTHER DUTY           MANAGER OFFICIAL STAMP. REFUND MAY BE ARRANGED.           RE-ROUTING MAY BE PERMITTED. APPLICABLE PENALTY           IF ANY MAY BE  WAIVED. DIFFERENCE OF FARE NEEDS           TO BE           COLLECTED.           -------------------------------------------------           REFUND IN CASE OF WAIVER WILL BE HALF 1\/2 RT FARE           IRRESPECTIVE OF THE FARE CONDITIONS AND BALANCE           AMOUNT MAY BE REFUNDED.           -------------------------------------------------           IN THE EVENT A PASSENGER IS DISCONTINUING TRAVEL           WITH THE GROUP IN ACCORDANCE WITH THE ABOVE THIS           SHALL NOT AFFECT THE ENTITLEMENT TO TRAVEL AT THE           GROUP FARE OF THE REMAINING PASSENGERS IN THE           GROUP.           --------------------------------------------------           NO WAIVER WILL BE GRANTED IN ABSENCE OF DEATH           CERTIFICATE ISSUED BY COMPETENT AUTHORITIES. I.E.           THOSE DESIGNATED TO ISSUE DEATH CERTIFICATE BY           APPLICABLE LAWS OF THE COUNTRY IN WHICH THE DEATH           OCCURRED. WAIVER ISSUING STATION MUST RETAIN THE           COPY OF DEATH CERTIFICATE AND RELATION PROOF OF           BEING PART OF IMMEDIATE FAMILY. 17. HIP\/MILEAGE EXCEPTIONS UNLESS OTHERWISE SPECIFIED   THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY FOR   STOPOVERS.          NOTE -           THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY           FOR STOPOVERS\/CONNECTIONS.           ---------------------------------------           IATA CHECKS SHOULD BE IGNORED WHERE HIP CHECK           DOES NOT APPLY   OR - THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY FOR        CONNECTIONS.          NOTE -           THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY           FOR STOPOVERS\/CONNECTIONS.           -----------------------------------------------           IATA CHECKS SHOULD BE IGNORED WHERE HIP CHECK           DOES NOT APPLY 18. TICKET ENDORSEMENT UNLESS OTHERWISE SPECIFIED   NOTE - GENERAL RULE DOES NOT APPLY   THE ORIGINAL AND THE REISSUED TICKET MUST BE ANNOTATED -   NON-END\/CHANGE - AND - CANCELLATION\/NO-SHOW - AND -   PENALTY MAY APPLY - AND - AS PER FARE RULES - IN THE   ENDORSEMENT BOX. 19. CHILDREN DISCOUNTS UNLESS OTHERWISE SPECIFIED   ACCOMPANIED CHILD 2-11 - CHARGE 75 PERCENT OF THE FARE.         TICKET DESIGNATOR - CH AND PERCENT OF DISCOUNT.          NOTE -           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR CHILD           SAME AS THAT MENTIONED FOR ADULT BELOW.   OR - UNACCOMPANIED CHILD 5-11 - CHARGE 100 PERCENT OF THE          FARE.              TICKET DESIGNATOR - CH AND PERCENT OF DISCOUNT.          NOTE -           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR CHILD           SAME AS THAT MENTIONED FOR ADULT BELOW.   OR - INFANT UNDER 2 WITHOUT A SEAT - CHARGE 10 PERCENT OF          THE FARE.              TICKET DESIGNATOR - IN AND PERCENT OF DISCOUNT.          NOTE -           INFANT WILL BE TICKETED IN THE SAME RBD AS THAT           OF THE ACCOMPANIED ADULT PASSENGER.           --------------------------------------------------           WHEN INFANT REACHES 2 YEARS OF AGE ON           DEPARTURE FROM POINT OF TURNAROUND A SEAT           MUST BE BOOKED ON THE RETURN LEG AND THE           APPLICABLE CHILD FARE CHARGED ON HALF ROUNDTRIP           BASIS WITH OUTBOUND INFANT FARE.           --------------------------------------------------           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR           INFANT----NIL   OR - INFANT UNDER 2 WITH A SEAT - CHARGE 75 PERCENT OF THE          FARE.              TICKET DESIGNATOR - CH AND PERCENT OF DISCOUNT.          NOTE -           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR CHILD           SAME AS THAT MENTIONED FOR ADULT BELOW. 20. TOUR CONDUCTOR DISCOUNTS UNLESS OTHERWISE SPECIFIED   TOUR CONDUCTOR - NO DISCOUNT. 21. AGENT DISCOUNTS UNLESS OTHERWISE SPECIFIED   AGENT - NO DISCOUNT. 22. ALL OTHER DISCOUNTS NONE UNLESS OTHERWISE SPECIFIED 23. MISCELLANEOUS PROVISIONS UNLESS OTHERWISE SPECIFIED   THIS FARE MUST NOT BE USED AS THE HIGH OR THE LOW FARE   WHEN CALCULATING A DIFFERENTIAL. THIS FARE MUST NOT BE   USED AS THE THROUGH FARE WHEN PRICING A FARE COMPONENT   WITH A DIFFERENTIAL. 31. VOLUNTARY CHANGES DO A CATEGORY 31 SPECIFIC TEXT ENTRY TO VIEW CONTENTS ALSO REFERENCE 16 PENALTIES - FOR ADDITIONAL CHANGE INFORMATION ","FlightId":0,"Origin":"BLR","ReturnDate":"2020-08-22T10:15:00"},{"Airline":"AI","DepartureTime":"2020-08-22T03:50:00","Destination":"DEL","FareBasisCode":"LE6MBLR","FareRestriction":"","FareRuleDetail":"FareBasisCode: LE6MBLR 0.  APPLICATION AND OTHER CONDITIONS RULE - 004\/INUK UNLESS OTHERWISE SPECIFIED IN UK YEAR ROUND FARES  APPLICATION    AREA      THESE FARES APPLY      FROM INDIA TO EUROPE.    CLASS OF SERVICE      THESE FARES APPLY FOR FIRST\/BUSINESS\/ECONOMY CLASS      SERVICE.    TYPES OF TRANSPORTATION      THIS RULE GOVERNS ONE-WAY AND ROUND-TRIP FARES.      FARES GOVERNED BY THIS RULE CAN BE USED TO CREATE      ONE-WAY\/ROUND-TRIP\/CIRCLE-TRIP\/OPEN-JAW\/SINGLE OPEN-      JAW\/DOUBLE OPEN-JAW JOURNEYS.  CAPACITY LIMITATIONS    THE CARRIER SHALL LIMIT THE NUMBER OF PASSENGERS CARRIED    ON ANY ONE FLIGHT AT FARES GOVERNED BY THIS RULE AND SUCH    FARES WILL NOT NECESSARILY BE AVAILABLE ON ALL FLIGHTS.    THE NUMBER OF SEATS WHICH THE CARRIER SHALL MAKE    AVAILABLE ON A GIVEN FLIGHT WILL BE DETERMINED BY THE    CARRIERS BEST JUDGMENT  OTHER CONDITIONS    ORIGIN AND DESTINATION ADDONS BUILT    DEL\/BOM\/AMD\/BLR-LHR AND DEL-BHX 4.  FLIGHT APPLICATION FOR -BLR TYPE FARES   THE FARE COMPONENT MUST NOT BE ON       ONE OR MORE OF THE FOLLOWING         BA FLIGHTS 510 THROUGH 524         BA FLIGHTS 1500 THROUGH 1999         BA FLIGHTS 2290 THROUGH 2539         BA FLIGHTS 2800 THROUGH 2899         BA FLIGHTS 3000 THROUGH 3269         BA FLIGHTS 3300 THROUGH 7019         BA FLIGHTS 7026 THROUGH 8035         BA FLIGHTS 8200 THROUGH 8449         BA FLIGHTS 8498 THROUGH 8699         BA FLIGHTS 8770 THROUGH 9999.   AND   IF THE FARE COMPONENT INCLUDES TRAVEL WITHIN DOMESTIC   SECTORS IN INDIA       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT.          NOTE -           RBDS FOR DOMESTIC TRAVEL IN INDIA           FOR ECONOMY CLASS - K           NO UPSELLS PERMITTED           --------------------------------------------------           FOR EXECUTIVE CLASS           REQUIRED WHEN AVAILABLE - D           PERMITTED - C           REQUIRED - Y           --------------------------------------------------           FOR FIRST CLASS           REQUIRED WHEN AVAILABLE - F\/A\/C\/D           REQUIRED - Y   AND   IF THE FARE COMPONENT INCLUDES TRAVEL BETWEEN   INTERNATIONAL SECTORS IN INDIA AND AREA 3       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT OPERATED BY AI.   AND   IF THE FARE COMPONENT INCLUDES TRAVEL BETWEEN INDIA AND   EUROPE       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT OPERATED BY AI.   AND   IF THE FARE COMPONENT INCLUDES TRAVEL WITHIN EUROPE       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY BA FLIGHT OPERATED BY BA.          NOTE -           RBDS AND UPSELL CHARGES ON BA           BA RBD FOR AI ECO CLASS RBD E\/S\/T\/U\/L\/G\/W\/V\/Q\/K  -            N           BA UPSELL FOR AI ECO CLASS RBD           E\/S\/T\/U\/L\/G\/W\/V\/Q\/K           N TO V INR 2200 OW \/ INR 4400 RT           ---------------------           BA RBD FOR AI ECO CLASS RBD H\/M\/B\/Y  - N           BA UPSELL FOR AI ECO CLASS RBD H\/M\/B\/Y           N TO V INR 2200 OW \/ INR 4400 RT           V TO B INR 11000 OW \/ INR 22000 RT.           ------------            BA RBD FOR AI EXE CLASS RBD C\/D\/J\/Z  - D            NO UPSELLS PERMITTED 5.  ADVANCE RES\/TICKETING UNLESS OTHERWISE SPECIFIED   NOTE - GENERAL RULE DOES NOT APPLY   RESERVATIONS ARE REQUIRED FOR ALL SECTORS. 7.  MAXIMUM STAY FOR -6M TYPE FARES   TRAVEL FROM LAST STOPOVER MUST BE COMPLETED NO LATER THAN   6 MONTHS AFTER DEPARTURE FROM FARE ORIGIN. 8.  STOPOVERS UNLESS OTHERWISE SPECIFIED   UNLIMITED STOPOVERS PERMITTED ON THE PRICING UNIT AT       INR 2500 EACH. 9.  TRANSFERS UNLESS OTHERWISE SPECIFIED   UNLIMITED TRANSFERS PERMITTED ON THE PRICING UNIT     FARE BREAK AND EMBEDDED SURFACE SECTORS NOT PERMITTED ON      THE FARE COMPONENT. 10. PERMITTED COMBINATIONS UNLESS OTHERWISE SPECIFIED    APPLICABLE ADD-ON CONSTRUCTION IS ADDRESSED IN    MISCELLANEOUS PROVISIONS - CATEGORY 23.   END-ON-END     END-ON-END COMBINATIONS PERMITTED WITH AI DOMESTIC     FARES. VALIDATE ALL FARE COMPONENTS. SIDE TRIPS NOT     PERMITTED.    PROVIDED -      COMBINATIONS ARE WITH ANY Y-\/B-\/M- TYPE FARES FOR      CARRIER AI WITHIN ALL DOMESTIC SECTORS IN INDIA   IF THE FARE COMPONENT INCLUDES TRAVEL WITHIN INDIA       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT.   OPEN JAWS\/ROUND TRIPS\/CIRCLE TRIPS     FARES MAY BE COMBINED ON A HALF ROUND TRIP BASIS     -TO FORM SINGLE OR DOUBLE OPEN JAWS WHICH CONSISTS OF NO      MORE THAN 2 INTERNATIONAL FARE COMPONENTS AND THE OPEN      SEGMENT AT ORIGIN MUST BE IN ONE COUNTRY. THE OPEN      SEGMENT AT DESTINATION HAS NO RESTRICTIONS.      MILEAGE OF THE OPEN SEGMENT MUST BE EQUAL\/LESS THAN      MILEAGE OF THE SHORTEST FLOWN FARE COMPONENT.     -TO FORM ROUND TRIPS\/CIRCLE TRIPS.    PROVIDED -      COMBINATIONS ARE WITH ANY FARE FOR CARRIER AI IN ANY       RULE IN TARIFF       IPRA    - USA\/CANADA-AREA 2\/3 AND GUAM-AREA 2 VIA                 ATLANTIC       IPRAI   - BETWEEN THE USA\/CANADA-AREA 2\/3 VIA ATLANTIC       IPREUAS - BETWEEN EUROPE-AREA 3       IPRFE   - BETWEEN THE RUSSIAN FEDERATION-AREA 3       IPRMEAS - BETWEEN THE MIDDLE EAST-AREA 3. 12. SURCHARGES FOR ROUND TRIP REGULAR EXCURSION FARES   A SURCHARGE OF INR 1000 PER DIRECTION WILL BE ADDED TO THE   APPLICABLE FARE FOR WEEKEND TRAVEL ON FRI\/SAT\/SUN.   AND - A SURCHARGE OF INR 3500 PER DIRECTION WILL BE ADDED         TO THE APPLICABLE FARE FOR TRAVEL FOR A PORTION OF         TRAVEL WITHIN INDIA.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY AI FLIGHT OPERATED BY 9I.   AND - A SURCHARGE OF INR 10000 PER DIRECTION WILL BE ADDED         TO THE APPLICABLE FARE FOR TRAVEL FOR A PORTION OF         TRAVEL WITHIN INDIA.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY AI FLIGHT OPERATED BY IX.   AND - A RBD SURCHARGE OF INR 2200 PER DIRECTION WILL BE         ADDED TO THE APPLICABLE FARE FOR A PORTION OF TRAVEL         WITHIN EUROPE BOOKED IN V.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY BA FLIGHT OPERATED BY BA.   AND - A RBD SURCHARGE OF INR 13200 PER DIRECTION WILL BE         ADDED TO THE APPLICABLE FARE FOR A PORTION OF TRAVEL         WITHIN EUROPE BOOKED IN B.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY BA FLIGHT OPERATED BY BA.   AND - A SURCHARGE OF INR 1500 WILL BE ADDED TO THE         APPLICABLE FARE FOR PEAK TRAVEL FROM 01JAN THROUGH         15JAN. 15. SALES RESTRICTIONS FOR -BLR TYPE FARES   TICKETS MUST BE ISSUED ON AI. 16. PENALTIES FOR L- TYPE FARES   CHANGES     CHARGE INR 6000 FOR REISSUE.          NOTE -           A CHANGE IS A DATE\/FLIGHT\/ROUTING\/BOOKING           MODIFICATION.           --------------------------------------------------           CHARGE APPLIES PER TRANSACTION.           A TRANSACTION MAY INCORPORATE ONE OR MORE           RESERVATION CHANGE IN THE SAME TRANSACTION E.G.           FLIGHT AND DATE CHANGE IN ONE DIRECTION OR BOTH.           --------------------------------------------------           CHARGE APPLIES TO ADULT CHILD AND INFANT           OCCUPYING A SEAT.           INFANT NOT OCCUPYING A SEAT IS EXEMPTED.           --------------------------------------------------           CHARGE 1500 PER SECTOR PER CHANGE IN DOMESTIC           SECTORS IN INDIA OR SAARC - IND V.V. LEG IF IND -           U.K. V.V. SECTORS ARE NOT CHANGED.           --------------------------------------------------           CHANGE FEE DOES NOT APPLY FOR UPGRADE TO A           HIGHER  CABIN CLASS ON THE SAME FLIGHT. ONLY           DIFFERENCE IN FARE AND TAXES TO BE COLLECTED.           IF THE UPGRADE IS WITH A DATE CHANGE CHANGE FEE           ALSO TO BE COLLECTED ALONG WITH DIFFERENCE IN           FARE AND TAXES.           --------------------------------------------------           WHEN NOSHOW TICKET IS PRESENTED FOR REBOOKING           BOTH NOSHOW AND REBOOKING\/REISSUE CHARGES APPLY.           NO SHOW IS WHEN A PAX FAILS TO CHANGE BOOKING           ATLEAST 24 HOURS BEFORE DEPARTURE OF THE FLIGHT           BEING CHANGED.           --------------------------------------------------           TICKET HAS TO BE REISSUED FOR ANY CHANGE           INCLUDING DATE\/FLIGHT\/ROUTING\/BOOKING CHANGE.           --------------------------------------------------           REBOOKING\/REISSUE\/UPGRADING MUST BE MADE IN ONE           TRANSACTION BEFORE DEPARTURE OF THE  FLIGHT BEING           CHANGED.           --------------------------------------------------           REISSUE TO BE DONE BY THE ORIGINAL ISSUING AGENT           OR AI OFFICE ONLY.           --------------------------------------------------           REPRICING SCENARIO -           1.BEFORE DEPARTURE -           IF A COMPLETELY UNUTILIZED TICKET IS BROUGHT FOR           EITHER AN OUTBOUND OR AN INBOUND           SEGMENT\/SECTOR\/FLIGHT           CHANGE THE FARE WILL RE RECALCULATED AS ON DATE           OF REISSUE WITH THE CURRENT FARES\/FARE RULES           BEING APPLICABLE.           2.AFTER DEPARTURE -           IF A PARTIALLY UTILIZED TICKET IS BROUGHT FOR           EITHER AN OUTBOUND OR AN INBOUND           SEGMENT\/SECTOR\/FLIGHT           CHANGE THE FARE WILL RE RECALCULATED AS ON THE           ORIGINAL DATE OF ISSUE WITH THE HISTORICAL FARES           FARES\/FARE RULES BEING APPLICABLE.           --------------------------------------------------           FOR WAIVER OF REISSUE PENALTY ON ACCOUNT OF DEATH           OF PASSENGER OR IMMEDIATE FAMILY MEMBER PLEASE           REFER LAST PAGE           --------------------------------------------------           IF NO SEATS ARE AVAILABLE IN THE SAME RBD AS           TICKETED PASSENGERS MAY BE BOOKED IN THE HIGHER           RBD BY CHARGING DIFFERENCE OF FARE AND TAXES.           DOWNSELLING TO A LOWER RBD IS NOT PERMITTED.           --------------------------------------------------           THE CHANGE\/REISSUE CHARGE PLUS DIFFERENCE IN FARE           AND TAXES WILL APPLY EVEN IF THERE IS A CHANGE OF           DATE\/FLIGHT\/ROUTING\/BOOKING ONLY ON THE           INTERLINING SECTOR.           --------------------------------------------------           WHEN FARES ARE COMBINED THE MOST RESTRICTIVE           CONDITIONS APPLY FOR THE ENTIRE JOURNEY.           --------------------------------------------------           THE CHANGE\/REISSUE CHARGE IS NON - REFUNDABLE.           --------------------------------------------------           CHARGES ARE NON-COMMISISONABLE. APPLICABLE GST           WILL BE ADDITIONAL.           --------------------------------------------------   CANCELLATIONS     CHARGE INR 10000 FOR CANCEL.          NOTE -           CHARGE APPLIES TO ADULT CHILD AND INFANT           OCCUPYING A SEAT.           INFANT NOT OCCUPYING A SEAT IS EXEMPTED.           --------------------------------------------------           WHEN NOSHOW TICKET IS PRESENTED FOR CANCELLATION           BOTH NOSHOW AND CANCELLATION CHARGES APPLY.           NO SHOW IS WHEN A PAX FAILS TO CANCEL BOOKING           ATLEAST 24 HOURS BEFORE DEPARTURE OF THE FLIGHT           BEING CANCELLED.           --------------------------------------------------           FOR WAIVER OF CANCELLATION PENALTY ON ACCOUNT OF           DEATH OF PASSENGER OR IMMEDIATE FAMILY MEMBER P           PLEASE REFER LAST PAGE           --------------------------------------------------           FULL REFUND PERMITTED IN CASE OF REJECTION OF           VISA SUBJECT TO           1. SUBMISSION OF PROPER DOCUMENTS SUCH AS EMBASSY           STATEMENT AT LEAST 14 DAYS BEFORE DEPARTURE.           2. BOTH OUTBOUND AND INBOUND JOURNEY BOOKED IN           RBD G OR ABOVE.           --------------------------------------------------           APPLICABLE PENALTIES TO BE RECOVERED FROM THE           BASIC FARE AND FUEL CHARGE ONLY.           --------------------------------------------------           IN CASES WHERE THE APPLICABLE PENALTIES ARE           HIGHER THAN THE SUM OF THE BASIC FARE AND FUEL           CHARGE ONLY THE BASIC FARE AND FUEL CHARGE WILL           BE FORFEITED.           STATUTORY TAXES E.G. K3 TAX EX INDIA AND OTHER           CHARGES LIKE AIRPORT DEPARTURE TAX ETC.           TO BE REFUNDED IN FULL.           --------------------------------------------------           AGAINST NON - REFUNDABLE TICKETS ONLY THE BASIC           FARE AND FUEL CHARGE TO BE FORFEITED. STATUTORY           TAXES AND OTHER CHARGES ARE REFUNDABLE IN FULL.           --------------------------------------------------           THE CUT-OFF DATE FOR REFUND OF K3 TAX WILL BE           31ST AUGUST YYYY FOR TICKETS ISSUED DURING           FINANCIAL YEAR  01ST APRIL XXXX TO 31ST MARCH           YYYY AND \/ OR  EXCHANGED \/ REISSUED UPTO 31           AUGUST YYYY.           --------------------------------------------------           IN CASE OF PARTIALLY UTILIZED TICKETS CHARGE ONE           WAY FARE OR HALF ROUND TRIP FARE WHICHEVER IS           HIGHER IN THE SAME RBD FOR THE SECTOR UTILISED           PLUS APPLICABLE TAXES.           IF NO ONE WAY FARE EXISTS FOR THE UTILISED SECTOR           IN THE SAME RBD THE NEXT HIGHER RBD WILL APPLY IN           ADDITION TO THE CANCELLATION CHARGE.           --------------------------------------------------           IF AN OUT OF SEQUENCE COUPON IS PRESENTED FOR           REFUND THE ITINERARY TO BE REPRICED AND THE           BALANCE IF ANY MAY BE PROCESSED FOR REFUND AFTER           DEDUCTING APPLICABLE PENALTIES.           --------------------------------------------------           THE CANCELLATION CHARGE WILL APPLY EVEN IF THERE           IS CANCELLATION ONLY OF THE INTERLINING SECTOR.           --------------------------------------------------           WHEN FARES ARE COMBINED THE MOST RESTRICTIVE           CONDITIONS APPLY FOR THE ENTIRE JOURNEY.           --------------------------------------------------           THE CHANGE\/REISSUE CHARGE IS NON - REFUNDABLE.           --------------------------------------------------           CHARGES ARE NON-COMMISISONABLE. APPLICABLE GST           WILL BE ADDITIONAL.           --------------------------------------------------   CHANGES\/CANCELLATIONS     CHARGE INR 9000 FOR NO-SHOW.          NOTE -           NO SHOW IS WHEN A PAX FAILS TO CHANGE\/CANCEL           BOOKING ATLEAST 24 HOURS BEFORE DEPARTURE OF THE           FLIGHT BEING CHANGED\/CANCELLED.           --------------------------------------------------           CHARGE APPLIES TO ADULT CHILD AND INFANT           OCCUPYING A SEAT.           INFANT NOT OCCUPYING A SEAT IS EXEMPTED.           --------------------------------------------------           CHARGE 3000 PER SECTOR PER NO-SHOW ON DOMESTIC           SECTORS IN INDIA OR SAARC - IND V.V. LEG IF IND -           U.K. V.V. SECTORS ARE NOT NO-SHOW.           --------------------------------------------------           WHEN NOSHOW TICKET IS PRESENTED FOR REBOOKING           BOTH NOSHOW AND REBOOKING\/REISSUE CHARGES APPLY.           WHEN NOSHOW TICKET IS PRESENTED FOR CANCELLATION           BOTH NOSHOW AND CANCELLATION CHARGES APPLY.           --------------------------------------------------           FOR WAIVER OF NO SHOW PENALTY ON ACCOUNT OF           DEATH OF PASSENGER OR IMMEDIATE FAMILY MEMBER           PLEASE REFER LAST PAGE           ------------------------------------------------           THE NO-SHOW CHARGE WILL APPLY EVEN IF THERE IS NO-           SHOW ONLY ON THE INTERLINING SECTOR.           --------------------------------------------------           WHEN FARES ARE COMBINED THE MOST RESTRICTIVE           CONDITIONS APPLY FOR THE ENTIRE JOURNEY.           --------------------------------------------------           CHARGES ARE NON-COMMISISONABLE. APPLICABLE GST           WILL BE ADDITIONAL.           --------------------------------------------------          NOTE -           BELOW TEXT IS REGARDING WAIVER OF           REISSUE\/CANCELLATION\/NO-SHOW PENALTY IN CASE           OF DEATH OF PASSENGER OR IMMEDIATE FAMILY           MEMBER.           -------------------------------------------------           REISSUE\/CANCELLATION\/NO-SHOW PENALTY WAIVED           FOR DEATH OF PASSENGER OR IMMEDIATE FAMILY           MEMBER.           --------------------------------------------------           PENALTY ON ABOVE ACCOUNT IS WAIVED FOR FIRST TRANS           ACTION ONLY. SUBSEQUENT TRANSACTIONS IF ANY WILL           ATTRACT APPLICABLE PENALTY.           PENALTY ON ABOVE ACCOUNT IS WAIVED FOR FIRST           TRANSACTION ONLY. SUBSEQUENT TRANSACTIONS IF ANY           WILL ATTRACT APPLICABLE           PENALTY           ----------------------------------------------           IMMEDIATE FAMILY SHALL BE LIMITED TO SPOUSE\/           CHILDREN INCLUDING ADOPTED CHILDREN\/           PARENTS\/BROTHERS\/ SISTERS\/ GRANDPARENTS\/           GRANDCHILDREN\/FATHER IN LAW\/ MOTHER IN LAW\/SISTER           IN LAW\/BROTHER IN LAW\/ SON IN LAW\/ AND DAUGHTER           IN LAW.           --------------------------------------------------            IN CASE OF DEATH OF A PASSENGER OR IMMEDIATE           FAMILY MEMBER BEFORE COMMENCEMENT OF TRAVEL           PENALTY CHARGES STAND WAIVED OFF. THE WAIVER IS           PERMITTED FOR PENALTIES ONLY AND NOT FOR           APPLICABLEDIFFERENCE IN FARE. THE ABOVE IS           APPLICABLE ONLY WHEN TICKET IS PURCHASED BEFORE T           THE DEATH OF PASSENGER OR IMMEDIATE FAMILY MEMBER           HAS OCCURRED.           -------------------------------------------------           IN CASE OF DEATH OF A PASSENGER OR IMMEDIATE           FAMILY MEMBER AFTER COMMENCEMENT OF           TRAVEL PENALTY CHARGES STAND WAIVED           OFF.           -------------------------------------------------            IN CASE OF DEATH OF PASSENGER AFTER           COMMENCEMENT OF TRAVEL ACCOMPANYING PASSENGER           MAY TERMINATE TRAVEL OR INTERRUPT TRAVEL UNTIL           COMPLETION OF FORMALITIES AND RELIGIOUS CUSTOMS.           IF ANY BUT IN NO EVENT LATER THAN FORTY FIVE -45-D           AYS AFTER TRAVEL IS INTERRUPTED.           THE TICKET OF           RETURNING PASSENGERS WILL BE ENDORSED RETURN           ACCOUNT DEATH - NAME - AND SUCH ENDORSEMENT SHALL           BE AUTHENTICATED BY VALIDATION OR OTHER DUTY           MANAGER OFFICIAL STAMP. REFUND MAY BE ARRANGED.           RE-ROUTING MAY BE PERMITTED. APPLICABLE PENALTY           IF ANY MAY BE  WAIVED. DIFFERENCE OF FARE NEEDS           TO BE           COLLECTED.           -------------------------------------------------           REFUND IN CASE OF WAIVER WILL BE HALF 1\/2 RT FARE           IRRESPECTIVE OF THE FARE CONDITIONS AND BALANCE           AMOUNT MAY BE REFUNDED.           -------------------------------------------------           IN THE EVENT A PASSENGER IS DISCONTINUING TRAVEL           WITH THE GROUP IN ACCORDANCE WITH THE ABOVE THIS           SHALL NOT AFFECT THE ENTITLEMENT TO TRAVEL AT THE           GROUP FARE OF THE REMAINING PASSENGERS IN THE           GROUP.           --------------------------------------------------           NO WAIVER WILL BE GRANTED IN ABSENCE OF DEATH           CERTIFICATE ISSUED BY COMPETENT AUTHORITIES. I.E.           THOSE DESIGNATED TO ISSUE DEATH CERTIFICATE BY           APPLICABLE LAWS OF THE COUNTRY IN WHICH THE DEATH           OCCURRED. WAIVER ISSUING STATION MUST RETAIN THE           COPY OF DEATH CERTIFICATE AND RELATION PROOF OF           BEING PART OF IMMEDIATE FAMILY. 17. HIP\/MILEAGE EXCEPTIONS UNLESS OTHERWISE SPECIFIED   THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY FOR   STOPOVERS.          NOTE -           THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY           FOR STOPOVERS\/CONNECTIONS.           ---------------------------------------           IATA CHECKS SHOULD BE IGNORED WHERE HIP CHECK           DOES NOT APPLY   OR - THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY FOR        CONNECTIONS.          NOTE -           THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY           FOR STOPOVERS\/CONNECTIONS.           -----------------------------------------------           IATA CHECKS SHOULD BE IGNORED WHERE HIP CHECK           DOES NOT APPLY 18. TICKET ENDORSEMENT UNLESS OTHERWISE SPECIFIED   NOTE - GENERAL RULE DOES NOT APPLY   THE ORIGINAL AND THE REISSUED TICKET MUST BE ANNOTATED -   NON-END\/CHANGE - AND - CANCELLATION\/NO-SHOW - AND -   PENALTY MAY APPLY - AND - AS PER FARE RULES - IN THE   ENDORSEMENT BOX. 19. CHILDREN DISCOUNTS UNLESS OTHERWISE SPECIFIED   ACCOMPANIED CHILD 2-11 - CHARGE 75 PERCENT OF THE FARE.         TICKET DESIGNATOR - CH AND PERCENT OF DISCOUNT.          NOTE -           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR CHILD           SAME AS THAT MENTIONED FOR ADULT BELOW.   OR - UNACCOMPANIED CHILD 5-11 - CHARGE 100 PERCENT OF THE          FARE.              TICKET DESIGNATOR - CH AND PERCENT OF DISCOUNT.          NOTE -           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR CHILD           SAME AS THAT MENTIONED FOR ADULT BELOW.   OR - INFANT UNDER 2 WITHOUT A SEAT - CHARGE 10 PERCENT OF          THE FARE.              TICKET DESIGNATOR - IN AND PERCENT OF DISCOUNT.          NOTE -           INFANT WILL BE TICKETED IN THE SAME RBD AS THAT           OF THE ACCOMPANIED ADULT PASSENGER.           --------------------------------------------------           WHEN INFANT REACHES 2 YEARS OF AGE ON           DEPARTURE FROM POINT OF TURNAROUND A SEAT           MUST BE BOOKED ON THE RETURN LEG AND THE           APPLICABLE CHILD FARE CHARGED ON HALF ROUNDTRIP           BASIS WITH OUTBOUND INFANT FARE.           --------------------------------------------------           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR           INFANT----NIL   OR - INFANT UNDER 2 WITH A SEAT - CHARGE 75 PERCENT OF THE          FARE.              TICKET DESIGNATOR - CH AND PERCENT OF DISCOUNT.          NOTE -           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR CHILD           SAME AS THAT MENTIONED FOR ADULT BELOW. 20. TOUR CONDUCTOR DISCOUNTS UNLESS OTHERWISE SPECIFIED   TOUR CONDUCTOR - NO DISCOUNT. 21. AGENT DISCOUNTS UNLESS OTHERWISE SPECIFIED   AGENT - NO DISCOUNT. 22. ALL OTHER DISCOUNTS NONE UNLESS OTHERWISE SPECIFIED 23. MISCELLANEOUS PROVISIONS UNLESS OTHERWISE SPECIFIED   THIS FARE MUST NOT BE USED AS THE HIGH OR THE LOW FARE   WHEN CALCULATING A DIFFERENTIAL. THIS FARE MUST NOT BE   USED AS THE THROUGH FARE WHEN PRICING A FARE COMPONENT   WITH A DIFFERENTIAL. 31. VOLUNTARY CHANGES DO A CATEGORY 31 SPECIFIC TEXT ENTRY TO VIEW CONTENTS ALSO REFERENCE 16 PENALTIES - FOR ADDITIONAL CHANGE INFORMATION ","FlightId":0,"Origin":"LHR","ReturnDate":"2020-08-22T10:15:00"},{"Airline":"AI","DepartureTime":"2020-08-22T03:50:00","Destination":"BLR","FareBasisCode":"LE6MBLR","FareRestriction":"","FareRuleDetail":"FareBasisCode: LE6MBLR 0.  APPLICATION AND OTHER CONDITIONS RULE - 004\/INUK UNLESS OTHERWISE SPECIFIED IN UK YEAR ROUND FARES  APPLICATION    AREA      THESE FARES APPLY      FROM INDIA TO EUROPE.    CLASS OF SERVICE      THESE FARES APPLY FOR FIRST\/BUSINESS\/ECONOMY CLASS      SERVICE.    TYPES OF TRANSPORTATION      THIS RULE GOVERNS ONE-WAY AND ROUND-TRIP FARES.      FARES GOVERNED BY THIS RULE CAN BE USED TO CREATE      ONE-WAY\/ROUND-TRIP\/CIRCLE-TRIP\/OPEN-JAW\/SINGLE OPEN-      JAW\/DOUBLE OPEN-JAW JOURNEYS.  CAPACITY LIMITATIONS    THE CARRIER SHALL LIMIT THE NUMBER OF PASSENGERS CARRIED    ON ANY ONE FLIGHT AT FARES GOVERNED BY THIS RULE AND SUCH    FARES WILL NOT NECESSARILY BE AVAILABLE ON ALL FLIGHTS.    THE NUMBER OF SEATS WHICH THE CARRIER SHALL MAKE    AVAILABLE ON A GIVEN FLIGHT WILL BE DETERMINED BY THE    CARRIERS BEST JUDGMENT  OTHER CONDITIONS    ORIGIN AND DESTINATION ADDONS BUILT    DEL\/BOM\/AMD\/BLR-LHR AND DEL-BHX 4.  FLIGHT APPLICATION FOR -BLR TYPE FARES   THE FARE COMPONENT MUST NOT BE ON       ONE OR MORE OF THE FOLLOWING         BA FLIGHTS 510 THROUGH 524         BA FLIGHTS 1500 THROUGH 1999         BA FLIGHTS 2290 THROUGH 2539         BA FLIGHTS 2800 THROUGH 2899         BA FLIGHTS 3000 THROUGH 3269         BA FLIGHTS 3300 THROUGH 7019         BA FLIGHTS 7026 THROUGH 8035         BA FLIGHTS 8200 THROUGH 8449         BA FLIGHTS 8498 THROUGH 8699         BA FLIGHTS 8770 THROUGH 9999.   AND   IF THE FARE COMPONENT INCLUDES TRAVEL WITHIN DOMESTIC   SECTORS IN INDIA       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT.          NOTE -           RBDS FOR DOMESTIC TRAVEL IN INDIA           FOR ECONOMY CLASS - K           NO UPSELLS PERMITTED           --------------------------------------------------           FOR EXECUTIVE CLASS           REQUIRED WHEN AVAILABLE - D           PERMITTED - C           REQUIRED - Y           --------------------------------------------------           FOR FIRST CLASS           REQUIRED WHEN AVAILABLE - F\/A\/C\/D           REQUIRED - Y   AND   IF THE FARE COMPONENT INCLUDES TRAVEL BETWEEN   INTERNATIONAL SECTORS IN INDIA AND AREA 3       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT OPERATED BY AI.   AND   IF THE FARE COMPONENT INCLUDES TRAVEL BETWEEN INDIA AND   EUROPE       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT OPERATED BY AI.   AND   IF THE FARE COMPONENT INCLUDES TRAVEL WITHIN EUROPE       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY BA FLIGHT OPERATED BY BA.          NOTE -           RBDS AND UPSELL CHARGES ON BA           BA RBD FOR AI ECO CLASS RBD E\/S\/T\/U\/L\/G\/W\/V\/Q\/K  -            N           BA UPSELL FOR AI ECO CLASS RBD           E\/S\/T\/U\/L\/G\/W\/V\/Q\/K           N TO V INR 2200 OW \/ INR 4400 RT           ---------------------           BA RBD FOR AI ECO CLASS RBD H\/M\/B\/Y  - N           BA UPSELL FOR AI ECO CLASS RBD H\/M\/B\/Y           N TO V INR 2200 OW \/ INR 4400 RT           V TO B INR 11000 OW \/ INR 22000 RT.           ------------            BA RBD FOR AI EXE CLASS RBD C\/D\/J\/Z  - D            NO UPSELLS PERMITTED 5.  ADVANCE RES\/TICKETING UNLESS OTHERWISE SPECIFIED   NOTE - GENERAL RULE DOES NOT APPLY   RESERVATIONS ARE REQUIRED FOR ALL SECTORS. 7.  MAXIMUM STAY FOR -6M TYPE FARES   TRAVEL FROM LAST STOPOVER MUST BE COMPLETED NO LATER THAN   6 MONTHS AFTER DEPARTURE FROM FARE ORIGIN. 8.  STOPOVERS UNLESS OTHERWISE SPECIFIED   UNLIMITED STOPOVERS PERMITTED ON THE PRICING UNIT AT       INR 2500 EACH. 9.  TRANSFERS UNLESS OTHERWISE SPECIFIED   UNLIMITED TRANSFERS PERMITTED ON THE PRICING UNIT     FARE BREAK AND EMBEDDED SURFACE SECTORS NOT PERMITTED ON      THE FARE COMPONENT. 10. PERMITTED COMBINATIONS UNLESS OTHERWISE SPECIFIED    APPLICABLE ADD-ON CONSTRUCTION IS ADDRESSED IN    MISCELLANEOUS PROVISIONS - CATEGORY 23.   END-ON-END     END-ON-END COMBINATIONS PERMITTED WITH AI DOMESTIC     FARES. VALIDATE ALL FARE COMPONENTS. SIDE TRIPS NOT     PERMITTED.    PROVIDED -      COMBINATIONS ARE WITH ANY Y-\/B-\/M- TYPE FARES FOR      CARRIER AI WITHIN ALL DOMESTIC SECTORS IN INDIA   IF THE FARE COMPONENT INCLUDES TRAVEL WITHIN INDIA       THEN THAT TRAVEL MUST BE ON       ONE OR MORE OF THE FOLLOWING         ANY AI FLIGHT.   OPEN JAWS\/ROUND TRIPS\/CIRCLE TRIPS     FARES MAY BE COMBINED ON A HALF ROUND TRIP BASIS     -TO FORM SINGLE OR DOUBLE OPEN JAWS WHICH CONSISTS OF NO      MORE THAN 2 INTERNATIONAL FARE COMPONENTS AND THE OPEN      SEGMENT AT ORIGIN MUST BE IN ONE COUNTRY. THE OPEN      SEGMENT AT DESTINATION HAS NO RESTRICTIONS.      MILEAGE OF THE OPEN SEGMENT MUST BE EQUAL\/LESS THAN      MILEAGE OF THE SHORTEST FLOWN FARE COMPONENT.     -TO FORM ROUND TRIPS\/CIRCLE TRIPS.    PROVIDED -      COMBINATIONS ARE WITH ANY FARE FOR CARRIER AI IN ANY       RULE IN TARIFF       IPRA    - USA\/CANADA-AREA 2\/3 AND GUAM-AREA 2 VIA                 ATLANTIC       IPRAI   - BETWEEN THE USA\/CANADA-AREA 2\/3 VIA ATLANTIC       IPREUAS - BETWEEN EUROPE-AREA 3       IPRFE   - BETWEEN THE RUSSIAN FEDERATION-AREA 3       IPRMEAS - BETWEEN THE MIDDLE EAST-AREA 3. 12. SURCHARGES FOR ROUND TRIP REGULAR EXCURSION FARES   A SURCHARGE OF INR 1000 PER DIRECTION WILL BE ADDED TO THE   APPLICABLE FARE FOR WEEKEND TRAVEL ON FRI\/SAT\/SUN.   AND - A SURCHARGE OF INR 3500 PER DIRECTION WILL BE ADDED         TO THE APPLICABLE FARE FOR TRAVEL FOR A PORTION OF         TRAVEL WITHIN INDIA.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY AI FLIGHT OPERATED BY 9I.   AND - A SURCHARGE OF INR 10000 PER DIRECTION WILL BE ADDED         TO THE APPLICABLE FARE FOR TRAVEL FOR A PORTION OF         TRAVEL WITHIN INDIA.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY AI FLIGHT OPERATED BY IX.   AND - A RBD SURCHARGE OF INR 2200 PER DIRECTION WILL BE         ADDED TO THE APPLICABLE FARE FOR A PORTION OF TRAVEL         WITHIN EUROPE BOOKED IN V.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY BA FLIGHT OPERATED BY BA.   AND - A RBD SURCHARGE OF INR 13200 PER DIRECTION WILL BE         ADDED TO THE APPLICABLE FARE FOR A PORTION OF TRAVEL         WITHIN EUROPE BOOKED IN B.     PROVIDED TRAVEL IS ON ONE OR MORE OF THE FOLLOWING       ANY BA FLIGHT OPERATED BY BA.   AND - A SURCHARGE OF INR 1500 WILL BE ADDED TO THE         APPLICABLE FARE FOR PEAK TRAVEL FROM 01JAN THROUGH         15JAN. 15. SALES RESTRICTIONS FOR -BLR TYPE FARES   TICKETS MUST BE ISSUED ON AI. 16. PENALTIES FOR L- TYPE FARES   CHANGES     CHARGE INR 6000 FOR REISSUE.          NOTE -           A CHANGE IS A DATE\/FLIGHT\/ROUTING\/BOOKING           MODIFICATION.           --------------------------------------------------           CHARGE APPLIES PER TRANSACTION.           A TRANSACTION MAY INCORPORATE ONE OR MORE           RESERVATION CHANGE IN THE SAME TRANSACTION E.G.           FLIGHT AND DATE CHANGE IN ONE DIRECTION OR BOTH.           --------------------------------------------------           CHARGE APPLIES TO ADULT CHILD AND INFANT           OCCUPYING A SEAT.           INFANT NOT OCCUPYING A SEAT IS EXEMPTED.           --------------------------------------------------           CHARGE 1500 PER SECTOR PER CHANGE IN DOMESTIC           SECTORS IN INDIA OR SAARC - IND V.V. LEG IF IND -           U.K. V.V. SECTORS ARE NOT CHANGED.           --------------------------------------------------           CHANGE FEE DOES NOT APPLY FOR UPGRADE TO A           HIGHER  CABIN CLASS ON THE SAME FLIGHT. ONLY           DIFFERENCE IN FARE AND TAXES TO BE COLLECTED.           IF THE UPGRADE IS WITH A DATE CHANGE CHANGE FEE           ALSO TO BE COLLECTED ALONG WITH DIFFERENCE IN           FARE AND TAXES.           --------------------------------------------------           WHEN NOSHOW TICKET IS PRESENTED FOR REBOOKING           BOTH NOSHOW AND REBOOKING\/REISSUE CHARGES APPLY.           NO SHOW IS WHEN A PAX FAILS TO CHANGE BOOKING           ATLEAST 24 HOURS BEFORE DEPARTURE OF THE FLIGHT           BEING CHANGED.           --------------------------------------------------           TICKET HAS TO BE REISSUED FOR ANY CHANGE           INCLUDING DATE\/FLIGHT\/ROUTING\/BOOKING CHANGE.           --------------------------------------------------           REBOOKING\/REISSUE\/UPGRADING MUST BE MADE IN ONE           TRANSACTION BEFORE DEPARTURE OF THE  FLIGHT BEING           CHANGED.           --------------------------------------------------           REISSUE TO BE DONE BY THE ORIGINAL ISSUING AGENT           OR AI OFFICE ONLY.           --------------------------------------------------           REPRICING SCENARIO -           1.BEFORE DEPARTURE -           IF A COMPLETELY UNUTILIZED TICKET IS BROUGHT FOR           EITHER AN OUTBOUND OR AN INBOUND           SEGMENT\/SECTOR\/FLIGHT           CHANGE THE FARE WILL RE RECALCULATED AS ON DATE           OF REISSUE WITH THE CURRENT FARES\/FARE RULES           BEING APPLICABLE.           2.AFTER DEPARTURE -           IF A PARTIALLY UTILIZED TICKET IS BROUGHT FOR           EITHER AN OUTBOUND OR AN INBOUND           SEGMENT\/SECTOR\/FLIGHT           CHANGE THE FARE WILL RE RECALCULATED AS ON THE           ORIGINAL DATE OF ISSUE WITH THE HISTORICAL FARES           FARES\/FARE RULES BEING APPLICABLE.           --------------------------------------------------           FOR WAIVER OF REISSUE PENALTY ON ACCOUNT OF DEATH           OF PASSENGER OR IMMEDIATE FAMILY MEMBER PLEASE           REFER LAST PAGE           --------------------------------------------------           IF NO SEATS ARE AVAILABLE IN THE SAME RBD AS           TICKETED PASSENGERS MAY BE BOOKED IN THE HIGHER           RBD BY CHARGING DIFFERENCE OF FARE AND TAXES.           DOWNSELLING TO A LOWER RBD IS NOT PERMITTED.           --------------------------------------------------           THE CHANGE\/REISSUE CHARGE PLUS DIFFERENCE IN FARE           AND TAXES WILL APPLY EVEN IF THERE IS A CHANGE OF           DATE\/FLIGHT\/ROUTING\/BOOKING ONLY ON THE           INTERLINING SECTOR.           --------------------------------------------------           WHEN FARES ARE COMBINED THE MOST RESTRICTIVE           CONDITIONS APPLY FOR THE ENTIRE JOURNEY.           --------------------------------------------------           THE CHANGE\/REISSUE CHARGE IS NON - REFUNDABLE.           --------------------------------------------------           CHARGES ARE NON-COMMISISONABLE. APPLICABLE GST           WILL BE ADDITIONAL.           --------------------------------------------------   CANCELLATIONS     CHARGE INR 10000 FOR CANCEL.          NOTE -           CHARGE APPLIES TO ADULT CHILD AND INFANT           OCCUPYING A SEAT.           INFANT NOT OCCUPYING A SEAT IS EXEMPTED.           --------------------------------------------------           WHEN NOSHOW TICKET IS PRESENTED FOR CANCELLATION           BOTH NOSHOW AND CANCELLATION CHARGES APPLY.           NO SHOW IS WHEN A PAX FAILS TO CANCEL BOOKING           ATLEAST 24 HOURS BEFORE DEPARTURE OF THE FLIGHT           BEING CANCELLED.           --------------------------------------------------           FOR WAIVER OF CANCELLATION PENALTY ON ACCOUNT OF           DEATH OF PASSENGER OR IMMEDIATE FAMILY MEMBER P           PLEASE REFER LAST PAGE           --------------------------------------------------           FULL REFUND PERMITTED IN CASE OF REJECTION OF           VISA SUBJECT TO           1. SUBMISSION OF PROPER DOCUMENTS SUCH AS EMBASSY           STATEMENT AT LEAST 14 DAYS BEFORE DEPARTURE.           2. BOTH OUTBOUND AND INBOUND JOURNEY BOOKED IN           RBD G OR ABOVE.           --------------------------------------------------           APPLICABLE PENALTIES TO BE RECOVERED FROM THE           BASIC FARE AND FUEL CHARGE ONLY.           --------------------------------------------------           IN CASES WHERE THE APPLICABLE PENALTIES ARE           HIGHER THAN THE SUM OF THE BASIC FARE AND FUEL           CHARGE ONLY THE BASIC FARE AND FUEL CHARGE WILL           BE FORFEITED.           STATUTORY TAXES E.G. K3 TAX EX INDIA AND OTHER           CHARGES LIKE AIRPORT DEPARTURE TAX ETC.           TO BE REFUNDED IN FULL.           --------------------------------------------------           AGAINST NON - REFUNDABLE TICKETS ONLY THE BASIC           FARE AND FUEL CHARGE TO BE FORFEITED. STATUTORY           TAXES AND OTHER CHARGES ARE REFUNDABLE IN FULL.           --------------------------------------------------           THE CUT-OFF DATE FOR REFUND OF K3 TAX WILL BE           31ST AUGUST YYYY FOR TICKETS ISSUED DURING           FINANCIAL YEAR  01ST APRIL XXXX TO 31ST MARCH           YYYY AND \/ OR  EXCHANGED \/ REISSUED UPTO 31           AUGUST YYYY.           --------------------------------------------------           IN CASE OF PARTIALLY UTILIZED TICKETS CHARGE ONE           WAY FARE OR HALF ROUND TRIP FARE WHICHEVER IS           HIGHER IN THE SAME RBD FOR THE SECTOR UTILISED           PLUS APPLICABLE TAXES.           IF NO ONE WAY FARE EXISTS FOR THE UTILISED SECTOR           IN THE SAME RBD THE NEXT HIGHER RBD WILL APPLY IN           ADDITION TO THE CANCELLATION CHARGE.           --------------------------------------------------           IF AN OUT OF SEQUENCE COUPON IS PRESENTED FOR           REFUND THE ITINERARY TO BE REPRICED AND THE           BALANCE IF ANY MAY BE PROCESSED FOR REFUND AFTER           DEDUCTING APPLICABLE PENALTIES.           --------------------------------------------------           THE CANCELLATION CHARGE WILL APPLY EVEN IF THERE           IS CANCELLATION ONLY OF THE INTERLINING SECTOR.           --------------------------------------------------           WHEN FARES ARE COMBINED THE MOST RESTRICTIVE           CONDITIONS APPLY FOR THE ENTIRE JOURNEY.           --------------------------------------------------           THE CHANGE\/REISSUE CHARGE IS NON - REFUNDABLE.           --------------------------------------------------           CHARGES ARE NON-COMMISISONABLE. APPLICABLE GST           WILL BE ADDITIONAL.           --------------------------------------------------   CHANGES\/CANCELLATIONS     CHARGE INR 9000 FOR NO-SHOW.          NOTE -           NO SHOW IS WHEN A PAX FAILS TO CHANGE\/CANCEL           BOOKING ATLEAST 24 HOURS BEFORE DEPARTURE OF THE           FLIGHT BEING CHANGED\/CANCELLED.           --------------------------------------------------           CHARGE APPLIES TO ADULT CHILD AND INFANT           OCCUPYING A SEAT.           INFANT NOT OCCUPYING A SEAT IS EXEMPTED.           --------------------------------------------------           CHARGE 3000 PER SECTOR PER NO-SHOW ON DOMESTIC           SECTORS IN INDIA OR SAARC - IND V.V. LEG IF IND -           U.K. V.V. SECTORS ARE NOT NO-SHOW.           --------------------------------------------------           WHEN NOSHOW TICKET IS PRESENTED FOR REBOOKING           BOTH NOSHOW AND REBOOKING\/REISSUE CHARGES APPLY.           WHEN NOSHOW TICKET IS PRESENTED FOR CANCELLATION           BOTH NOSHOW AND CANCELLATION CHARGES APPLY.           --------------------------------------------------           FOR WAIVER OF NO SHOW PENALTY ON ACCOUNT OF           DEATH OF PASSENGER OR IMMEDIATE FAMILY MEMBER           PLEASE REFER LAST PAGE           ------------------------------------------------           THE NO-SHOW CHARGE WILL APPLY EVEN IF THERE IS NO-           SHOW ONLY ON THE INTERLINING SECTOR.           --------------------------------------------------           WHEN FARES ARE COMBINED THE MOST RESTRICTIVE           CONDITIONS APPLY FOR THE ENTIRE JOURNEY.           --------------------------------------------------           CHARGES ARE NON-COMMISISONABLE. APPLICABLE GST           WILL BE ADDITIONAL.           --------------------------------------------------          NOTE -           BELOW TEXT IS REGARDING WAIVER OF           REISSUE\/CANCELLATION\/NO-SHOW PENALTY IN CASE           OF DEATH OF PASSENGER OR IMMEDIATE FAMILY           MEMBER.           -------------------------------------------------           REISSUE\/CANCELLATION\/NO-SHOW PENALTY WAIVED           FOR DEATH OF PASSENGER OR IMMEDIATE FAMILY           MEMBER.           --------------------------------------------------           PENALTY ON ABOVE ACCOUNT IS WAIVED FOR FIRST TRANS           ACTION ONLY. SUBSEQUENT TRANSACTIONS IF ANY WILL           ATTRACT APPLICABLE PENALTY.           PENALTY ON ABOVE ACCOUNT IS WAIVED FOR FIRST           TRANSACTION ONLY. SUBSEQUENT TRANSACTIONS IF ANY           WILL ATTRACT APPLICABLE           PENALTY           ----------------------------------------------           IMMEDIATE FAMILY SHALL BE LIMITED TO SPOUSE\/           CHILDREN INCLUDING ADOPTED CHILDREN\/           PARENTS\/BROTHERS\/ SISTERS\/ GRANDPARENTS\/           GRANDCHILDREN\/FATHER IN LAW\/ MOTHER IN LAW\/SISTER           IN LAW\/BROTHER IN LAW\/ SON IN LAW\/ AND DAUGHTER           IN LAW.           --------------------------------------------------            IN CASE OF DEATH OF A PASSENGER OR IMMEDIATE           FAMILY MEMBER BEFORE COMMENCEMENT OF TRAVEL           PENALTY CHARGES STAND WAIVED OFF. THE WAIVER IS           PERMITTED FOR PENALTIES ONLY AND NOT FOR           APPLICABLEDIFFERENCE IN FARE. THE ABOVE IS           APPLICABLE ONLY WHEN TICKET IS PURCHASED BEFORE T           THE DEATH OF PASSENGER OR IMMEDIATE FAMILY MEMBER           HAS OCCURRED.           -------------------------------------------------           IN CASE OF DEATH OF A PASSENGER OR IMMEDIATE           FAMILY MEMBER AFTER COMMENCEMENT OF           TRAVEL PENALTY CHARGES STAND WAIVED           OFF.           -------------------------------------------------            IN CASE OF DEATH OF PASSENGER AFTER           COMMENCEMENT OF TRAVEL ACCOMPANYING PASSENGER           MAY TERMINATE TRAVEL OR INTERRUPT TRAVEL UNTIL           COMPLETION OF FORMALITIES AND RELIGIOUS CUSTOMS.           IF ANY BUT IN NO EVENT LATER THAN FORTY FIVE -45-D           AYS AFTER TRAVEL IS INTERRUPTED.           THE TICKET OF           RETURNING PASSENGERS WILL BE ENDORSED RETURN           ACCOUNT DEATH - NAME - AND SUCH ENDORSEMENT SHALL           BE AUTHENTICATED BY VALIDATION OR OTHER DUTY           MANAGER OFFICIAL STAMP. REFUND MAY BE ARRANGED.           RE-ROUTING MAY BE PERMITTED. APPLICABLE PENALTY           IF ANY MAY BE  WAIVED. DIFFERENCE OF FARE NEEDS           TO BE           COLLECTED.           -------------------------------------------------           REFUND IN CASE OF WAIVER WILL BE HALF 1\/2 RT FARE           IRRESPECTIVE OF THE FARE CONDITIONS AND BALANCE           AMOUNT MAY BE REFUNDED.           -------------------------------------------------           IN THE EVENT A PASSENGER IS DISCONTINUING TRAVEL           WITH THE GROUP IN ACCORDANCE WITH THE ABOVE THIS           SHALL NOT AFFECT THE ENTITLEMENT TO TRAVEL AT THE           GROUP FARE OF THE REMAINING PASSENGERS IN THE           GROUP.           --------------------------------------------------           NO WAIVER WILL BE GRANTED IN ABSENCE OF DEATH           CERTIFICATE ISSUED BY COMPETENT AUTHORITIES. I.E.           THOSE DESIGNATED TO ISSUE DEATH CERTIFICATE BY           APPLICABLE LAWS OF THE COUNTRY IN WHICH THE DEATH           OCCURRED. WAIVER ISSUING STATION MUST RETAIN THE           COPY OF DEATH CERTIFICATE AND RELATION PROOF OF           BEING PART OF IMMEDIATE FAMILY. 17. HIP\/MILEAGE EXCEPTIONS UNLESS OTHERWISE SPECIFIED   THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY FOR   STOPOVERS.          NOTE -           THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY           FOR STOPOVERS\/CONNECTIONS.           ---------------------------------------           IATA CHECKS SHOULD BE IGNORED WHERE HIP CHECK           DOES NOT APPLY   OR - THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY FOR        CONNECTIONS.          NOTE -           THE HIGHER INTERMEDIATE POINT RULE DOES NOT APPLY           FOR STOPOVERS\/CONNECTIONS.           -----------------------------------------------           IATA CHECKS SHOULD BE IGNORED WHERE HIP CHECK           DOES NOT APPLY 18. TICKET ENDORSEMENT UNLESS OTHERWISE SPECIFIED   NOTE - GENERAL RULE DOES NOT APPLY   THE ORIGINAL AND THE REISSUED TICKET MUST BE ANNOTATED -   NON-END\/CHANGE - AND - CANCELLATION\/NO-SHOW - AND -   PENALTY MAY APPLY - AND - AS PER FARE RULES - IN THE   ENDORSEMENT BOX. 19. CHILDREN DISCOUNTS UNLESS OTHERWISE SPECIFIED   ACCOMPANIED CHILD 2-11 - CHARGE 75 PERCENT OF THE FARE.         TICKET DESIGNATOR - CH AND PERCENT OF DISCOUNT.          NOTE -           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR CHILD           SAME AS THAT MENTIONED FOR ADULT BELOW.   OR - UNACCOMPANIED CHILD 5-11 - CHARGE 100 PERCENT OF THE          FARE.              TICKET DESIGNATOR - CH AND PERCENT OF DISCOUNT.          NOTE -           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR CHILD           SAME AS THAT MENTIONED FOR ADULT BELOW.   OR - INFANT UNDER 2 WITHOUT A SEAT - CHARGE 10 PERCENT OF          THE FARE.              TICKET DESIGNATOR - IN AND PERCENT OF DISCOUNT.          NOTE -           INFANT WILL BE TICKETED IN THE SAME RBD AS THAT           OF THE ACCOMPANIED ADULT PASSENGER.           --------------------------------------------------           WHEN INFANT REACHES 2 YEARS OF AGE ON           DEPARTURE FROM POINT OF TURNAROUND A SEAT           MUST BE BOOKED ON THE RETURN LEG AND THE           APPLICABLE CHILD FARE CHARGED ON HALF ROUNDTRIP           BASIS WITH OUTBOUND INFANT FARE.           --------------------------------------------------           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR           INFANT----NIL   OR - INFANT UNDER 2 WITH A SEAT - CHARGE 75 PERCENT OF THE          FARE.              TICKET DESIGNATOR - CH AND PERCENT OF DISCOUNT.          NOTE -           NOSHOW\/REBOOKING\/CANCELLATION PENALTIES FOR CHILD           SAME AS THAT MENTIONED FOR ADULT BELOW. 20. TOUR CONDUCTOR DISCOUNTS UNLESS OTHERWISE SPECIFIED   TOUR CONDUCTOR - NO DISCOUNT. 21. AGENT DISCOUNTS UNLESS OTHERWISE SPECIFIED   AGENT - NO DISCOUNT. 22. ALL OTHER DISCOUNTS NONE UNLESS OTHERWISE SPECIFIED 23. MISCELLANEOUS PROVISIONS UNLESS OTHERWISE SPECIFIED   THIS FARE MUST NOT BE USED AS THE HIGH OR THE LOW FARE   WHEN CALCULATING A DIFFERENTIAL. THIS FARE MUST NOT BE   USED AS THE THROUGH FARE WHEN PRICING A FARE COMPONENT   WITH A DIFFERENTIAL. 31. VOLUNTARY CHANGES DO A CATEGORY 31 SPECIFIC TEXT ENTRY TO VIEW CONTENTS ALSO REFERENCE 16 PENALTIES - FOR ADDITIONAL CHANGE INFORMATION ","FlightId":0,"Origin":"DEL","ReturnDate":"2020-08-22T10:15:00"}],"ResponseStatus":1,"TraceId":"c086130c-70c4-44fc-be2f-0df6080b345f"}}';
			

			$data['fare_rule_details']=$f1;
		//echo "<pre/>";print_r($data);exit();

		   $this->load->view(PROJECT_THEME.'/flight/flight_details_tbo',$data);
			}
		
	}
/*Tbo new end */



	function render_fare_rule_response($response){
		// debug($response);die;
        $fare_ruleResult = array();
        if (!isset($response['soapenv:Envelope']['soapenv:Body']['Fare_GetFareRulesReply']['errorInfo'])) {
            if (isset($response['soapenv:Envelope']['soapenv:Body']['Fare_GetFareRulesReply']))
                $fare_ruleResult = $response['soapenv:Envelope']['soapenv:Body']['Fare_GetFareRulesReply'];
        }

        $fare_ruleResult1 = array();
        foreach($fare_ruleResult['tariffInfo'] as $key=>$val){
            $index_name = explode('.',$val['fareRuleText'][0]['freeText'])[1];
            $fare_ruleResult1[$index_name] = '';
            foreach($val['fareRuleText'] as $text_key=>$text_val){
                $fare_ruleResult1[$index_name] .= ' ';
                if($text_key == 0)
                    continue;
                if(empty($text_val['freeText']))
                    continue;
                $fare_ruleResult1[$index_name] .= trim($text_val['freeText']);
            }
        }

        return $fare_ruleResult1;
    }

	public function addToCart($uid=''){
		if($uid!=''){
			$uid_v1 = json_decode(base64_decode($uid));
			$uid = $uid_v1->id;
			$session_id  = $uid_v1->sessionid;
			$fareBasis = $uid_v1->fareBasis;
			$result = $this->Flight_Model->get_flight_data_segments($uid);
			// debug($result);die;
			if($result!=''){
					$RoutingId = $result->routing_id;
					$this->Flight_Model->insert_flight_data_segments_to_query_table($result->segment_data);
					$segment_data  = json_decode($result->segment_data,1);

			//echo "<pre/>";print_r($segment_data);exit();

					#debug($segment_data);die;
					if($result->api_name=='AMADEUS'){
						$api_id=1;
						$out_count = (count($segment_data[0]['DepartureDate']) - 1 );
						$out_DepartDate = $segment_data[0]['DepartureDate'][0];
						$out_ArriveDate = $segment_data[0]['ArrivalDate'][$out_count];
						 
						if(isset($segment_data[1]['flightId']) && $segment_data[1]['flightId']!='') {
							$in_count = (count($segment_data[1]['DepartureDate']) - 1 );
							$in_DepartDate = $segment_data[1]['DepartureDate'][0];
							$in_ArriveDate = $segment_data[1]['ArrivalDate'][$in_count];
							$modee='ROUNDTRIP';
						}else{
							$modee='ONEWAY'; $in_DepartDate = ''; $in_ArriveDate = '';
						}
					}elseif($result->api_name=='TBO'){
						$api_id=2;
						$out_count = (count($segment_data[0]) - 1 );
						$dep1=explode('T',$segment_data[0][0]['Origin']['DepTime']);
						$out_DepartDate = $dep1[0];
						$arr1=explode('T',$segment_data[0][$out_count]['Destination']['ArrTime']);
						$out_ArriveDate = $dep1[0];
						if(isset($segment_data[1]) && $segment_data[1][0]['FlightStatus']=='Confirmed') {
							$in_count = (count($segment_data[1]) - 1 );
						$dep1=explode('T',$segment_data[1][0]['Origin']['DepTime']);
						$in_DepartDate = $dep1[0];
						$arr1=explode('T',$segment_data[1][$out_count]['Destination']['ArrTime']);
						$in_ArriveDate = $dep1[0];
						$modee='ROUNDTRIP';
						}else{
							$modee='ONEWAY'; $in_DepartDate = ''; $in_ArriveDate = '';
						}
					}



				   $cart_flight = array(
					'session_id' 			=> $session_id,
					'origin' 				=> $result->origin,
					'destination' 			=> $result->destination,
					'origin_city' 			=> $this->Flight_Model->get_airport_cityname($result->origin),
					'destination_city' 		=> $this->Flight_Model->get_airport_cityname($result->destination),
					'origin_airport'	 	=> $this->Flight_Model->get_airport_name($result->origin),
					'destination_airport' 	=> $this->Flight_Model->get_airport_name($result->destination),
					'mode'					=> $result->trip_type,
					'outward_departure' 	=> $out_DepartDate,
					'outward_arrival' 		=> $out_ArriveDate,
					'inward_depature' 		=> $in_DepartDate,
					'inward_arrival' 		=> $in_ArriveDate,
					'outward_duration' 		=> $result->onwards_duration,
					'inward_duration' 		=> $result->returns_duration,
					'airline' 				=> $result->airline,
					'outward_stops' 		=> $result->onwards_stops,
					'inward_stops' 			=> $result->returns_stops,
					'amount' 				=> $result->amount,
					'api_tax' 				=> $result->api_tax,
					'segment_data' 			=> $result->segment_data,
					'PricingDetails' 		=> $result->PricingDetails,
					'airline_image' 		=> 'https://www.amadeus.net/static/img/static/airlines/medium/'.$result->airline_code.'.png',
					'admin_markup' 			=> $result->admin_markup,
					'admin_baseprice' 		=> $result->admin_baseprice,
					'my_markup' 			=> $result->my_markup,
					'site_currency' 		=> BASE_CURRENCY,
					'api_currency' 			=> $result->api_currency,
					'request_scenario'		=> $result->request_scenario,
					'api_id' 				=> $api_id,
					'fareBasis'				=> $fareBasis,
					'specific_rec_details'	=> $result->specific_rec_details,
					'bundle_search_id'		=> @$result->bundle_search_id
					);

				   if($result->bundle_search_id!=''||$result->bundle_search_id==0){
				   	$booking_cart_id = $this->Flight_Model->delete_cart_flight($result->bundle_search_id);
				   }

				  // 	echo "<pre/>";print_r($cart_flight);exit("1185");
				   $booking_cart_id = $this->Flight_Model->insert_cart_flight($cart_flight);

				   if($this->session->userdata('user_id')){
						$user_type =$this->session->userdata('user_type');
						$user_id = $this->session->userdata('user_id');
					}else{
						$user_type = '';
						$user_id = '';
					}
					$cart_global = array(
						'parent_cart_id' => 0,
						'referal_id' => $booking_cart_id,
						'product_id' => '1',
						'user_type' => $user_type,
						'user_id' => $user_id,
						'session_id' => $session_id,
						'site_currency' => BASE_CURRENCY,
						'total_cost' => $result->amount,
						'bundle_search_id'=> @$result->bundle_search_id,
						'ip_address' =>  $this->input->ip_address(),
						'timestamp' => date('Y-m-d H:i:s')
						);
					if($result->bundle_search_id!=''||$result->bundle_search_id==0){
				   	$booking_cart_id = $this->Flight_Model->delete_cart_global($result->bundle_search_id);
				   }
				$cart_global_id = $this->Flight_Model->insert_cart_global($cart_global);
				/*$request = $this->custom_db->single_table_records('search_history', '', array('origin' => $result->bundle_search_id));
					$fs = json_decode($request['data'][0]['search_data'], true);
				*/	
					$data['status'] = 1;
					$data['isCart'] = true;
					$search_module_id = $uid_v1->search_id;
					$search_module = $uid_v1->search_module;
					$data['C_URL'] = WEB_URL.'booking/'.$session_id.'/'.$search_module_id.'/'.$search_module;
		   		
		
	}else{
		$data['isCart'] = false;
	}
		echo json_encode($data);    
	}
}

 public function generate_rand_no($length = 24) {
        $alphabets = range('A','Z');
        $numbers = range('0','9');
        $final_array = array_merge($alphabets,$numbers);
        //$id = date("ymd").date("His");
        $id = '';
        while($length--) {
          $key = array_rand($final_array);
          $id .= $final_array[$key];
        }
        return $id;
    }

function ajaxPaginationData($session_data){
        //echo "<pre>"; print_r($this->input->post()); echo "</pre>"; die();
        

        $page = $this->input->post('page');
        $offset = (!$page) ? 0 : $page ;
        
         //What ever the filtering data comes here
        $data = json_decode($this->input->post('filter'),true);

        list($from_amt, $to_amt) = explode('-',$data['amount']);
        $from_amt = (int) trim(str_replace($this->display_icon,'', $from_amt));
        $to_amt  =  (int) trim( str_replace($this->display_icon,'', $to_amt));

        $amount_filter['Amount >='] = floor(($from_amt / $this->curr_val)); 
        $amount_filter['Amount <=']  = ceil($to_amt / $this->curr_val);
        // echo "<pre/>";print_r($amount_filter);die;
        if($data['airline'] != ''){
			for($a=0;$a<count($data['airline']);$a++){
				$data['airline'][$a] = str_replace("_"," ",$data['airline'][$a]);
			}
		}
        $airline_filter = count($data['airline']) > 0 ?  $data['airline'] : NULL;

        if($data['con_air'] != ''){
            for($a=0;$a<count($data['con_air']);$a++){
                $data['con_air'][$a] = str_replace("_"," ",$data['con_air'][$a]);
            }
        }
        $con_air_filter = count($data['con_air']) > 0 ?  $data['con_air'] : NULL;

        if($data['prefer'] != ''){
            for($a=0;$a<count($data['prefer']);$a++){
                $data['prefer'][$a] = str_replace("_"," ",$data['prefer'][$a]);
            }
        }
        $prefer = count($data['prefer']) > 0 ?  $data['prefer'] : NULL;

    $stop_filter = count($data['stops']) > 0 ?  $data['stops'] : NULL;

    $min_arrive_tme =  $max_arrive_tme = $min_depart_tme =  $max_depart_tme = $min_return_tme =  $max_return_tme =  NULL ;

        if(count($data['arrive_time']) > 0 )
        {
            $min_arrive_tme = $max_arrive_tme = 0 ;
            foreach ($data['arrive_time'] as $key => $val)
            {
                $arr = $this->format_time($val);

                if( $arr['min'] <= $min_arrive_tme OR $min_arrive_tme === 0)
                {
                    $min_arrive_tme = $arr['min'];
                }

                if( $arr['max']  >=  $max_arrive_tme )
                {
                    $max_arrive_tme = $arr['max'];
                }
            }

        }

        // echo '<pre/>';print_r($data);exit;
        if(count($data['depart_time']) > 0 )
        {
            $min_depart_tme = $max_depart_tme = 0 ;
            foreach ($data['depart_time'] as $key => $val) 
            {
                $arr = $this->format_time($val);
               
                if( $arr['min'] <= $min_depart_tme OR $min_depart_tme === 0)
                {
                    $min_depart_tme = $arr['min'];
                }

                if( $arr['max']  >=  $max_depart_tme )
                {
                    $max_depart_tme = $arr['max'];
                }
            }  
         
        }



        if(count($data['return_time']) > 0 )
        {
            $min_return_tme = $max_return_tme =  0 ;
            foreach ($data['return_time'] as $key => $val) 
            {
                $arr = $this->format_time($val);
                if( $arr['min']  <=  $min_return_tme  OR $min_return_tme === 0)
                {
                    $min_return_tme = $arr['min'];
                }
                if( $arr['max']  >=  $max_return_tme )
                {
                    $max_return_tme = $arr['max'];
                    
                    
                }
            } 
        }

        $cond = array('amount_filter' => $amount_filter , 
                      'airline_filter' => $airline_filter,
                      'sort_col' => $data['sort']['column'],
                      'sort_val' => $data['sort']['value'],
                      'stop_filter' => $stop_filter,
                      'min_arrive_tme' => $min_arrive_tme,
                      'max_arrive_tme' => $max_arrive_tme,
                      'min_depart_tme' => $min_depart_tme,
                      'max_depart_tme' => $max_depart_tme,
                      'min_return_tme' => $min_return_tme,
                      'max_return_tme' => $max_return_tme,
                      'con_air_filter' => $con_air_filter,
                      'prefer'         => $prefer
                      ); 


        //total rows count
       // debug($cond);die;
        $totalRec = $this->Flight_Model->get_last_response_count($session_data,$cond);

        $data['flight_count'] =  $totalRec;
       
        $flight_data = $this->Flight_Model->get_last_response_data($session_data);
        

        $data['airline_data'] = $flight_data['airline_data'];
        
        //pagination configuration
        $config['first_link']  = 'First';
        $config['div']         = 'flightsdata'; //parent div tag id
        $config['base_url']    = WEB_URL.'flight/ajaxPaginationData/'.$session_data;
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
        
        $this->ajax_pagination->initialize($config);
        
        //get the posts data
    
       $data['flight_result'] =   $this->Flight_Model->get_last_response_filter($session_data,array('start'=>$offset,'limit'=>$this->perPage) ,$cond);
       
//	 echo '<pre>';print_r($data['flight_result']);exit;
       if(!$data['flight_result'])
        {
            $data['message'] = "No Result Found."; 
        }
        $data['airline_filter'] = $cond['airline_filter'];
        $data['con_air_fil'] = $cond['con_air_filter'];
        $data['connecting_airports_filter'] = $flight_data['connecting_airports_filter'];
//         print_r($cond['airline_filter']);exit;
//		echo "<pre>"; print_r($data); exit;
		$this->load->view(PROJECT_THEME.'/flight/ajax_result',$data);
    }

function format_time($time_f)
{
     switch ($time_f) {
        case '12_6A':
                $time_v1 = '0';$time_v2 = '0600';
            break;
             case '6_12A':
                  $time_v1 = '0600';$time_v2 = '1200';
            break;
             case '12_6P':
                   $time_v1 = '1200';$time_v2 = '1800';
            break;
             case '6_12P':
                 $time_v1 = '1800';$time_v2 = '2400';
            break;
    }

    return array('min' => $time_v1 , 'max' => $time_v2);

}


public function flight_mail_voucher($pnr_no){
  

        $count = $this->booking_model->getBookingPnr($pnr_no)->num_rows();

        if($count == 1){
            $b_data = $this->booking_model->getBookingPnr($pnr_no)->row();
            if($b_data->product_name == 'FLIGHT'){
            //  $data['terms_conditions'] = $this->booking_model->get_terms_conditions($product_id);
           $data['b_data'] = $this->booking_model->getBookingPnr($pnr_no)->row();     
           $booking_global_id=$b_data->booking_global_id;
           $billing_address_id=$b_data->billing_address_id;
             
                 $data['Passenger'] = $passenger = $this->booking_model->getPassengerbyid($booking_global_id)->result();
                 $data['booking_agent'] = $passenger = $this->booking_model->getagentbyid($billing_address_id)->result();
                $data['message'] = $this->load->view(PROJECT_THEME.'/booking/mail_voucher', $data,TRUE);
               
                $data['to'] = $data['booking_agent'][0]->billing_email;               
                $data['booking_status'] = $b_data->booking_status;
                $data['pnr_no'] = $pnr_no;
                $data['email_access'] = $this->email_model->get_email_acess()->row();
                $email_type = 'FLIGHT_BOOKING_VOUCHER';

                
                $Response = $this->email_model->sendmail_flightVoucher($data);
                $response = array('status' => 1);
               // echo"aschva";
                //echo json_encode($response);
            }
        }else{
            $response = array('status' => 0);
            echo json_encode($response);
        }
    }

    function flight_deal($id){
    	$flight_deals =$this->Flight_Model->get_flight_data_deals($id);
    	$from_air=explode('(', $flight_deals[0]->deal_from_place);
    	$to_air=explode('(', $flight_deals[0]->deal_to_place);

    
    	$from_airport_code = trim($from_air[1],")");
    	$to_airport_code = trim($to_air[1],")");
    	
    	$depart_date = date("d-m-Y",strtotime('+7 days'));
    	$return_date = date("d-m-Y",strtotime('+14 days'));
     	// echo "<pre>"; print_r($flight_deals); exit;
  	
    	$request = array(       
		            'type' => 'round',
		            'origin' => $from_airport_code,
		            'destination' => $to_airport_code,
		            'depart_date' => $depart_date,
		            'return_date' => $return_date,
		            'ADT' => 1,
		            'CHD' => 0,
		          	'INF' => 0,
		           'class' => All,
		           'is_domestic' => 0,
        );
    	$query=http_build_query($request);
    	// echo $query; exit();
    	redirect(WEB_URL.'flight/?'.$query);
    	
     } 

      function renderApiResponse_calender($SearchResponse,$rand_id){
		$flight_result = $this->xml2array($SearchResponse);

        $flightResult = array(); $currency = '';   
            // Calendar Module
            if (!isset($flight_result['soapenv:Envelope']['soapenv:Body']['Fare_MasterPricerCalendarReply']['errorMessage'])) {
                if (isset($flight_result['soapenv:Envelope']['soapenv:Body']['Fare_MasterPricerCalendarReply']))
                    $flightResult = $flight_result['soapenv:Envelope']['soapenv:Body']['Fare_MasterPricerCalendarReply'];
            }


      
        $flightIndex1 = array(); 
        $flightIndex = array();



        if($flightResult){
            $currency = $flightResult['conversionRate']['conversionRateDetail']['currency'];
            // To Check the JourneyType: Oneway Or Roundtrip or Multicity or Calendar
            $flightIndex1 = $flightResult['flightIndex'];

            if(!isset($flightIndex1[0]))
                $flightIndex[0] = $flightIndex1;
            else
                $flightIndex = $flightIndex1;
            	$flightIndexCount = count($flightIndex);
            for ($i = 0; $i < $flightIndexCount; $i++){ // No of Flight Records Loop
                $groupOfFlights = $flightIndex[$i]['groupOfFlights'];
                $groupOfFlightsCount = count($groupOfFlights);
                for ($f = 0; $f < ($groupOfFlightsCount); $f++) { // To Check the Flight Segment
                    $FlightSegment1 = array(); $FlightSegment = array();
                    $FlightSegment1 = $groupOfFlights[$f]['flightDetails'];

                    if(!isset($FlightSegment1[0]))
                        $FlightSegment[0] = $FlightSegment1;
                    else
                        $FlightSegment = $FlightSegment1;   
                            
                    for ($j = 0; $j < (count($FlightSegment)); $j++) {
                        $flightId  = $groupOfFlights[$f]['propFlightGrDetail']['flightProposal'][0]['ref'];
                        $flightDetails1[$flightId]['Flight'][$i]['flightId']                    = $groupOfFlights[$f]['propFlightGrDetail']['flightProposal'][0]['ref'];
                        
                        $flightDetails1[$flightId]['Flight'][$i]['currency']                    = $currency;
                        $flightDetails1[$flightId]['Flight'][$i]['stops']                       = $j;
                        $flightDetails1[$flightId]['Flight'][$i]['FlightEft']                   = $groupOfFlights[$f]['propFlightGrDetail']['flightProposal'][1]['ref'];
                        $flightDetails1[$flightId]['Flight'][$i]['dateOfDeparture'][$j]         = $departureDate = $FlightSegment[$j]['flightInformation']['productDateTime']['dateOfDeparture'];
                        $flightDetails1[$flightId]['Flight'][$i]['timeOfDeparture'][$j]         = $departureTime = $FlightSegment[$j]['flightInformation']['productDateTime']['timeOfDeparture'];
                        $flightDetails1[$flightId]['Flight'][$i]['dateOfArrival'][$j]           = $arrivalDate = $FlightSegment[$j]['flightInformation']['productDateTime']['dateOfArrival'];
                        $flightDetails1[$flightId]['Flight'][$i]['timeOfArrival'][$j]           = $arrivalTime = $FlightSegment[$j]['flightInformation']['productDateTime']['timeOfArrival'];
                        $flightDetails1[$flightId]['Flight'][$i]['flightOrtrainNumber'][$j]     = $FlightSegment[$j]['flightInformation']['flightOrtrainNumber'];
                        $flightDetails1[$flightId]['Flight'][$i]['marketingCarrier'][$j]        = $FlightSegment[$j]['flightInformation']['companyId']['marketingCarrier'];
                        $flightDetails1[$flightId]['Flight'][$i]['airlineName'][$j]             = $this->Flight_Model->get_airline_name($FlightSegment[$j]['flightInformation']['companyId']['marketingCarrier']);
                        
                        $flightDetails1[$flightId]['Flight'][$i]['DepartureDate'][$j]           = ((substr("$departureDate", 0, -4)) . "-" . (substr("$departureDate", -4, 2)) . "-20" . (substr("$departureDate", -2)));
                        $flightDetails1[$flightId]['Flight'][$i]['ArrivalDate'][$j]             = ((substr("$arrivalDate", 0, -4)) . "-" . (substr("$arrivalDate", -4, 2)) . "-20" . (substr("$arrivalDate", -2)));
                        
                        $flightDetails1[$flightId]['Flight'][$i]['DepartureTime'][$j]           = ((substr("$departureTime", 0, -2)) . ":" . (substr("$departureTime", -2)));
                        $flightDetails1[$flightId]['Flight'][$i]['ArrivalTime'][$j]             = ((substr("$arrivalTime", 0, -2)) . ":" . (substr("$arrivalTime", -2)));
                        
                        $eft_final = str_split($flightDetails1[$flightId]['Flight'][$i]['FlightEft'],2);
                        $flightDetails1[$flightId]['Flight'][$i]['durationFinalEft'] = $eft_final[0]." h ".$eft_final[1]." min";
                        
                        
                        // Red Eye Feature
                        if ((($flightDetails1[$flightId]['Flight'][$i]['timeOfDeparture'][0]) <= "0700") && (($flightDetails1[$flightId]['Flight'][$i]['timeOfArrival'][$j]) >= "2000"))
                            $flightDetails1[$flightId]['Flight'][$i]['redEye'] = "Yes";
                        else
                            $flightDetails1[$flightId]['Flight'][$i]['redEye'] = "No";
                        
                        // Diffrent Airport Feature
                        if ($flightDetails1[$flightId]['Flight'][$i]['marketingCarrier'][0] != $flightDetails1[$flightId]['Flight'][$i]['marketingCarrier'][$j])
                            $flightDetails1[$flightId]['Flight'][$i]['DiffrentAirport'] = "Yes";
                        else
                            $flightDetails1[$flightId]['Flight'][$i]['DiffrentAirport'] = "No";
                        
                        // Short layover Time and Long Layover Time feature
                        if($j != 0)
                        {
                            $departureDateTimeLayover                                       = new DateTime($flightDetails1[$flightId]['Flight'][$i]['DepartureDate'][$j]." ".$flightDetails1[$flightId]['Flight'][$i]['DepartureTime'][$j]);
                            $arrivalDateTimeLayover                                         = new DateTime($flightDetails1[$flightId]['Flight'][$i]['ArrivalDate'][($j-1)]." ".$flightDetails1[$flightId]['Flight'][$i]['ArrivalTime'][($j-1)]);
                            $Layoverinterval                                                = date_diff($arrivalDateTimeLayover,$departureDateTimeLayover);
                            
                            $hour_layover                                                   = $Layoverinterval->format('%h');
                            $min_layover                                                    = $Layoverinterval->format('%i');
                            $dur_in_min_layover                                             = (($hour_layover * 60) + $min_layover);
                            $flightDetails1[$flightId]['Flight'][$i]['LayoverDurationMins'] = $dur_in_min_layover;
                            $flightDetails1[$flightId]['Flight'][$i]['LayoverDurationText'] = $Layoverinterval->format('%h H %i M');
                            $flightDetails1[$flightId]['Flight'][$i]['LayoverDuration'][$j] = $Layoverinterval->format('%h H %i M');
                        }
                        // echo '<pre/>';print_r($FlightSegment[$j]);exit;
                        if(isset($FlightSegment[$j]['flightInformation']['companyId']['operatingCarrier'])){
							$flightDetails1[$flightId]['Flight'][$i]['operatingCarrier'][$j]        = $FlightSegment[$j]['flightInformation']['companyId']['operatingCarrier'];
                        }else{
                            $flightDetails1[$flightId]['Flight'][$i]['operatingCarrier'][$j]    = '';
                        }
                        // echo '<pre/>';print_r($FlightSegment);exit;
                        $flightDetails1[$flightId]['Flight'][$i]['locationIdDeparture'][$j]     = $FlightSegment[$j]['flightInformation']['location'][0]['locationId'];
                        $flightDetails1[$flightId]['Flight'][$i]['locationIdArival'][$j]        = $FlightSegment[$j]['flightInformation']['location'][1]['locationId'];
                        
                        $dep_name                                                               = $this->Flight_Model->get_airport_cityname($flightDetails1[$flightId]['Flight'][$i]['locationIdDeparture'][$j]);
                        $arr_name                                                               = $this->Flight_Model->get_airport_cityname($flightDetails1[$flightId]['Flight'][$i]['locationIdArival'][$j]);
                        if(isset($flightDetails1[$flightId]['Flight'][$i]['DepartureAirport'][$j]))
                        $flightDetails1[$flightId]['Flight'][$i]['DepartureAirport'][$j]        = $dep_name->city.", ".$dep_name->country." (".$dep_name->city_code.")";
                        if(isset($flightDetails1[$flightId]['Flight'][$i]['ArrivalAirport'][$j]))
                        $flightDetails1[$flightId]['Flight'][$i]['ArrivalAirport'][$j]          = $arr_name->city.", ".$arr_name->country." (".$arr_name->city_code.")";
                        
                        $dep_time_zone_offset                                                   = $this->Flight_Model->get_time_zone_details($flightDetails1[$flightId]['Flight'][$i]['locationIdDeparture'][$j]); 
                        $arv_time_zone_offset                                                   = $this->Flight_Model->get_time_zone_details($flightDetails1[$flightId]['Flight'][$i]['locationIdArival'][$j]); 
                        $flightDetails1[$flightId]['Flight'][$i]['dep_time_zone_offset'][$j]    = $dep_time_zone_offset;
                        $flightDetails1[$flightId]['Flight'][$i]['arv_time_zone_offset'][$j]    = $arv_time_zone_offset;
                        
                        $flightDetails1[$flightId]['Flight'][$i]['equipmentType'][$j]           = $FlightSegment[$j]['flightInformation']['productDetail']['equipmentType'];
                        $flightDetails1[$flightId]['Flight'][$i]['electronicTicketing'][$j]     = $FlightSegment[$j]['flightInformation']['addProductDetail']['electronicTicketing'];
                        $flightDetails1[$flightId]['Flight'][$i]['productDetailQualifier'][$j]  = $FlightSegment[$j]['flightInformation']['addProductDetail']['productDetailQualifier'];
                        // Time Zone Related Code
						if(isset($flightDetails1[$flightId]['Flight'][$i]['dep_time_zone_offset'][$j]))
							$dep_zone = explode(":",($flightDetails1[$flightId]['Flight'][$i]['dep_time_zone_offset'][$j]));
						if(isset($flightDetails1[$flightId]['Flight'][$i]['arv_time_zone_offset'][$j]))
							$arv_zone = explode(":",($flightDetails1[$flightId]['Flight'][$i]['arv_time_zone_offset'][$j]));
						
						if($flightId == 2)	{
							// print_r($dep_zone)." ".print_r($arv_zone);exit;
						}
						if(!empty($arv_zone)){
							$Change_clock=(($arv_zone[0].".".$arv_zone[1])-($dep_zone[0].".".$dep_zone[1]));
							if(!is_int($Change_clock)){
								$Changeclock	= explode(".", $Change_clock);
								$Changeclock0	= $Changeclock[0];
								if($Changeclock0 > 0){
									$Changeclock1 	= ($Changeclock[1]*6);
								}else{
									$Changeclock1 	= (-1 * $Changeclock[1]*6);
								}
							}else{
								$Changeclock0	= $Change_clock;
								$Changeclock1	= 0;
							}
						}
                        $ddate = ((substr("$departureDate", 0, -4)) . "-" . (substr("$departureDate", -4, 2)) . "-20" . (substr("$departureDate", -2))) . " " . ((substr("$departureTime", 0, -2)) . ":" . (substr("$departureTime", -2))) . "";;
                        $adate = ((substr("$arrivalDate", 0, -4)) . "-" . (substr("$arrivalDate", -4, 2)) . "-20" . (substr("$arrivalDate", -2))) . " " . ((substr("$arrivalTime", 0, -2)) . ":" . (substr("$arrivalTime", -2))) . "";
                        $date_a = new DateTime($ddate);
                        $date_b = new DateTime($adate);
                        $interval 	= date_diff($date_a, $date_b);
						$hour 		= $interval->format('%h');
						$min 		= $interval->format('%i');
						$day1		= $interval->format('%d');
						$dur_in_min = ((($hour * 60) + $min) - (($Changeclock0 * 60) + $Changeclock1));
						$hour 		= FLOOR($dur_in_min / 60);
						$min 		= $dur_in_min%60;
						
						if($hour<0){ $hour=((24)+($hour)); }
						if($min<0){ $min=((60)+($min)); }
						
						$day 		= floor(((($hour * 60) + $min) / 1440));
						$hours 		= floor((($hour * 60) + $min) / 60);
						$minutes	= ((($hour * 60) + $min) % 60);
						
						if($hours>24){
							$hours=($hours % 24);
						}
                        if ($day1 > 0)
                            $duration_time_zone=$day1." D ".$hours." h ".$minutes." min";
                        else
                            $duration_time_zone=$hours." h ".$minutes." min";
                            
                        $flightDetails1[$flightId]['Flight'][$i]['duration_time_zone'][$j]      = $duration_time_zone;
                        $flightDetails1[$flightId]['Flight'][$i]['Clock_Changes'][$j]           = $Change_clock;
                        $flightDetails1[$flightId]['Flight'][$i]['dur_in_min_time_zone'][$j]    = $dur_in_min;
                  }
                }
            }
           
            $x = 0; $recommendation = array();
            if(isset($flightResult['recommendation'][0]))
                $recommendation                 = $flightResult['recommendation'];
            else
                $recommendation[0]              = $flightResult['recommendation'];
            foreach ($recommendation as $p => $s) {

                if(isset($s['itemNumber']['itemNumberId']['numberType'])){ $price = $p;$flag = "MTK"; }else{$price = 0;$flag = "Normal";}
                $segmentFlightRef = array();
                if(isset($s['segmentFlightRef'][0]))
                    $segmentFlightRef           = $s['segmentFlightRef'];
                else
                    $segmentFlightRef[0]        = $s['segmentFlightRef'];
                for ($sfr = 0; $sfr <  (count($segmentFlightRef)); $sfr++) {
                    $referencingDetail = array();
                    if(isset($segmentFlightRef[$sfr]['referencingDetail'][0]))
                        $referencingDetail      = $segmentFlightRef[$sfr]['referencingDetail'];
                    else
                        $referencingDetail[0]   = $segmentFlightRef[$sfr]['referencingDetail'];
                    for ($rd = 0; $rd < (count($referencingDetail)); $rd++) {
                        $refNumber              = $referencingDetail[$rd]['refNumber']."-".$flag."-".$p;
                        $refNumberFlight        = $referencingDetail[$rd]['refNumber'];
                        $refQualifier           = $referencingDetail[$rd]['refQualifier'];
                        if(isset($s['itemNumber']['itemNumberId']['numberType'])){
                            $flightDetails[$refNumber][$price]['PriceInfo']['MultiTicket']          = "Yes";
                            // $flightDetails[$refNumber][$p]['PriceInfo']['MultiTicket_type']      = $s['itemNumber']['itemNumberId']['numberType'];
                            $flightDetails[$refNumber][$price]['PriceInfo']['MultiTicket_number']   = $s['itemNumber']['itemNumberId']['number'];
                        }else{
                            $flightDetails[$refNumber][$price]['PriceInfo']['MultiTicket']          = "No";
                            $flightDetails[$refNumber][$price]['PriceInfo']['MultiTicket_number']   = $s['itemNumber']['itemNumberId']['number'];
                        }
                        
                        $flightDetails[$refNumber][$price]['PriceInfo']['refQualifier']             = $refQualifier;
                        $flightDetails[$refNumber][$price]['PriceInfo']['totalFareAmount']          = $s['recPriceInfo']['monetaryDetail'][0]['amount'];
                        $flightDetails[$refNumber][$price]['PriceInfo']['totalTaxAmount']           = $s['recPriceInfo']['monetaryDetail'][1]['amount'];

                        $paxFareProduct = array();
                        if(isset($s['paxFareProduct'][0]))
                            $paxFareProduct             = $s['paxFareProduct'];
                        else
                            $paxFareProduct[0]          = $s['paxFareProduct'];
                        for($pfp = 0; $pfp < (count($paxFareProduct)); $pfp++) {
                            $paxReference = array();
                            if(isset($paxFareProduct[$pfp]['paxReference']['traveller'][0]))
                                $paxReference           = $paxFareProduct[$pfp]['paxReference']['traveller'];
                            else
                                $paxReference[0]        = $paxFareProduct[$pfp]['paxReference']['traveller'];
                            $flightDetails[$refNumber][$price]['PriceInfo']['passengerType'] = $passengerType = $paxFareProduct[$pfp]['paxReference']['ptc'];
                            for($pr = 0; $pr < (count($paxReference)); $pr++) {
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['count']       = ($pr+1);
                            }
                            
                            $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['totalFareAmount']         = $paxFareProduct[$pfp]['paxFareDetail']['totalFareAmount'];
                            $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['totalTaxAmount']          = $paxFareProduct[$pfp]['paxFareDetail']['totalTaxAmount'];
                            if(isset($paxFareProduct[$pfp]['paxFareDetail']['codeShareDetails']['transportStageQualifier'])){
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['transportStageQualifier'] = $paxFareProduct[$pfp]['paxFareDetail']['codeShareDetails']['transportStageQualifier'];
                            }else{
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['transportStageQualifier'] = '';
                            }
                            if(isset($paxFareProduct[$pfp]['paxFareDetail']['codeShareDetails']['company'])){
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['company']                 = $paxFareProduct[$pfp]['paxFareDetail']['codeShareDetails']['company'];
                            }else{
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['company']                 = '';
                            }
                                
                        
                            $fare = array();
                            if(isset($paxFareProduct[$pfp]['fare'][0]))
                                $fare           = $paxFareProduct[$pfp]['fare'];
                            else
                                $fare[0]        = $paxFareProduct[$pfp]['fare'];
                            
                            for($fa = 0; $fa < (count($fare)); $fa++) {
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['fare'][$fa]['description'] = '';  
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['fare'][$fa]['textSubjectQualifier']   = $fare[$fa]['pricingMessage']['freeTextQualification']['textSubjectQualifier'];
                                $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['fare'][$fa]['informationType']        = $fare[$fa]['pricingMessage']['freeTextQualification']['informationType'];
                                $description = array();
                                if(is_array($fare[$fa]['pricingMessage']['description']))
                                    $description            = $fare[$fa]['pricingMessage']['description'];
                                else
                                    $description[0]         = $fare[$fa]['pricingMessage']['description'];
                                $flightDetails[$refNumber][$price]['PriceInfo']['fare'][$fa]['description'] = ''    ;
                                for ($d = 0; $d < count($description); $d++) {
                                    if(isset($description[$d]))
                                        $flightDetails[$refNumber][$price]['PriceInfo']['PassengerFare'][$passengerType]['fare'][$fa]['description'] .= $description[$d] . " - ";
                                }
                            }
                            $fareDetails = array();
                            if(isset($paxFareProduct[$pfp]['fareDetails'][0]))
                                $fareDetails            = $paxFareProduct[$pfp]['fareDetails'];
                            else
                                $fareDetails[0]         = $paxFareProduct[$pfp]['fareDetails'];
                            for($fd = 0; $fd < (count($fareDetails)); $fd++) 
                            {
                                $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['flightMtkSegRef']              = $fareDetails[$fd]['segmentRef']['segRef'];
                                $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['designator']           = $fareDetails[$fd]['majCabin']['bookingClassDetails']['designator'];                                   
                                $groupOfFares = array();
                                if(isset($fareDetails[$fd]['groupOfFares'][0]))
                                    $groupOfFares           = $fareDetails[$fd]['groupOfFares'];
                                else
                                    $groupOfFares[0]        = $fareDetails[$fd]['groupOfFares'];
                                for($gf = 0; $gf < (count($groupOfFares)); $gf++) 
                                {
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['rbd'][$gf]         = $groupOfFares[$gf]['productInformation']['cabinProduct']['rbd'];
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['cabin'][$gf]       = $groupOfFares[$gf]['productInformation']['cabinProduct']['cabin'];
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['avlStatus'][$gf]   = $groupOfFares[$gf]['productInformation']['cabinProduct']['avlStatus'];
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['breakPoint'][$gf]  = $groupOfFares[$gf]['productInformation']['breakPoint'];
                                    $flightDetails[$refNumber][$price]['PriceInfo']['fareDetails'][$fd]['fareType'][$gf]    = $groupOfFares[$gf]['productInformation']['fareProductDetail']['fareType'];
                                }
                            }
                        }
                    }
                }
            }

            foreach ($recommendation as $p => $s) {
                if(isset($s['itemNumber']['itemNumberId']['numberType'])) { $price = $p;$flag = "MTK"; }else{ $price = 0;$flag = "Normal"; }
                $segmentFlightRef = array();
                if(isset($s['segmentFlightRef'][0]))
                    $segmentFlightRef           = $s['segmentFlightRef'];
                else
                    $segmentFlightRef[0]        = $s['segmentFlightRef'];
                for ($sfr = 0; $sfr <  (count($segmentFlightRef)); $sfr++) {
                    $referencingDetail = array();
                    if(isset($segmentFlightRef[$sfr]['referencingDetail'][0]))
                        $referencingDetail      = $segmentFlightRef[$sfr]['referencingDetail'];
                    else
                        $referencingDetail[0]   = $segmentFlightRef[$sfr]['referencingDetail'];
                    for ($rd = 0; $rd < (count($referencingDetail)); $rd++) {
                        $refNumber              = $referencingDetail[$rd]['refNumber']."-".$flag."-".$p;
                        $refNumberFlight        = $referencingDetail[$rd]['refNumber'];
                        $refQualifier           = $referencingDetail[$rd]['refQualifier'];
                        $FinalResult[$x]['FlightDetailsID']     = $x;
                        $FinalResult[$x]['FlightDetails'][$rd]  = $flightDetails1[$refNumberFlight]['Flight'][$rd];
                    }
                    
                    $priceDetailsfinal = array();
                    foreach($flightDetails[$refNumber] as $price)
                        $priceDetailsfinal[] = $price;
                    
                    $FinalResult[$x]['PricingDetails']      = $priceDetailsfinal;
                    
                    if (!isset($s['paxFareProduct'][0])) {
                    	$paxFareProduct[0] = $s['paxFareProduct'];
                    } else {
                    	$paxFareProduct = $s['paxFareProduct'];
                    }
                    $FinalResult[$x]['paxFareProduct'] = $paxFareProduct;                    
                    $specificRecDetails ='';

                   // echo "recommendation11<pre>"; print_r($s); echo "</pre>"; 

                    if (!empty($s['specificRecDetails'])){
                    	if (!empty($s['specificRecDetails'][0]['specificProductDetails'][0])){
                    		$specificRecDetails = $s['specificRecDetails']['0']['specificProductDetails'][0]['fareContextDetails']['cnxContextDetails'][0]['fareCnxInfo']['contextDetails']['availabilityCnxType'];
                    	} else {
                     		$specificRecDetails = $s['specificRecDetails']['0']['specificProductDetails']['fareContextDetails']['cnxContextDetails'][0]['fareCnxInfo']['contextDetails']['availabilityCnxType'];
                    	}
                    	$FinalResult[$x]['specificRecDetails'] = $specificRecDetails;
                    }
                    
                    $x++;
                }
            }
        }else{
        	//if there is no result
        	$FinalResult = array();
        }

        	//echo "asdfg<pre>"; print_r($FinalResult); echo "</pre>"; die();
        
        return $data['flight_result'] = $FinalResult;
    }

    public function send_group_bookingsearch(){
        $gb_id='TRIP-'.time();
    	$insert_data=array(
    	                'gb_id' => $gb_id,
						'request' => json_encode($_POST),
						'agent_id' => $this->session->userdata('user_id'),
						'agent_type' => $this->session->userdata('user_type'),
					);
    	if($this->custom_db->insert_record('group_booking',$insert_data)){
    		$this->session->set_flashdata('group_book_msg','Thank you for your booking enquiry. We will be in touch shortly. Please note this booking is not yet confirmed');
    	}else{
    		$this->session->set_flashdata('group_book_msg','There was an error trying to send your enquiry.Please try again later.');
    	}
    	redirect(WEB_URL.'dashboard/add_search');
    }
    public function get_grp_booking()
    {
    	$data['user_id'] = $user_id = $this->session->userdata('user_id');
	    $data['user_type']=$user_type =  $this->session->userdata('user_type');
	    $data['userInfo'] = $this->general_model->get_user_details($user_id,$user_type);
		$data['group_report']=$this->Flight_Model->get_group_booking_agent();
		$this->load->view(PROJECT_THEME.'/dashboard/dashboard_group_enquiry',$data);
    }
    
    public function view_more($type)
    {
        $data['top_flightdeals']	=	$this->Home_Model->get_flight_deals();
        $data['type']	=	$type;
        $this->load->view(PROJECT_THEME.'/common/view_more', $data);
    }
    
    public function custom_search(){
        $request 	= $this->input->get(); 

		$depature = date("Y-m-d", strtotime("+1 week"));

		$request['trip_type'] = 'circle';
		$request['depature'] = date("F d Y", strtotime($depature));
		$request['return'] = date('F d Y', strtotime($depature . ' +5 day'));
		$request['class'] = 'Economy';
		$request['class2'] = 'Economy';
		$request['airlines'] = 0;
		$request['adult'] = 1;
		$request['child'] = 0;
		$request['infant'] = 0;
		$request['infant_child'] = 0;
		
        $insert_report['search_type'] = 'FLIGHT';
		$insert_report['trip_type'] = $request['trip_type'];
		$insert_report['cehck_from'] = $request['from'];
       	$insert_report['cehck_to'] = $request['to'];
       	$insert_report['cehck_both'] = $request['from'].' - '.$request['to'];

        $search_report_data = $this->custom_db->insert_record('search_report',$insert_report);

        $insert_data['search_type'] = 'FLIGHT';
        
        if($request['depature']){
       		$request['depature'] = date('d-m-Y',strtotime($request['depature']));
       	}
       	if($request['return']){
       		$request['return']= date('d-m-Y',strtotime($request['return']));
       	}
       
       $insert_data['search_data'] = json_encode($request);
       $insert_data['search_type'] = 'FLIGHT';
        
        $search_insert_data = $this->custom_db->insert_record('search_history',$insert_data);
        
        $request['type'] = $request['trip_type'];
        
        $return_date = '';$isdomstic='';
        $dep_check=explode("-",$request['depature']);
        $deppp    = 		count($dep_check);	
        	if(($request['type'])=="round"){
        		$ret_check=explode("-",$request['return']);
        		$rett     =count($ret_check);
        	}	
        $from_aircode=explode('(',$request['from']);
        $to_aircode=explode('(',$request['to']);
        $cehck_from=count($from_aircode);
        $cehck_to=count($to_aircode);
        
        $type 	= 'type=round'; $return_date = '&return_date='.$request['return'];
        
        $from_aircode=substr(chop(substr($request['from'], -5), ')'), -3);
        $country_name=$this->Flight_Model->getcountry_name($from_aircode);
        $from_country=$country_name->country;
        $to_aircode=substr(chop(substr($request['to'], -5), ')'), -3);
        $country_name=$this->Flight_Model->getcountry_name($to_aircode);
        $to_country=$country_name->country;
        
        
        $isdomstic=0;
        if($request['airlines']!="0" && $request['airlines']!="" ){
        	$airline=$request['airlines'];	
        }else{
        	$airline='';	
        }
         
        
         $query 	= $type.'&origin='.substr(chop(substr($request['from'], -5), ')'), -3).'&destination='.substr(chop(substr($request['to'], -5), ')'), -3).'&depart_date='.$request['depature'].$return_date.'&ADT='.$request['adult'].'&CHD='.$request['child'].'&INF='.$request['infant'].'&class='.$request['class2'].'&is_domestic='.$isdomstic.'&airline='.$airline.'&search_id='.$search_insert_data['insert_id'].'&flexible='.$request['flexible'];
        
        redirect(WEB_URL.'flight/?'.$query);  
	 	
    }

    function test(){
    $test=PNR_Retrieve('UQLM2Y');

    }







//end of file
}
?>
