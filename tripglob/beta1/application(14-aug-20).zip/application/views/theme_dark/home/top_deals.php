<!--top_deals-->


<div class="ithudeals">
	<div class="container">
    	<div class="staffarea">
        	<div class="pagehed">Top Deals</div>
            <div class="centersep"><div class="comn_icons"><img src="<?php echo ASSETS; ?>images/user.png"  alt=""/></div></div>
            <div class="clearfix"></div>
        	<ul class="nav nav-tabs customdeals" role="tablist">
                <li data-role="presentation" class="active">
                	<a href="#hotdeals" data-aria-controls="home" data-role="tab" data-toggle="tab">Holidays</a>
                </li>
                <li data-role="presentation">
                	<a href="#lastminutes" data-aria-controls="profile" data-role="tab" data-toggle="tab">Hotels</a>
                </li>
                <li data-role="presentation">
                	<a href="#earlybookings" data-aria-controls="messages" data-role="tab" data-toggle="tab">Activities</a>
                </li>
             </ul>
            <div class="clearfix"></div>
            
            <div class="tab-content">
            
                <div role="tabpanel" class="tab-pane active" id="hotdeals">
                	<div class="retmnus">
                    	<div id="owl-demo2" class="owl-carousel owlindex2 navchange">
                    
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd1.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd2.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd3.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd4.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                     </div>
                     </div>
                </div>
                
                <div role="tabpanel" class="tab-pane" id="lastminutes">
                	<div class="retmnus">
               		 <div id="owl-demo3" class="owl-carousel owlindex2 navchange">
                    
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd1.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd2.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd3.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd4.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
        
                     </div>
                     </div>
                 </div>
                <div role="tabpanel" class="tab-pane" id="earlybookings">
                	<div class="retmnus">
                	<div id="owl-demo4" class="owl-carousel owlindex2 navchange">
                    
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd1.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd2.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd3.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
                                
                                <a class="portimgwrap item">
                                    <div class="portimg"><img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/dd4.jpg" alt="" /> </div>
                                    <div class="imgname">
                                    <div class="col-md-8 nopad"> 
                                        <span class="tile">Belgium</span>
                                        <span class="starbook"><img src="<?php echo ASSETS; ?>images/star4.png" alt="" /></span>
                                    </div>
                                    <div class="col-md-4 nopad">
                                        <span class="strngat">starting@</span>
                                        <span class="tileprice">$299</span>
                                    </div>
                                    </div>
                                </a>
        
                     </div>
                     </div>
                 </div>
            </div>
            
            
        </div>
    </div>
</div>


<!--/top_deals-->
