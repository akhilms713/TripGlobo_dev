<!-- Deals -->
<div class="fullback padbotom10 padtopalso">
<div class="container"> 
  
  <!-- Marketing Icons Section -->
  <div class="row">
  
  	<div class="col-lg-12">
      <h1 class="pageheader centralign">TURKEY DEALS & OFFERS</h1>
      <span class="centersmalcps">Lorem Ipsum is simply dummy text of the printing and </span>
    </div>
 	<div class="col-lg-12">
	<div class="dealslider">
        <div id="owl-demo" class="owl-carousel owlindex">
      
          <a class="item chinadel">
            <div class="dealimage">
                <img src="<?php echo ASSETS; ?>images/d1.jpg" alt="" />
            </div>
            <div class="imgname2">
                	<span class="tilenew">Hot Deal</span>
                    <div class="clear"></div>
                    <div class="col-md-8 nopad">
                    	<span class="delabl">hagia sophia</span>
                    </div>
                    <div class="col-md-4 nopad">
                        <span class="delprice">$49.00</span>
                    </div>
               
                </div>
          </a>
          
          <a class="item chinadel">
            <div class="dealimage">
                <img src="<?php echo ASSETS; ?>images/d2.jpg" alt="" />
            </div>
            <div class="imgname2">
                	<span class="tilenew">Hot Deal</span>
                    <div class="clear"></div>
                    <div class="col-md-8 nopad">
                    	<span class="delabl">hagia sophia</span>
                    </div>
                    <div class="col-md-4 nopad">
                        <span class="delprice">$49.00</span>
                    </div>
               
                </div>
          </a>
          
          <a class="item chinadel">
            <div class="dealimage">
                <img src="<?php echo ASSETS; ?>images/d3.jpg" alt="" />
            </div>
            <div class="imgname2">
                	<span class="tilenew">Hot Deal</span>
                    <div class="clear"></div>
                    <div class="col-md-8 nopad">
                    	<span class="delabl">hagia sophia</span>
                    </div>
                    <div class="col-md-4 nopad">
                        <span class="delprice">$49.00</span>
                    </div>
               
                </div>
          </a>
          
          <a class="item chinadel">
            <div class="dealimage">
                <img src="<?php echo ASSETS; ?>images/d4.jpg" alt="" />
            </div>
            <div class="imgname2">
                	<span class="tilenew">Hot Deal</span>
                    <div class="clear"></div>
                    <div class="col-md-8 nopad">
                    	<span class="delabl">hagia sophia</span>
                    </div>
                    <div class="col-md-4 nopad">
                        <span class="delprice">$49.00</span>
                    </div>
               
                </div>
          </a>
          
		</div>
          
        <div id="owl-demoone" class="owl-carousel owlindex">
      
          <a class="item chinadel">
            <div class="dealimage">
                <img src="<?php echo ASSETS; ?>images/d1.jpg" alt="" />
            </div>
            <div class="imgname2">
                	<span class="tilenew">Hot Deal</span>
                    <div class="clear"></div>
                    <div class="col-md-8 nopad">
                    	<span class="delabl">hagia sophia</span>
                    </div>
                    <div class="col-md-4 nopad">
                        <span class="delprice">$49.00</span>
                    </div>
               
                </div>
          </a>
          
          <a class="item chinadel">
            <div class="dealimage">
                <img src="<?php echo ASSETS; ?>images/d2.jpg" alt="" />
            </div>
            <div class="imgname2">
                	<span class="tilenew">Hot Deal</span>
                    <div class="clear"></div>
                    <div class="col-md-8 nopad">
                    	<span class="delabl">hagia sophia</span>
                    </div>
                    <div class="col-md-4 nopad">
                        <span class="delprice">$49.00</span>
                    </div>
               
                </div>
          </a>
          
          <a class="item chinadel">
            <div class="dealimage">
                <img src="<?php echo ASSETS; ?>images/d3.jpg" alt="" />
            </div>
            <div class="imgname2">
                	<span class="tilenew">Hot Deal</span>
                    <div class="clear"></div>
                    <div class="col-md-8 nopad">
                    	<span class="delabl">hagia sophia</span>
                    </div>
                    <div class="col-md-4 nopad">
                        <span class="delprice">$49.00</span>
                    </div>
               
                </div>
          </a>
          
          <a class="item chinadel">
            <div class="dealimage">
                <img src="<?php echo ASSETS; ?>images/d4.jpg" alt="" />
            </div>
            <div class="imgname2">
                	<span class="tilenew">Hot Deal</span>
                    <div class="clear"></div>
                    <div class="col-md-8 nopad">
                    	<span class="delabl">hagia sophia</span>
                    </div>
                    <div class="col-md-4 nopad">
                        <span class="delprice">$49.00</span>
                    </div>
               
                </div>
          </a>
          
		</div>
          
		</div>
    </div>
    <div class="vmore">View More</div>
	</div>
  </div>
</div>
<!-- Deals -->
