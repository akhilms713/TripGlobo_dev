
<!-- Why -->
<div class="fullback padbotom10 padtopalso">
<div class="container"> 
  
  <!-- Marketing Icons Section -->
  <div class="row">
  
  	<div class="col-lg-12 specheadmar">
      <h1 class="pageheader centralign">WORLDWIDE TOP DESTINATIONS</h1>
      <span class="centersmalcps">Lorem Ipsum is simply dummy text of the printing and </span>
    </div>
 	<div class="col-lg-12  boxx">
      
      <div id="owl-demo2" class="owl-carousel owlindex2">

        	<div class="portimgwrap clr1 item">
            	<div class="portimg"> <img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/d1.jpg" alt="" /> </div>
            	<div class="imgname">
                <span class="tile">DUBAI</span>
               <span class="selplace">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been </span>
                <span class="tileprice">View More</span>
                </div>
            </div>
            
            <div class="portimgwrap clr2 item">
            	<div class="portimg"> <img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/d2.jpg" alt="" /> </div>
            	<div class="imgname">
                <span class="tile">HONKONG</span>
               <span class="selplace">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been </span>
                <span class="tileprice">View More</span>
                </div>
            </div>
            
            <div class="portimgwrap clr3 item">
            	<div class="portimg"> <img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/d3.jpg" alt="" /> </div>
            	<div class="imgname">
                <span class="tile">JAPAN</span>
                 <span class="selplace">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been </span>
                <span class="tileprice">View More</span>
                </div>
            </div>
            
            <div class="portimgwrap clr4 item">
            	<div class="portimg"> <img class="img-responsive img-portfolio img-hover" src="<?php echo ASSETS; ?>images/d4.jpg" alt="" /> </div>
            	<div class="imgname">
                <span class="tile">FRANKFURT</span>
                <span class="selplace">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been </span>
                <span class="tileprice">View More</span>
                </div>
            </div> 


      </div> 
        
        
        
      </div>
	</div>
  </div>
</div>
<!-- why -->
