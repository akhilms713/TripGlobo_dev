
<!--/holiday-->
<div class="topdeal">
<div class="dealshaedow"></div>
	<div class="container">
    	<div class="pagehed">Hloiday Types</div>
        <h5 class="subcaption">Find a holiday by type</h5>
		<div class="centersep"><div class="comn_icons"><img src="<?php echo ASSETS; ?>images/user.png"  alt=""/></div></div>
        <div class="clearfix"></div>
        <div class="dealslider">
        	<div id="owl-demodeals" class="owl-carousel owlindex3 owl-theme">
              <div class="item">
                <a class="ourdeal"><span class="sprite1 cmndeal deal1"></span><span class="dealplace">Adventure</span></a>
              </div>
              <div class="item">
                <a class="ourdeal"><span class="sprite1 cmndeal deal2"></span><span class="dealplace">Sports</span></a>
              </div>
              <div class="item">
                <a class="ourdeal"><span class="sprite1 cmndeal deal3"></span><span class="dealplace">Wildlife</span></a>
              </div>
              <div class="item">
                <a class="ourdeal"><span class="sprite1 cmndeal deal4"></span><span class="dealplace">Family</span></a>
              </div>
              <div class="item">
                <a class="ourdeal"><span class="sprite1 cmndeal deal5"></span><span class="dealplace">Explorer</span></a>
              </div>
              <div class="item">
                <a class="ourdeal"><span class="sprite1 cmndeal deal5"></span><span class="dealplace">Adventure</span></a>
              </div>
           </div>
        </div>
    </div>
</div>
<!--/holiday-->
