<!--destination-->

<div class="destions">
	<div class="container">
    	<div class="pagehed">Our Destinations</div>
        <h5 class="subcaption">Choose your next Destinations</h5>
		<div class="centersep"><div class="comn_icons"><img src="<?php echo ASSETS; ?>images/user.png"  alt=""/></div></div>
        <div class="clearfix"></div>
        <div class="destslider">
        	<div id="owl-demodestination" class="owl-carousel owlindex2 owl-theme">
              <div class="item">
                <div class="ourdest"><img src="<?php echo ASSETS; ?>images/d1.jpg" alt="" /><span class="destplace">Erope</span></div>
              </div>
              <div class="item">
                <div class="ourdest"><img src="<?php echo ASSETS; ?>images/d2.jpg" alt="" /><span class="destplace">India</span></div>
              </div>
              <div class="item">
                <div class="ourdest"><img src="<?php echo ASSETS; ?>images/d3.jpg" alt="" /><span class="destplace">Japan</span></div>
              </div>
              <div class="item">
                <div class="ourdest"><img src="<?php echo ASSETS; ?>images/d4.jpg" alt="" /><span class="destplace">Australia</span></div>
              </div>
              <div class="item">
                <div class="ourdest"><img src="<?php echo ASSETS; ?>images/d5.jpg" alt="" /><span class="destplace">Africa</span></div>
              </div>
           </div>
        </div>
    </div>
</div>

<!--/destination-->
