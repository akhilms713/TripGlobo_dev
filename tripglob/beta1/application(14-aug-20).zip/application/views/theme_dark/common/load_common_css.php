<link href='https://fonts.googleapis.com/css?family=Raleway:400,500' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link href="<?php echo base_url(); ?>assets/theme_dark/css/font-awesome5.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo ASSETS; ?>css/font-awesome.min.css" rel="stylesheet" type="text/css">

<link href="<?php echo ASSETS; ?>css/bootstrap.min.css" rel="stylesheet" />
<link href="<?php echo ASSETS; ?>css/jquery_ui.css" rel="stylesheet" type="text/css">
<link href="<?php echo ASSETS; ?>css/owl.carousel.css" rel="stylesheet" />
<link href="<?php echo ASSETS; ?>css/animation.css" rel="stylesheet" />
<!-- Custom CSS -->
<!--<link href="<?php //echo ASSETS; ?>css/custom.css" rel="stylesheet" />-->
<link href="<?php echo ASSETS; ?>css/temp.css" rel="stylesheet" />
<script src="<?php echo ASSETS; ?>js/jquery-1.11.0.js"></script> 
<script src="<?php echo ASSETS; ?>js/jquery_ui.js"></script>
<script src="<?php echo ASSETS; ?>js/bootstrap.min.js"></script>
