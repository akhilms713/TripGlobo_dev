<div id="confirmation" class="modal fade" data-role="dialog">
<div class="modal-dialog">
    <div class="modal-content">
	<div class="activation">
    	<div class="close_activation fa fa-close"></div>
        <div class="activation_hd">OK, you are almost there...</div>
        <div class="round_acti fa fa-check"></div>
        <span class="active_acoounts">We'he sent a link to
        <span class="mail_active" id="confim_email_idshow"></span>
        to activate your account.</span>
      <!--  <span class="dont_get">Didn't get email from us? <a>Resend</a></span>-->
    <span class="check_spam">Check to see if it's hiding in your junk mail.</span>
    </div>
    </div>
</div>
</div> 
<footer>
<div class="comonfooter">
  	<div class="footerbotm">

          <span class="copurit">&copy; <?=date('Y')?> <a href="http://tripglobo.com">TripGlobo.com</a> All Rights Reserved </span> 

    </div>
</div>

</footer>
