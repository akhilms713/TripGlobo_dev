<script> var WEB_URL = "<?php echo WEB_URL; ?>";</script>
<script type='text/javascript' src="<?php echo ASSETS;?>js/owl.carousel.min.js"></script>
<script type='text/javascript' src="<?php echo ASSETS;?>js/validate/jquery.validate.js"></script>
<script type='text/javascript' src="<?php echo ASSETS;?>js/validate/custom.js"></script>
<script type="text/javascript" src="<?php echo ASSETS; ?>js/custom_1.js"></script>
<script type="text/javascript" src="<?php echo ASSETS; ?>js/pax_count.js"></script>
<script type="text/javascript" src="<?php echo ASSETS; ?>js/hotel_suggest.js"></script>





