<?php
 
//$Booking=$b_data;


// function getairlinecode($code=''){
//         $air = explode('-', $code);
//         $MarketingAirlineCode = $air[0];
//         return $MarketingAirlineCode;
//     } $request = json_decode(base64_decode($Booking->request));// echo '<pre/>';print_r($request);exit;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<style type="text/css">
div, p, a, li, td {
   -webkit-text-size-adjust:none;
}
#outlook a {
   padding:0;
}
html {
   width: 100%;
}
body {
   width:100% !important;
   -webkit-text-size-adjust:100%;
   -ms-text-size-adjust:100%;
   margin:0;
   padding:0;
}
.ExternalClass {
   width:100%;
}
.ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {
   line-height: 100%;
}
#backgroundTable {
   margin:0;
   padding:0;
   width:100% !important;
   line-height: 100% !important;
}
img {
   outline:none;
   text-decoration:none;
   border:none;
   -ms-interpolation-mode: bicubic;
}
a img {
   border:none;
}
.image_fix {
   display:block;
}
p {
   margin: 0px 0px !important;
}
table td {
   border-collapse: collapse;
}
table {
   border-collapse:collapse;
   mso-table-lspace:0pt;
   mso-table-rspace:0pt;
   font-size:14px; color:#333;
}
table[class=full] {
   width: 100%;
   clear: both;
}
 @media only screen and (max-width: 640px) {
a[href^="tel"], a[href^="sms"] {
   text-decoration: none;
   color: #33b9ff;
   pointer-events: none;
   cursor: default;
}
.mobile_link a[href^="tel"], .mobile_link a[href^="sms"] {
   text-decoration: default;
   color: #33b9ff !important;
   pointer-events: auto;
   cursor: default;
}
table[class=devicewidth] {
   width: 440px!important;
   text-align:center!important;
}
table[class=devicewidth2] {
   width: 440px!important;
   text-align:center!important;
}
table[class=devicewidth3] {
   width: 400px!important;
   text-align:center!important;
}
table[class=devicewidth33] {
   width: 420px!important;
   text-align:center!important;
}
table[class=devicewidthinner] {
   width: 420px!important;
   text-align:center!important;
}
img[class=banner] {
   width: 440px!important;
   height:220px!important;
}
img[class=col2img] {
   display:block;
   margin:0 auto;
}
}
 @media only screen and (max-width: 480px) {
a[href^="tel"], a[href^="sms"] {
   text-decoration: none;
   color: #33b9ff;
   pointer-events: none;
   cursor: default;
}
.mobile_link a[href^="tel"], .mobile_link a[href^="sms"] {
   text-decoration: default;
   color: #33b9ff !important;
   pointer-events: auto;
   cursor: default;
}
table[class=devicewidth] {
   width: 280px!important;
   text-align:center!important;
}
table[class=devicewidth33] {
   width: 260px!important;
   text-align:center!important;
}
table[class=devicewidth2] {
   width: 280px!important;
   text-align:center!important;
}
table[class=devicewidth3] {
   width: 240px!important;
   text-align:center!important;
}
table[class=devicewidthinner] {
   width: 260px!important;
   text-align:center!important;
}
img[class=banner] {
   width: 280px!important;
   height:140px!important;
}
img[class=col2img] {
   width: 260px!important;
   height:140px!important;
}
.social {
   display: block;
   float: none;
   margin: 0 auto;
   overflow: hidden;
   padding: 10px 0;
   text-align: center !important;
   width: 100%;
}
.social div {
}
}
</style>
</head>
<body>

<table width="100%"  cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="header">
   <tbody>
      <tr>
         <td>
            <table width="645" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
               <tbody>
                  <tr>
                     <td width="100%" style="border: 1px solid #dddddd;">
                        <table width="645" bgcolor="#ffffff" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth">
                           <tbody>
                              <tr>
                                 <td>
                                    <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                       <tr>
                                          <td align="left" width="100%">
                                             <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                                <tr>
                                                   <!-- <td align="left"><img src="http://108.170.38.171/vietnet/assets/theme_dark/images/logo.png" /></td> -->
                                                   <td align="right">
                                                      <div class="confirmtionltr" style="text-align:center;">Quotation Details</div>
                                                   </td>
                                                </tr>
                                             </table>
                                             <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                                <tr>
                                                   <td align="left" width="100%">
                                                      <table width="100%" border="0" align="center" cellpadding="8" cellspacing="0" style=" font-family:Arial, Helvetica, sans-serif; font-size:13px;" class="tables">
                                                         <tbody>
                                                            <tr>
                                                               <td align="left"></td>
                                                               <td align="right" style="font-size:13px; line-height:20px;"></td>
                                                            </tr>
                                                            <tr>
                                                               <td colspan="2" style="border:0px; border-top:1px dashed #CCC;">
                                                                  <table width="100%" border="0" align="center" cellpadding="8" cellspacing="0">
                                                                     <tbody>
                                                                        <tr>
                                                                           <td align="center" bgcolor="#ffffff" class="padding1" style="border: 1px solid #eee; padding:0px;">
                                                                              <table width="100%" border="0" cellspacing="0" cellpadding="7" bgcolor="#FFFFFF" class="paddingTableTable">
                                                                                 <tbody>
                                                                                    <?php   
                                                                                       $detail_count = count($flight_result['FlightDetails']);
                                                                                       for($j=0;$j<$detail_count;$j++){
                                                                                         $flight_id=$flight_result['FlightDetails'][$j]['FlightDetailsID'];
                                                                                         $inner_segment_len=count($flight_result['FlightDetails'][$j]['dateOfDeparture']) - 1;
                                                                                    ?>
                                                                                    <tr style="font-size:12px; color:#666;">
                                                                                       <td width="25%" rowspan="2" style="border-right: 1px solid #eee;">
                                                                                          <div class="padwithbord">
                                                                                             <div style="padding:5px 0;" class="leftflitmg"> <img src="https://c.fareportal.com/n/common/air/ai/<?php echo $flight_result['FlightDetails'][$j]['MarketingAirline'][0]; ?>.gif" />  </div>
                                                                                             <div style="padding:5px 0;" class="fligtdetss">
                                                                                                <?php echo $flight_result['FlightDetails'][$j]['Airline_name'][0]; ?>
                                                                                                <?php echo $flight_result['FlightDetails'][$j]['MarketingAirline'][0]; ?> -  <?php echo $flight_result['FlightDetails'][$j]['FlighvgtNumber_no'][0]; ?>
                                                                                             </div>
                                                                                             <div style="padding:5px 0;" class="opfligt"> Operated by: <strong><?php echo $flight_result['FlightDetails'][$j]['Airline_name'][0]; ?></strong></div>
                                                                                             <div style="padding:5px 0;" class="opfligt">Duration: <strong><?php echo $this->Flight_Model->get_airport_cityname($flight_result['FlightDetails'][$j]['OriginLocation'][0]); ?></strong></div>
                                                                                          </div>
                                                                                       </td>
                                                                                       <td bgcolor="#FFFFFF" style="border-bottom:1px solid #EEE; border-right:1px solid #EEE; vertical-align:top;">
                                                                                          <span style="font-size:14px; color:#333; font-weight:bold; padding: 5px 0;display: block;">
                                                                                             <?php echo date("H:i", strtotime($flight_result['FlightDetails'][$j]['DepartureDateTime_r'][0]));   ?></span>
                                                                                             <?php echo $this->Flight_Model->get_airport_cityname($flight_result['FlightDetails'][$j]['OriginLocation'][0]); ?>
                                                                                       </td>
                                                                                       <td bgcolor="#FFFFFF" style="border-bottom:1px solid #EEE; border-right:1px solid #EEE;vertical-align:top;"><span style="font-size:14px;color:#333; font-weight:bold;display: block;padding: 5px 0;">
                                                                                          <?php echo date("H:i", strtotime($flight_result['FlightDetails'][$j]['ArrivalDateTime_r'][$inner_segment_len]));  ?></span>
                                                                                          <?php echo $this->Flight_Model->get_airport_cityname($flight_result['FlightDetails'][$j]['DestinationLocation'][$inner_segment_len]); ?>
                                                                                       </td>
                                                                                       <td width="25%" rowspan="2" bgcolor="#FFFFFF">
                                                                                          <span style="display:block; padding:5px 0;"><strong>Aircraft:</strong>
                                                                                          <?php echo date("H:i", strtotime($flight_result['FlightDetails'][$j]['ArrivalDateTime_r'][$inner_segment_len]));  ?></span> <br/>
                                                                                          <span style="display:block; padding:5px 0;"><strong>Stop(s):
                                                                                                                                                      <?php  
                                                                                             if($flight_result['FlightDetails'][$j]['stops']==0){
                                                                                                 echo "Non-Stop";
                                                                                             }else{
                                                                                                 echo $flight_result['FlightDetails'][$j]['stops']." "."Stop"; 
                                                                                             }
                                                                                             ?>   
                                                                                          </span><br/>
                                                                                       </td>
                                                                                    </tr>
                                                                                    <tr colspan="5">
                                                                                       <td bgcolor="#FFFFFF" style="border-right:1px solid #EEE;vertical-align:top;padding-bottom:5px;"><span style="display:block; padding:5px 0;">Departing At:</span>
                                                                                          <span style="font-size:13px; font-weight:bold;"><?php echo date("H:i", strtotime($flight_result['FlightDetails'][$j]['DepartureDateTime_r'][0]));   ?></span>
                                                                                       </td>
                                                                                       <td bgcolor="#FFFFFF" style="border-right:1px solid #EEE;vertical-align:top;padding-bottom:5px;"><span style="display:block; padding:5px 0;">Arriving At:</span>
                                                                                          <span style="font-size:12px; font-weight:bold;"><?php echo date("H:i", strtotime($flight_result['FlightDetails'][$j]['ArrivalDateTime_r'][$inner_segment_len]));  ?></span>
                                                                                       </td>
                                                                                    </tr>
                                                                                    <?php
                                                                                       
                                                                                       }?>
                                                                                 </tbody>
                                                                              </table>
                                                                           </td>
                                                                        </tr>
                                                                        <tr>
                                                                           <td style="height:20px;width:100%;"></td>
                                                                        </tr>
                                                                     </tbody>
                                                                  </table>
                                                               </td>
                                                            </tr>

                                                            <tr>
                                                               <td style="padding:0px;">
                                                                  <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" class="detailtbl">
                                                                     <tbody>
                                                                        <tr>
                                                                           <td width="100%"  align="right" style="padding:10px">
                                                                              <div style="color: #666; display: block; line-height: 20px; overflow: hidden; text-align: right; font-family: Helvetica Neue, Helvetica, Arial, sans-serif;">
                                                                              <table width="100%" border="0" cellspacing="1" cellpadding="7" bgcolor="#FFFFFF" class="con_addr_bottom">
                                                                                 <td colspan="2" bgcolor="##008000" style=" color: #ffffff; border-bottom: 1px solid #eee;">
                                                                                       <div class="snotes" style="text-align: left;font-size:13px;">
                                                                                          Agent Markup : <?php echo $agent_markup; ?>
                                                                                       </div>
                                                                                 </td>
                                                                              </table>
                                                                              </div>
                                                                           </td>
                                                                        </tr>
                                                                     </tbody>
                                                                  </table>
                                                               </td>
                                                            </tr>
                                                            <?php // echo 'terms_conditions<pre/>';print_r($terms_conditions);exit; ?>
                                                       
                                                            <tr>
                                                               <td style="padding:0px;">
                                                                  <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" class="detailtbl">
                                                                     <tbody>
                                                                        <tr>
                                                                           <td width="100%"  align="right" style="padding:10px">
                                                                              <div style="color: #666; display: block; line-height: 20px; overflow: hidden; text-align: right; font-family: Helvetica Neue, Helvetica, Arial, sans-serif;">
                                                                              <table width="100%" border="0" cellspacing="1" cellpadding="7" bgcolor="#FFFFFF" class="con_addr_bottom">
                                                                                 <td colspan="2" bgcolor="#dd2a1b" style=" color: #ffffff; border-bottom: 1px solid #eee;">
                                                                                       <div class="snotes" style="text-align: left;font-size:13px;">Vietnet Address</div>
                                                                                 </td>
                                                                                 <tr style="color:#666; line-height:20px;">
                                                                                 <td colspan="5" align="left" valign="top" style="border:0px; border-right:1px solid #FFF;">
                                                                                 <p style="margin:0px"><i class='fa fa-home'></i> <label>Lorem Ipsum is simply dummy text of the printing and typesetting industry. <br/></label></p><br/>
                                                                                 <p style="margin:0px"><i class='fa fa-phone'></i>Phone Number:  +0123456789</p>
                                                                                 <p style="margin:0px"><i class='fa fa-envelope'></i> Email: info@Vietnet.us</p>
                                                                                 <p style="margin:0px"><i class='fa fa-envelope'></i> Website :Vietnet.com</p><br/>
                                                                                 </td>
                                                                                 </tr>
                                                                              </table>
                                                                              </div>
                                                                           </td>
                                                                        </tr>
                                                                     </tbody>
                                                                  </table>
                                                               </td>
                                                            </tr>
                                                         </tbody>
                                                      </table>
                                                   </td>
                                                </tr>
                                             </table>
                                          </td>
                                       </tr>
                                    </table>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </td>
                  </tr>
               </tbody>
            </table>
         </td>
      </tr>
   </tbody>
</table>

</body>
</html>
