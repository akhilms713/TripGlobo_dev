
<div class="comonfooter dashboar_footer">
	    <span class="copurit"> <?php echo date('Y');?> <a href="#"></a> All Rights Reserved </span> 
</div>