<script type="text/javascript" src="<?php echo base_url(); ?>assets/theme_dark/js/backslider.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/theme_dark/js/custom.js"></script>
<script>
var WEB_URL = "<?php echo WEB_URL; ?>";
</script>
<script type='text/javascript' src="<?php echo ASSETS;?>js/owl.carousel.min.js"></script>
<script type='text/javascript' src="<?php echo ASSETS;?>js/validate/jquery.validate.js"></script>
<script type='text/javascript' src="<?php echo ASSETS;?>js/validate/custom.js"></script>
<script type="text/javascript" src="<?php echo ASSETS; ?>js/custom_1.js"></script>
<script type="text/javascript">
   var api_url='<?php echo base_url();?>';
</script>
<script type="text/javascript" src="<?php echo ASSETS; ?>js/custom_modified.js"></script>
<script type="text/javascript" src="<?php echo ASSETS; ?>js/cbpFWTabs.js"></script>
